import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'util.dart';

Future<Map<String, dynamic>> loadConfig() async {
  final rows = await sb.from('app_config').select();
  return {for (final r in rows) r['key'] as String: r['value']};
}

Future<void> openUrl(BuildContext c, String? url) async {
  final u = (url ?? '').trim();
  if (u.isEmpty) {
    toast(c, 'লিংকটি এখনো সেট করা হয়নি');
    return;
  }
  try {
    await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {
    if (c.mounted) toast(c, 'লিংক খোলা যায়নি', err: true);
  }
}

String linkOf(Map<String, dynamic> cfg, String key) {
  final l = cfg['links'];
  if (l is Map && l[key] != null) return '${l[key]}';
  return '';
}
