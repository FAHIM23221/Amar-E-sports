# Update-12 — বিল্ড ফেইল ফিক্স (আসল Flutter SDK দিয়ে যাচাই করা)

## GitHub-এ কী ভুল হয়েছিল
GitHub-এর বিল্ড লগে অ্যাডমিন অ্যাপ বানাতে গিয়ে এই লাইনে আটকে গেছে:

```
admin_app/lib/admin.dart:1434
? const ListView(children: [SizedBox(height: 80), Center(child: Text('কেউ জয়েন করেনি', ...)))] )
Target kernel_snapshot_program failed
```

## আসল কারণ (অনুমান নয়, Flutter SDK দিয়ে প্রমাণিত)
`ListView`-এর কনস্ট্রাক্টর `const` নয় — Flutter-এর সোর্সে `ListView({` লেখা, `const ListView({` নয়।
তাই `const ListView(...)` লিখলেই কম্পাইলার ভুল ধরে: **"The constructor being called isn't a const constructor"**
(`const_with_non_const`)। আগের আপডেটগুলোতে শুধু Dart-এর analyzer ব্যবহার করা হয়েছিল,
সেখানে Flutter-এর টাইপগুলো চেনা যেত না বলে এই ভুলটা ধরা পড়েনি।

একই ভুল আরেক জায়গায়ও ছিল — `admin.dart:1317`-এর "কোনো ম্যাচ নেই" লাইনেও।

## কী ঠিক করা হয়েছে
- `admin_app/lib/admin.dart:1317` ও `:1434` — দুটো জায়গা থেকেই `const` সরিয়ে
  সাধারণ `ListView(...)` করা হয়েছে। ভেতরের উইজেটগুলো আগের মতোই আছে, দেখতে কিছু বদলায়নি।
- সঙ্গে ছোট পরিষ্কার-পরিচ্ছন্নতা: অপ্রয়োজনীয় ৫টি `as Map<String, dynamic>` কাস্ট
  এবং ইউজার অ্যাপের অব্যবহৃত `compact` ভ্যারিয়েবলটি সরানো হয়েছে
  (এগুলো বিল্ড আটকাত না, শুধু সতর্কবার্তা দিত)।
- Update-11-এর `ledgerLabel` ফিক্স আগের মতোই আছে (অ্যাডমিন `util.dart`-এ ম্যাপ,
  `admin.dart`-এ `ledgerLabel['...']` ব্যবহার) — আবার যাচাই করা হয়েছে।

## যাচাই (এবার আসল Flutter SDK 3.50.1 দিয়ে — GitHub CI-এর একই সংস্করণ)
- `flutter pub get` — দুই অ্যাপেই সফল।
- `flutter analyze` — **ইউজার অ্যাপ: ০টি এরর, অ্যাডমিন অ্যাপ: ০টি এরর।**
  বাকি শুধু info/warning (যেমন পুরনো API ব্যবহারের নোট) — এগুলো বিল্ড আটকায় না।
- `flutter assemble ... kernel_snapshot_program` — **দুই অ্যাপেই সফল (exit 0)**,
  `app.dill` তৈরি হয়েছে (ইউজার অ্যাপ ৩৫ MB, অ্যাডমিন অ্যাপ ৩৭ MB)।
  এটাই GitHub-এ ফেইল করা ধাপ — এখন সেটা পাস করে।
- নোট: `flutter build bundle` এখানে চালানো যায়নি, কারণ সেটা Android SDK চায়
  (এখানে Android SDK নেই)। কিন্তু kernel কম্পাইল ধাপটি সরাসরি চালিয়ে যাচাই করা হয়েছে,
  তাই GitHub-এর Dart কম্পাইল পাস করার কথা।

## করণীয়
GitHub-এ update-12-এর কোড দিয়ে আবার workflow চালান। বিল্ড হলে APK ডাউনলোড করে জানাবেন,
আর আবার ফেইল হলে লগের ছবি পাঠাবেন।
