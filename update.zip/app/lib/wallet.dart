import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'home.dart' show ledgerLabel;

// পুরনো অ্যাপের Wallet: কালো "Available Balance" হেডার, Add Money / Withdraw
// ট্যাব, bKash / Nagad / Rocket লোগো কার্ড, উইথড্র ফর্ম (Recharge সহ)।

const _wdMethods = ['bkash', 'nagad', 'rocket', 'recharge'];

String _methodLabel(String m) {
  switch (m) {
    case 'bkash':
      return 'bKash';
    case 'nagad':
      return 'Nagad';
    case 'rocket':
      return 'Rocket';
    case 'recharge':
      return 'Recharge';
    default:
      return m;
  }
}

String _methodAsset(String m) {
  switch (m) {
    case 'nagad':
      return 'assets/images/nagad.png';
    case 'rocket':
      return 'assets/images/rocket.png';
    default:
      return 'assets/images/bkash.png';
  }
}

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  late Future<Map<String, dynamic>> _f;
  var _tab = 0; // 0 = Add Money, 1 = Withdraw
  var _wdMethod = 'bkash';
  final _wdNumber = TextEditingController();
  final _wdAmount = TextEditingController();

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _wdNumber.dispose();
    _wdAmount.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select().eq('user_id', me).single();
    final l = await sb.from('ledger').select().eq('user_id', me).order('created_at', ascending: false).limit(30);
    final dep = await sb.from('deposits').select().eq('user_id', me).eq('status', 'pending');
    final wd = await sb.from('withdrawals').select().eq('user_id', me).eq('status', 'pending');
    final cfg = await loadConfig();
    return {'w': w, 'l': l, 'dep': dep, 'wd': wd, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _submitWithdraw(Map<String, dynamic> cfg) async {
    final number = _wdNumber.text.trim();
    final amount = int.tryParse(_wdAmount.text.trim());
    if (!phoneRe.hasMatch(number)) {
      toast(context, 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)');
      return;
    }
    if (amount == null || amount <= 0) {
      toast(context, 'সঠিক টাকার অঙ্ক দিন');
      return;
    }
    final ns = cfg['notice_settings'];
    final minVal = ns is Map ? (ns['minimum'] as num?)?.toInt() : null;
    if (minVal != null && minVal > 0 && amount < minVal) {
      toast(context, 'কমপক্ষে $minVal৳ তুলতে হবে');
      return;
    }
    final ok = await run(context, () => sb.rpc('request_withdraw', params: {
          'p_method': _wdMethod,
          'p_number': number,
          'p_amount': amount,
        }), ok: 'উইথড্র রিকোয়েস্ট জমা হয়েছে');
    if (ok) {
      _wdNumber.clear();
      _wdAmount.clear();
      _refresh();
    }
  }

  void _howTo(Map<String, dynamic> cfg) {
    final url = linkOf(cfg, 'howto');
    if (url.isNotEmpty) {
      openUrl(context, url);
      return;
    }
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('টাকা যোগ করার নিয়ম'),
        content: const Text('১. bKash / নগদ / রকেটের যেকোনো একটি বেছে নিন।\n'
            '২. দেওয়া নম্বরে Send Money করুন।\n'
            '৩. TrxID ও যে নম্বর থেকে পাঠিয়েছেন তা লিখে জমা দিন।\n'
            '৪. অ্যাডমিন যাচাই করলে ব্যালেন্সে টাকা যোগ হবে।'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
      ),
    );
  }

  Widget _tabBtn(IconData icon, String label, int index) => Expanded(
        child: InkWell(
          onTap: () => setState(() => _tab = index),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: _tab == index ? Colors.black : Colors.transparent, width: 2)),
            ),
            child: Column(children: [
              Icon(icon, size: 28, color: _tab == index ? Colors.black : Colors.black45),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(fontSize: 18, color: _tab == index ? Colors.black : Colors.black45)),
            ]),
          ),
        ),
      );

  Widget _blackBtn(String label, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.fromLTRB(46, 0, 46, 8),
        child: Material(
          color: Colors.black,
          elevation: 3,
          borderRadius: BorderRadius.circular(6),
          child: InkWell(
            borderRadius: BorderRadius.circular(6),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18))),
            ),
          ),
        ),
      );

  Widget _provider(String asset, VoidCallback onTap) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: AspectRatio(
            aspectRatio: 0.78,
            child: Material(
              color: Colors.white,
              elevation: 3,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: onTap,
                child: Padding(padding: const EdgeInsets.all(14), child: Image.asset(asset)),
              ),
            ),
          ),
        ),
      );

  Widget _wdField(TextEditingController c, String label, {bool number = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: TextField(
          controller: c,
          keyboardType: number ? TextInputType.number : TextInputType.text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black, fontSize: 17),
          inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
          decoration: InputDecoration(
            hintText: label,
            hintStyle: const TextStyle(color: Colors.black87, fontSize: 16),
            border: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue)),
            enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue)),
            focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue, width: 2)),
          ),
        ),
      );

  Widget _withdrawTab(Map<String, dynamic> cfg) {
    final ns = cfg['notice_settings'];
    final minVal = ns is Map ? (ns['minimum'] as num?)?.toInt() : null;
    final minVisible = ns is Map ? ns['minimum_visible'] == true : false;
    final numberLabel = _wdMethod == 'recharge' ? 'Enter your Mobile Number' : 'Enter your ${_methodLabel(_wdMethod)} Number';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('CHOOSE WITHDRAW METHOD', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _wdMethod,
            decoration: const InputDecoration(border: UnderlineInputBorder()),
            items: [for (final m in _wdMethods) DropdownMenuItem(value: m, child: Text(_methodLabel(m)))],
            onChanged: (v) => setState(() => _wdMethod = v ?? 'bkash'),
          ),
          const SizedBox(height: 8),
          const Text('Withdraw can take 24 hours for processing.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 14)),
          _wdField(_wdNumber, numberLabel, number: true),
          _wdField(_wdAmount, 'Amount to Withdraw', number: true),
          if (minVisible && minVal != null && minVal > 0)
            Text('Minimum: $minVal৳', textAlign: TextAlign.center, style: const TextStyle(color: Colors.red, fontSize: 15, fontWeight: FontWeight.bold))
          else
            const Text('Minimum', textAlign: TextAlign.center, style: TextStyle(color: Colors.red, fontSize: 15, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: () => _submitWithdraw(cfg),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A1230), foregroundColor: Colors.white),
              child: const Text('CONFIRM', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _addMoneyTab(Map<String, dynamic> cfg) => Column(
        children: [
          const SizedBox(height: 20),
          _blackBtn('SUPPORT', () {
            final s = linkOf(cfg, 'support');
            openUrl(context, s.isNotEmpty ? s : linkOf(cfg, 'whatsapp'));
          }),
          _blackBtn('HOW TO ADD MONEY?', () => _howTo(cfg)),
          const SizedBox(height: 22),
          const Center(child: Text('মোবাইল রিচার্জ প্রোভাইডার সমূহ', style: TextStyle(color: Colors.black54, fontSize: 16))),
          const SizedBox(height: 18),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(children: [
              _provider('assets/images/bkash.png', () => Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentPage(method: 'bkash', cfg: cfg)))),
              _provider('assets/images/nagad.png', () => Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentPage(method: 'nagad', cfg: cfg)))),
              _provider('assets/images/rocket.png', () => Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentPage(method: 'rocket', cfg: cfg)))),
            ]),
          ),
          const SizedBox(height: 16),
        ],
      );

  @override
  Widget build(BuildContext context) => Theme(
        data: ThemeData(useMaterial3: true, brightness: Brightness.light, colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue)),
        child: Scaffold(
          backgroundColor: const Color(0xFFF7F8FB),
          appBar: AppBar(
            backgroundColor: navy,
            foregroundColor: Colors.white,
            title: const Text('Wallet', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          body: Loader<Map<String, dynamic>>(
            future: _f,
            builder: (d) {
              final w = d['w'] as Map<String, dynamic>;
              final l = d['l'] as List<dynamic>;
              final dep = d['dep'] as List<dynamic>;
              final wd = d['wd'] as List<dynamic>;
              final cfg = d['cfg'] as Map<String, dynamic>;
              final balance = (w['balance'] as num?)?.toInt() ?? 0;
              return RefreshIndicator(
                onRefresh: _refresh,
                child: ListView(padding: EdgeInsets.zero, children: [
                  Container(
                    width: double.infinity,
                    color: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 46),
                    child: Column(children: [
                      const Text('Available Balance', style: TextStyle(color: Colors.white, fontSize: 22)),
                      const SizedBox(height: 14),
                      Text('$balance', style: const TextStyle(color: Colors.white, fontSize: 46, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  Material(
                    color: Colors.white,
                    elevation: 4,
                    child: Row(children: [
                      _tabBtn(Icons.add, 'Add Money', 0),
                      _tabBtn(Icons.account_balance_wallet_outlined, 'Withdraw', 1),
                    ]),
                  ),
                  if (_tab == 0) _addMoneyTab(cfg) else _withdrawTab(cfg),
                  const SizedBox(height: 8),
                  if (dep.isNotEmpty || wd.isNotEmpty) ...[
                    const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('অপেক্ষমাণ রিকোয়েস্ট', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                    for (final e in dep)
                      ListTile(dense: true, title: Text('ডিপোজিট ${taka(e['amount'])} (${e['method']})'), subtitle: Text('TrxID ${e['trx_id']}')),
                    for (final e in wd)
                      ListTile(dense: true, title: Text('উইথড্র ${taka(e['amount'])} (${e['method']})'), subtitle: Text('${e['number']}')),
                    const SizedBox(height: 8),
                  ],
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                  if (l.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('এখনো কোনো লেনদেন নেই')),
                  for (final e in l)
                    ListTile(
                      dense: true,
                      title: Text(ledgerLabel[e['type']] ?? '${e['type']}'),
                      subtitle: Text(when(e['created_at'])),
                      trailing: Text(
                        '${(e['amount'] as num) >= 0 ? '+' : ''}${e['amount']}',
                        style: TextStyle(color: (e['amount'] as num) >= 0 ? Colors.green.shade700 : Colors.red.shade700, fontWeight: FontWeight.bold),
                      ),
                    ),
                  const SizedBox(height: 30),
                ]),
              );
            },
          ),
        ),
      );
}

// ===========================================================================
// Payment পেজ (প্রতি মাধ্যমের জন্য) — পুরনো অ্যাপের মতো: পেমেন্ট নম্বর
// (ট্যাপ করলে কপি হয়), যে নম্বর থেকে পাঠিয়েছেন, টাকার পরিমাণ,
// টিল "SEND PAYMENT REQUEST", লাল সতর্কতা। নম্বর আসে app_config-এর
// payment_numbers থেকে — কোডে কোনো নম্বর লেখা নেই।
// Rocket-এ বাড়তি হিন্ট: আগে Send Money করুন, তারপর Payment Request পাঠান।
// TrxID ঘরটিও আছে — নতুন ব্যাকএন্ড TrxID দিয়ে ডিপোজিট যাচাই করে।
// ===========================================================================

class PaymentPage extends StatefulWidget {
  final String method;
  final Map<String, dynamic> cfg;
  const PaymentPage({super.key, required this.method, required this.cfg});
  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  final _sender = TextEditingController();
  final _amount = TextEditingController();
  final _trx = TextEditingController();
  var _busy = false;

  @override
  void dispose() {
    _sender.dispose();
    _amount.dispose();
    _trx.dispose();
    super.dispose();
  }

  String get _number {
    final nums = widget.cfg['payment_numbers'];
    if (nums is Map) return '${nums[widget.method] ?? ''}'.trim();
    return '';
  }

  Future<void> _submit() async {
    final sender = _sender.text.trim();
    final amount = int.tryParse(_amount.text.trim());
    final trx = _trx.text.trim();
    if (!phoneRe.hasMatch(sender)) {
      toast(context, 'সঠিক নম্বর দিন (01XXXXXXXXX)');
      return;
    }
    if (amount == null || amount < 20 || amount > 50000) {
      toast(context, 'টাকার পরিমাণ ২০ থেকে ৫০,০০০ এর মধ্যে হতে হবে');
      return;
    }
    if (trx.isEmpty) {
      toast(context, 'TrxID দিন');
      return;
    }
    setState(() => _busy = true);
    final ok = await run(context, () => sb.rpc('request_deposit', params: {
          'p_method': widget.method,
          'p_trx': trx,
          'p_amount': amount,
          'p_sender': sender,
        }), ok: 'রিকোয়েস্ট জমা হয়েছে, অ্যাডমিন যাচাই করবেন');
    if (mounted) setState(() => _busy = false);
    if (ok && mounted) Navigator.pop(context);
  }

  Widget _payField(TextEditingController c, String label, {bool number = false}) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 48, vertical: 9),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
        child: TextField(
          controller: c,
          keyboardType: number ? TextInputType.number : TextInputType.text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black, fontSize: 17),
          inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
          decoration: InputDecoration(
            hintText: label,
            hintStyle: const TextStyle(color: Colors.black87, fontSize: 16),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final num = _number;
    return Scaffold(
      backgroundColor: const Color(0xFF0A1B33),
      appBar: AppBar(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        title: const Text('Payment', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(
          children: [
            Image.asset(_methodAsset(widget.method), width: 72, height: 72),
            const SizedBox(height: 10),
            InkWell(
              onTap: num.isEmpty
                  ? null
                  : () async {
                      await Clipboard.setData(ClipboardData(text: num));
                      if (context.mounted) toast(context, 'copied');
                    },
              child: Text(
                num.isEmpty ? 'পেমেন্ট নম্বরের জন্য সাপোর্টে যোগাযোগ করুন' : num,
                style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Tap on Number to copy!', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 22),
            _payField(_sender, 'যে নাম্বার থেকে টাকা পাঠিয়েছেন', number: true),
            _payField(_amount, 'টাকার পরিমান', number: true),
            _payField(_trx, 'TrxID'),
            if (widget.method == 'rocket')
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 6),
                child: Text('আগে Send Money করুন, তারপর Payment Request পাঠান', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF1FB6C9), fontSize: 15, fontWeight: FontWeight.bold)),
              ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 48),
              child: SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: (_busy || num.isEmpty) ? null : _submit,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1FB6C9), foregroundColor: Colors.white),
                  child: const Text('SEND PAYMENT REQUEST', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 32),
              child: Text('অতিরিক্ত কিছুই পাঠালে আপনাকে ব্যান করা হবে', textAlign: TextAlign.center, style: TextStyle(color: Colors.pinkAccent, fontSize: 15, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
