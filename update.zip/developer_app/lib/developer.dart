import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'util.dart';

// ===========================================================================
// ডেভেলপার প্যানেল — অ্যাডমিন প্যানেলের মতো দেখতে হোম + সেকশন।
// কালো ব্যাকগ্রাউন্ড, গাঢ় নেভি হেডার, বড় সাদা মেনু কার্ড, টিল বোতাম।
// এই প্যানেলের সব লেখা RPC দিয়েই হয় (dev_*), ভেতরে is_developer() চেক।
// ===========================================================================

/// সাদা পেজের ফিল্ড: লেবেল + নিচে টিল আন্ডারলাইন।
Widget devField(TextEditingController c, String label, {bool number = false, int maxLines = 1}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(
        controller: c,
        maxLines: maxLines,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.black, fontSize: 16),
        inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.black87),
          border: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal)),
          enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal)),
          focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal, width: 2)),
        ),
      ),
    );

/// টিল বোতাম।
Widget tealBtn(String label, VoidCallback? onTap, {double height = 52}) => SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: devTeal,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child: Text(label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );

/// পাসকোড ফিল্ড (CHANGE DEVELOPER PASSWORD ডায়ালগের জন্য)।
Widget passField(TextEditingController c, String label) => TextField(
      controller: c,
      obscureText: true,
      keyboardType: TextInputType.number,
      maxLength: 4,
      textAlign: TextAlign.center,
      style: const TextStyle(color: Colors.black, fontSize: 18),
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      decoration: InputDecoration(
        hintText: label,
        hintStyle: const TextStyle(color: devTeal, fontSize: 17),
        counterText: '',
        border: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal)),
        enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal)),
        focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: devTeal, width: 2)),
      ),
    );

/// "CHANGE DEVELOPER PASSWORD" ডায়ালগ — অ্যাডমিনের মতো ঠিক দুটো ফিল্ড:
/// Old Password, New Password + SAVE / CANCEL।
Future<void> showChangePasscodeDialog(BuildContext context) async {
  final oldC = TextEditingController();
  final newC = TextEditingController();
  final go = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: Colors.white,
      title: const Text(
        'CHANGE DEVELOPER PASSWORD',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 19),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          passField(oldC, 'Old Password'),
          const SizedBox(height: 18),
          passField(newC, 'New Password'),
          const SizedBox(height: 26),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: devTeal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
              ),
              child: const Text('SAVE', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('CANCEL', style: TextStyle(color: devTeal, fontSize: 16)),
        ),
      ],
    ),
  );
  if (go != true || !context.mounted) return;
  final oldP = oldC.text.trim();
  final newP = newC.text.trim();
  if (!passcodeRe.hasMatch(oldP) || !passcodeRe.hasMatch(newP)) {
    toast(context, 'দুটো পাসকোডই ঠিক ৪ সংখ্যার হতে হবে');
    return;
  }
  if (oldP == newP) {
    toast(context, 'নতুন পাসকোড আগেরটার মতোই');
    return;
  }
  final ok = await run(context, () async {
    final verified = await sb.rpc('verify_developer_passcode', params: {'p_code': oldP});
    if (verified != true) throw Exception('ভুল পুরনো পাসকোড');
    await sb.auth.updateUser(UserAttributes(password: developerAuthPassword(newP)));
    await sb.rpc('admin_set_developer_passcode', params: {'p_old': oldP, 'p_new': newP});
  }, ok: 'পাসকোড বদলে গেছে');
  if (ok) {
    await sb.auth.signOut();
  }
}

/// app_config-এর সব রো একবারে পড়া।
Future<Map<String, dynamic>> loadConfigMap() async {
  final rows = await sb.from('app_config').select();
  return {for (final r in rows) r['key'] as String: r['value']};
}

String cfgStr(Map<String, dynamic> cfg, String key) {
  final v = cfg[key];
  if (v == null) return '';
  if (v is String) return v;
  return '$v';
}

bool cfgBool(Map<String, dynamic> cfg, String key) => cfg[key] == true;

// ===========================================================================
// ডেভেলপার হোম — বড় সাদা মেনু কার্ড, এক কার্ডে এক সেকশন।
// ===========================================================================

class DeveloperHome extends StatelessWidget {
  const DeveloperHome({super.key});

  void _push(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  Widget _menuCard(BuildContext context, IconData icon, String title, String? sub, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Row(
              children: [
                Icon(icon, color: Colors.black, size: 40),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(color: Colors.black, fontSize: 21, fontWeight: FontWeight.w900),
                      ),
                      if (sub != null)
                        Text(
                          sub,
                          style: const TextStyle(color: Colors.black87, fontSize: 14, fontWeight: FontWeight.w700),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Developer Panel'),
        actions: [
          IconButton(icon: const Icon(Icons.lock), onPressed: () => showChangePasscodeDialog(context)),
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () async {
              await sb.auth.signOut();
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 10, bottom: 20),
        children: [
          _menuCard(context, Icons.view_carousel, 'BANNERS & LINKS', 'হোমের স্লাইডার + ক্লিক লিংক',
              () => _push(context, const DevBannersPage())),
          _menuCard(context, Icons.contact_phone, 'CONTACTS', 'WhatsApp / ইমেইল / Telegram',
              () => _push(context, const DevContactsPage())),
          _menuCard(context, Icons.build, 'MAINTENANCE MODE', 'ইউজার + অ্যাডমিন অ্যাপ বন্ধ/খোলা',
              () => _push(context, const DevMaintenancePage())),
          _menuCard(context, Icons.system_update, 'FORCE UPDATE', 'ভার্সন + আপডেট লিংক',
              () => _push(context, const DevForceUpdatePage())),
          _menuCard(context, Icons.admin_panel_settings, 'ADMINS', 'অ্যাডমিন যোগ / ব্যান / পাসকোড',
              () => _push(context, const DevAdminsPage())),
          _menuCard(context, Icons.toggle_on, 'FEATURE CONTROL', 'কোন ফিচার চালু, কোনটা বন্ধ',
              () => _push(context, const DevTogglesPage())),
          _menuCard(context, Icons.history, 'ADMIN ACTIVITY', 'কে কখন কী করল',
              () => _push(context, const DevActivityPage())),
          _menuCard(context, Icons.people, 'USERS', 'ইউজার খোঁজা / ব্যান / পাসওয়ার্ড',
              () => _push(context, const DevUsersPage())),
          _menuCard(context, Icons.account_balance, 'MONEY DASHBOARD', 'ডিপোজিট / উইথড্র / ব্যালেন্স',
              () => _push(context, const DevMoneyPage())),
          _menuCard(context, Icons.notifications, 'NOTICES & PUSH', 'ঘোষণা পাঠানো',
              () => _push(context, const DevPushPage())),
          _menuCard(context, Icons.settings, 'SETTINGS', 'পেমেন্ট নম্বর / সর্বনিম্ন অঙ্ক',
              () => _push(context, const DevSettingsPage())),
        ],
      ),
    );
  }
}

// ===========================================================================
// ১) BANNERS & LINKS — app_config 'banners' (JSON array):
//    [{image, title, link, order, visible}]। ইউজার অ্যাপের হোম স্লাইডার
//    এখান থেকেই ব্যানার পড়ে; না থাকলে আগের হার্ডকোড ব্যানার দেখায়।
// ===========================================================================

class DevBannersPage extends StatefulWidget {
  const DevBannersPage({super.key});
  @override
  State<DevBannersPage> createState() => _DevBannersPageState();
}

class _DevBannersPageState extends State<DevBannersPage> {
  late Future<List<Map<String, dynamic>>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final row = await sb.from('app_config').select('value').eq('key', 'banners').maybeSingle();
    final v = (row as Map?)?['value'];
    if (v is List) {
      final list = [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)];
      list.sort((a, b) => ((a['order'] as num?)?.toInt() ?? 999).compareTo((b['order'] as num?)?.toInt() ?? 999));
      return list;
    }
    return [];
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _save(List<Map<String, dynamic>> list) async {
    final ok = await run(context, () => sb.rpc('dev_save_banners', params: {'p_banners': list}), ok: 'ব্যানার সেভ হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _edit([Map<String, dynamic>? b, int? index]) async {
    final m = await showForm(context, b == null ? 'নতুন ব্যানার' : 'ব্যানার এডিট', [
      const F('image', 'ছবির URL (https://...)'),
      const F('title', 'টাইটেল'),
      const F('link', 'ক্লিক লিংক (Telegram / WhatsApp / YouTube...)'),
      const F('order', 'অর্ডার (১, ২, ৩...)', number: true),
    ], init: {
      'image': '${b?['image'] ?? ''}',
      'title': '${b?['title'] ?? ''}',
      'link': '${b?['link'] ?? b?['url'] ?? ''}',
      'order': '${b?['order'] ?? ''}',
    });
    if (m == null || !mounted) return;
    if ((m['title'] ?? '').isEmpty) {
      toast(context, 'টাইটেল দিন');
      return;
    }
    final list = await _f;
    final item = <String, dynamic>{
      'image': m['image'] ?? '',
      'title': m['title'] ?? '',
      'link': m['link'] ?? '',
      'order': int.tryParse(m['order'] ?? '') ?? (list.length + 1),
      'visible': b?['visible'] != false,
    };
    if (index == null) {
      list.add(item);
    } else {
      list[index] = item;
    }
    await _save(list);
  }

  Future<void> _delete(int index) async {
    if (!await confirm(context, 'এই ব্যানারটি মুছে ফেলবেন?')) return;
    if (!mounted) return;
    final list = await _f;
    list.removeAt(index);
    await _save(list);
  }

  Future<void> _toggleVisible(int index, bool visible) async {
    final list = await _f;
    list[index]['visible'] = visible;
    await _save(list);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Banners & Links')),
        floatingActionButton: FloatingActionButton(
          backgroundColor: devTeal,
          onPressed: () => _edit(),
          child: const Icon(Icons.add, color: Colors.white),
        ),
        body: Loader<List<Map<String, dynamic>>>(
          future: _f,
          builder: (list) => list.isEmpty
              ? const Center(child: Text('কোনো ব্যানার সেট করা নেই — ইউজার অ্যাপে আগের ব্যানার দেখাবে',
                  textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final b = list[i];
                    final visible = b['visible'] != false;
                    return Card(
                      child: ListTile(
                        leading: '${b['image'] ?? ''}'.isNotEmpty
                            ? Image.network('${b['image']}', width: 64, height: 40, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.image, size: 40))
                            : const Icon(Icons.image, size: 40),
                        title: Text('${b['title'] ?? ''}'),
                        subtitle: Text('${b['link'] ?? b['url'] ?? ''}\nঅর্ডার: ${b['order'] ?? '-'}'),
                        isThreeLine: true,
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Switch(
                              value: visible,
                              activeColor: devTeal,
                              onChanged: (v) => _toggleVisible(i, v),
                            ),
                            IconButton(icon: const Icon(Icons.edit, color: Colors.black54), onPressed: () => _edit(b, i)),
                            IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => _delete(i)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ===========================================================================
// ২) CONTACTS — WhatsApp নম্বর, সাপোর্ট ইমেইল, Telegram লিংক
//    (app_config keys: whatsapp / email / telegram)।
// ===========================================================================

class DevContactsPage extends StatefulWidget {
  const DevContactsPage({super.key});
  @override
  State<DevContactsPage> createState() => _DevContactsPageState();
}

class _DevContactsPageState extends State<DevContactsPage> {
  final _wa = TextEditingController();
  final _email = TextEditingController();
  final _tg = TextEditingController();
  late Future<void> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _wa.dispose();
    _email.dispose();
    _tg.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cfg = await loadConfigMap();
    _wa.text = cfgStr(cfg, 'whatsapp');
    _email.text = cfgStr(cfg, 'email');
    _tg.text = cfgStr(cfg, 'telegram');
  }

  Future<void> _save() async {
    await run(context, () => sb.rpc('dev_save_contacts', params: {
          'p_contacts': {
            'whatsapp': _wa.text.trim(),
            'email': _email.text.trim(),
            'telegram': _tg.text.trim(),
          }
        }), ok: 'যোগাযোগের তথ্য সেভ হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Contacts')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator(color: devTeal));
            }
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                devField(_wa, 'WhatsApp নম্বর / লিংক'),
                devField(_email, 'সাপোর্ট ইমেইল'),
                devField(_tg, 'Telegram লিংক'),
                const SizedBox(height: 8),
                const Text('ইউজার অ্যাপের হোয়াটসঅ্যাপ বোতাম ও সাপোর্ট এখান থেকেই নম্বর/লিংক পড়ে।',
                    style: TextStyle(color: Colors.black54, fontSize: 14)),
                const SizedBox(height: 20),
                tealBtn('SAVE', _save),
              ],
            );
          },
        ),
      );
}

// ===========================================================================
// ৩) MAINTENANCE MODE — ইউজার অ্যাপ ও অ্যাডমিন অ্যাপ আলাদা বন্ধ/খোলা যায়,
//    সঙ্গে মেইনটেন্যান্স মেসেজ।
// ===========================================================================

class DevMaintenancePage extends StatefulWidget {
  const DevMaintenancePage({super.key});
  @override
  State<DevMaintenancePage> createState() => _DevMaintenancePageState();
}

class _DevMaintenancePageState extends State<DevMaintenancePage> {
  final _msg = TextEditingController();
  var _user = false;
  var _admin = false;
  late Future<void> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cfg = await loadConfigMap();
    _user = cfgBool(cfg, 'maintenance_user');
    _admin = cfgBool(cfg, 'maintenance_admin');
    _msg.text = cfgStr(cfg, 'maintenance_message');
  }

  Future<void> _save() async {
    await run(context, () => sb.rpc('dev_save_maintenance', params: {
          'p_maintenance': {
            'maintenance_user': _user,
            'maintenance_admin': _admin,
            'maintenance_message': _msg.text.trim(),
          }
        }), ok: 'মেইনটেন্যান্স সেটিংস সেভ হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Maintenance Mode')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator(color: devTeal));
            }
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                SwitchListTile(
                  value: _user,
                  activeColor: devTeal,
                  title: const Text('ইউজার অ্যাপ মেইনটেন্যান্স', style: TextStyle(color: Colors.black, fontSize: 17)),
                  onChanged: (v) => setState(() => _user = v),
                ),
                SwitchListTile(
                  value: _admin,
                  activeColor: devTeal,
                  title: const Text('অ্যাডমিন অ্যাপ মেইনটেন্যান্স', style: TextStyle(color: Colors.black, fontSize: 17)),
                  onChanged: (v) => setState(() => _admin = v),
                ),
                devField(_msg, 'মেইনটেন্যান্স মেসেজ', maxLines: 3),
                const SizedBox(height: 20),
                tealBtn('SAVE', _save),
              ],
            );
          },
        ),
      );
}

// ===========================================================================
// ৪) FORCE UPDATE — ইউজার ও অ্যাডমিন অ্যাপের জন্য আলাদা: সর্বনিম্ন ভার্সন,
//    APK ডাউনলোড লিংক, ফোর্স (true = আপডেট না করে ঢোকা যাবে না)।
// ===========================================================================

class DevForceUpdatePage extends StatefulWidget {
  const DevForceUpdatePage({super.key});
  @override
  State<DevForceUpdatePage> createState() => _DevForceUpdatePageState();
}

class _DevForceUpdatePageState extends State<DevForceUpdatePage> {
  final _minUser = TextEditingController();
  final _minAdmin = TextEditingController();
  final _urlUser = TextEditingController();
  final _urlAdmin = TextEditingController();
  var _forceUser = false;
  var _forceAdmin = false;
  late Future<void> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _minUser.dispose();
    _minAdmin.dispose();
    _urlUser.dispose();
    _urlAdmin.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cfg = await loadConfigMap();
    _minUser.text = cfgStr(cfg, 'min_version_user');
    _minAdmin.text = cfgStr(cfg, 'min_version_admin');
    _urlUser.text = cfgStr(cfg, 'update_url_user');
    _urlAdmin.text = cfgStr(cfg, 'update_url_admin');
    _forceUser = cfgBool(cfg, 'force_user');
    _forceAdmin = cfgBool(cfg, 'force_admin');
  }

  Future<void> _save() async {
    await run(context, () => sb.rpc('dev_save_force_update', params: {
          'p_force': {
            'min_version_user': _minUser.text.trim(),
            'min_version_admin': _minAdmin.text.trim(),
            'update_url_user': _urlUser.text.trim(),
            'update_url_admin': _urlAdmin.text.trim(),
            'force_user': _forceUser,
            'force_admin': _forceAdmin,
          }
        }), ok: 'ফোর্স আপডেট সেটিংস সেভ হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Force Update')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator(color: devTeal));
            }
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text('ইউজার অ্যাপ', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
                devField(_minUser, 'সর্বনিম্ন ভার্সন (যেমন 1.0.1)'),
                devField(_urlUser, 'APK ডাউনলোড লিংক'),
                SwitchListTile(
                  value: _forceUser,
                  activeColor: devTeal,
                  title: const Text('ফোর্স আপডেট (বন্ধ থাকলে শুধু ব্যানার দেখাবে)', style: TextStyle(color: Colors.black, fontSize: 15)),
                  onChanged: (v) => setState(() => _forceUser = v),
                ),
                const Divider(height: 32),
                const Text('অ্যাডমিন অ্যাপ', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
                devField(_minAdmin, 'সর্বনিম্ন ভার্সন (যেমন 1.0.1)'),
                devField(_urlAdmin, 'APK ডাউনলোড লিংক'),
                SwitchListTile(
                  value: _forceAdmin,
                  activeColor: devTeal,
                  title: const Text('ফোর্স আপডেট (বন্ধ থাকলে শুধু ব্যানার দেখাবে)', style: TextStyle(color: Colors.black, fontSize: 15)),
                  onChanged: (v) => setState(() => _forceAdmin = v),
                ),
                const SizedBox(height: 20),
                tealBtn('SAVE', _save),
              ],
            );
          },
        ),
      );
}

// ===========================================================================
// ৫) ADMINS — is_admin=true প্রোফাইলের তালিকা (ফোন, নাম, ব্যান, শেষ
//    অ্যাক্টিভিটি)। নতুন অ্যাডমিন: Auth ইউজার আগে Dashboard-এ বানাতে হয়
//    (email: ফোন@amaresports.app, password: পাসকোড) — তারপর এখানে Add
//    করলে প্রোফাইলে is_admin=true বসে। (নোট: অ্যাডমিন অ্যাপের পাসকোড
//    স্ক্রিন থেকে "অন্য অ্যাকাউন্ট দিয়ে লগইন" বোতামটি সরিয়ে দেওয়া হয়েছে,
//    তাই নতুন অ্যাডমিনদের জন্য আলাদা লগইনের রাস্তা আপাতত নেই — দরকার হলে
//    পাসকোড দিয়েই চেনার ব্যবস্থা করতে হবে।)
// ===========================================================================

class DevAdminsPage extends StatefulWidget {
  const DevAdminsPage({super.key});
  @override
  State<DevAdminsPage> createState() => _DevAdminsPageState();
}

class _DevAdminsPageState extends State<DevAdminsPage> {
  late Future<Map<String, dynamic>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final admins = await sb.from('profiles').select().eq('is_admin', true).order('created_at', ascending: false) as List;
    Map<String, String> lastSeen = {};
    try {
      final logs = await sb.from('admin_activity_log').select('admin_phone, created_at').order('created_at', ascending: false).limit(200) as List;
      for (final l in logs) {
        final ph = '${l['admin_phone'] ?? ''}';
        lastSeen.putIfAbsent(ph, () => when(l['created_at']));
      }
    } catch (_) {}
    return {'admins': admins, 'lastSeen': lastSeen};
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _add() async {
    final m = await showForm(context, 'নতুন অ্যাডমিন', [
      const F('phone', 'মোবাইল নম্বর (01XXXXXXXXX)', number: true),
      const F('passcode', 'পাসকোড (৪ সংখ্যা)', number: true, obscure: true),
    ]);
    if (m == null || !mounted) return;
    final phone = m['phone'] ?? '';
    final code = m['passcode'] ?? '';
    if (!phoneRe.hasMatch(phone) || !passcodeRe.hasMatch(code)) {
      toast(context, 'সঠিক নম্বর ও ৪ সংখ্যার পাসকোড দিন');
      return;
    }
    final ok = await run(context, () => sb.rpc('dev_add_admin', params: {'p_phone': phone, 'p_passcode': code}),
        ok: 'অ্যাডমিন যোগ হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _ban(Map<String, dynamic> a, bool ban) async {
    final ok = await run(context, () => sb.rpc('dev_set_admin_banned', params: {'p_phone': a['phone'], 'p_ban': ban}),
        ok: ban ? 'অ্যাডমিন ব্যান হয়েছে' : 'ব্যান তুলে নেওয়া হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _resetPasscode(Map<String, dynamic> a) async {
    final m = await showForm(context, 'অ্যাডমিনের পাসকোড বদলান', [
      const F('pass', 'নতুন পাসকোড (৪ সংখ্যা)', number: true, obscure: true),
    ], ok: 'বদলান');
    if (m == null || !mounted) return;
    final p = m['pass'] ?? '';
    if (!passcodeRe.hasMatch(p)) {
      toast(context, 'পাসকোড ঠিক ৪ সংখ্যার হতে হবে');
      return;
    }
    await run(context, () => sb.rpc('dev_reset_admin_passcode', params: {'p_phone': a['phone'], 'p_new': p}),
        ok: 'অ্যাডমিনের পাসকোড বদলে গেছে');
  }

  Future<void> _remove(Map<String, dynamic> a) async {
    if (!await confirm(context, '${a['phone']} কে অ্যাডমিন থেকে সরাবেন? (প্রোফাইল থাকবে, শুধু অ্যাডমিন অধিকার যাবে)')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('dev_remove_admin', params: {'p_phone': a['phone']}), ok: 'অ্যাডমিন সরানো হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Admins')),
        floatingActionButton: FloatingActionButton(
          backgroundColor: devTeal,
          onPressed: _add,
          child: const Icon(Icons.add, color: Colors.white),
        ),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final admins = d['admins'] as List;
            final lastSeen = d['lastSeen'] as Map<String, String>;
            if (admins.isEmpty) {
              return const Center(child: Text('কোনো অ্যাডমিন নেই', style: TextStyle(color: Colors.black54)));
            }
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: admins.length,
              itemBuilder: (c, i) {
                final a = admins[i] as Map<String, dynamic>;
                final phone = '${a['phone'] ?? ''}';
                final banned = a['is_banned'] == true;
                return Card(
                  child: ListTile(
                    title: Text('${a['name'] ?? ''} • $phone'),
                    subtitle: Text(
                        '${banned ? 'ব্যানড • ' : ''}শেষ অ্যাক্টিভিটি: ${lastSeen[phone] ?? lastSeen['admin'] ?? '—'}'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'ban') _ban(a, true);
                        if (v == 'unban') _ban(a, false);
                        if (v == 'reset') _resetPasscode(a);
                        if (v == 'remove') _remove(a);
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'ban', child: Text('ব্যান করুন')),
                        PopupMenuItem(value: 'unban', child: Text('ব্যান তুলুন')),
                        PopupMenuItem(value: 'reset', child: Text('পাসকোড বদলান')),
                        PopupMenuItem(value: 'remove', child: Text('অ্যাডমিন থেকে সরান')),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
}

// ===========================================================================
// ৬) FEATURE CONTROL — app_config 'feature_toggles' (JSON অবজেক্ট)।
//    টগলগুলো শুধু এই প্যানেলেই আছে; বন্ধ ফিচার অ্যাডমিন/ইউজার অ্যাপে
//    লুকিয়ে যায়।
// ===========================================================================

const _toggleDefs = [
  ('admin_change_numbers', 'অ্যাডমিন: পেমেন্ট নম্বর বদলানো'),
  ('admin_send_money', 'অ্যাডমিন: Send Money'),
  ('admin_notice', 'অ্যাডমিন: নোটিশ'),
  ('admin_push', 'অ্যাডমিন: পুশ নোটিফিকেশন'),
  ('admin_match_create', 'অ্যাডমিন: ম্যাচ তৈরি'),
  ('admin_requests', 'অ্যাডমিন: ডিপোজিট/উইথড্র রিকোয়েস্ট'),
  ('user_withdraw', 'ইউজার: উইথড্র'),
  ('user_topup', 'ইউজার: Add Money'),
];

class DevTogglesPage extends StatefulWidget {
  const DevTogglesPage({super.key});
  @override
  State<DevTogglesPage> createState() => _DevTogglesPageState();
}

class _DevTogglesPageState extends State<DevTogglesPage> {
  late Future<Map<String, bool>> _f;
  var _vals = <String, bool>{};

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, bool>> _load() async {
    final cfg = await loadConfigMap();
    final t = cfg['feature_toggles'];
    final m = <String, bool>{};
    for (final def in _toggleDefs) {
      m[def.$1] = t is Map ? t[def.$1] != false : true;
    }
    _vals = m;
    return m;
  }

  Future<void> _save() async {
    await run(context, () => sb.rpc('dev_save_toggles', params: {'p_toggles': _vals}),
        ok: 'ফিচার টগল সেভ হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Feature Control')),
        body: Loader<Map<String, bool>>(
          future: _f,
          builder: (_) => ListView(
            padding: const EdgeInsets.all(12),
            children: [
              for (final def in _toggleDefs)
                SwitchListTile(
                  value: _vals[def.$1] ?? true,
                  activeColor: devTeal,
                  title: Text(def.$2, style: const TextStyle(color: Colors.black, fontSize: 16)),
                  onChanged: (v) => setState(() => _vals[def.$1] = v),
                ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: tealBtn('SAVE', _save),
              ),
            ],
          ),
        ),
      );
}

// ===========================================================================
// ৭) ADMIN ACTIVITY — admin_activity_log: কে কী করল, কখন। অ্যাডমিন ও
//    তারিখ দিয়ে ফিল্টার করা যায়, নতুনটা আগে।
// ===========================================================================

class DevActivityPage extends StatefulWidget {
  const DevActivityPage({super.key});
  @override
  State<DevActivityPage> createState() => _DevActivityPageState();
}

class _DevActivityPageState extends State<DevActivityPage> {
  final _date = TextEditingController();
  String? _adminFilter;
  List<String> _admins = [];
  late Future<List<dynamic>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
    _loadAdmins();
  }

  @override
  void dispose() {
    _date.dispose();
    super.dispose();
  }

  Future<void> _loadAdmins() async {
    try {
      final rows = await sb.from('admin_activity_log').select('admin_phone').order('created_at', ascending: false).limit(200) as List;
      final set = <String>{};
      for (final r in rows) {
        set.add('${r['admin_phone'] ?? ''}');
      }
      if (mounted) setState(() => _admins = set.toList());
    } catch (_) {}
  }

  Future<List<dynamic>> _load() async {
    dynamic q = sb.from('admin_activity_log').select().order('created_at', ascending: false).limit(100);
    if (_adminFilter != null && _adminFilter!.isNotEmpty) {
      q = q.eq('admin_phone', _adminFilter!);
    }
    final d = _date.text.trim();
    if (d.isNotEmpty) {
      final day = DateTime.tryParse(d);
      if (day != null) {
        final next = day.add(const Duration(days: 1));
        q = q.gte('created_at', day.toIso8601String()).lt('created_at', next.toIso8601String());
      }
    }
    return (await q) as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Admin Activity')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Row(children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _adminFilter,
                    decoration: const InputDecoration(labelText: 'অ্যাডমিন (সবাই)'),
                    items: [
                      const DropdownMenuItem(value: null, child: Text('সবাই')),
                      for (final a in _admins) DropdownMenuItem(value: a, child: Text(a)),
                    ],
                    onChanged: (v) {
                      setState(() => _adminFilter = v);
                      _refresh();
                    },
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 140,
                  child: TextField(
                    controller: _date,
                    decoration: const InputDecoration(labelText: 'তারিখ (YYYY-MM-DD)'),
                    onSubmitted: (_) => _refresh(),
                  ),
                ),
                IconButton(icon: const Icon(Icons.search, color: devTeal), onPressed: _refresh),
              ]),
            ),
            Expanded(
              child: Loader<List<dynamic>>(
                future: _f,
                builder: (list) => list.isEmpty
                    ? const Center(child: Text('কোনো অ্যাক্টিভিটি নেই', style: TextStyle(color: Colors.black54)))
                    : RefreshIndicator(
                        onRefresh: _refresh,
                        child: ListView.builder(
                          itemCount: list.length,
                          itemBuilder: (c, i) {
                            final l = list[i] as Map<String, dynamic>;
                            return ListTile(
                              title: Text('${l['admin_phone'] ?? ''} • ${l['action'] ?? ''}',
                                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                              subtitle: Text('${l['detail'] ?? ''}\n${when(l['created_at'])}',
                                  style: const TextStyle(color: Colors.black87)),
                              isThreeLine: true,
                            );
                          },
                        ),
                      ),
              ),
            ),
          ],
        ),
      );
}

// ===========================================================================
// ৮) USERS — ফোন নম্বর দিয়ে খোঁজা; ব্যালেন্স, ম্যাচ, কিল, জয়, ডিপোজিট /
//    উইথড্র মোট; ব্যান/আনব্যান, পাসওয়ার্ড রিসেট।
// ===========================================================================

class DevUsersPage extends StatefulWidget {
  const DevUsersPage({super.key});
  @override
  State<DevUsersPage> createState() => _DevUsersPageState();
}

class _DevUsersPageState extends State<DevUsersPage> {
  final _q = TextEditingController();
  List<dynamic> _results = [];
  var _searched = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _q.text.trim();
    if (q.isEmpty) {
      toast(context, 'ইউজারের নম্বর দিন');
      return;
    }
    final ok = await run(context, () async {
      final rows = await sb.from('profiles').select().ilike('phone', '%$q%').order('created_at', ascending: false).limit(20);
      _results = rows as List;
      _searched = true;
    });
    if (ok) setState(() {});
  }

  Future<void> _ban(Map<String, dynamic> u, bool ban) async {
    final ok = await run(context, () => sb.rpc('dev_set_user_banned', params: {'p_user': u['id'], 'p_ban': ban}),
        ok: ban ? 'ইউজার ব্যান হয়েছে' : 'ব্যান তুলে নেওয়া হয়েছে');
    if (ok) _search();
  }

  Future<void> _reset(Map<String, dynamic> u) async {
    final m = await showForm(context, 'পাসওয়ার্ড রিসেট', [const F('pass', 'নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)')], ok: 'রিসেট করুন');
    if (m == null || !mounted) return;
    final p = m['pass'] ?? '';
    if (p.length < 6) {
      toast(context, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }
    await run(context, () => sb.rpc('dev_reset_user_password', params: {'p_user': u['id'], 'p_new': p}),
        ok: 'পাসওয়ার্ড রিসেট হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Users')),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            children: [
              TextField(
                controller: _q,
                keyboardType: TextInputType.phone,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black, fontSize: 17),
                decoration: const InputDecoration(
                  hintText: "ইউজারের নম্বর দিয়ে খুঁজুন",
                  hintStyle: TextStyle(color: Colors.black87, fontSize: 16),
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                ),
                onSubmitted: (_) => _search(),
              ),
              const SizedBox(height: 14),
              tealBtn('খুঁজুন', _search),
              const SizedBox(height: 16),
              Expanded(
                child: _results.isEmpty
                    ? Center(child: Text(_searched ? 'কোনো ইউজার পাওয়া যায়নি' : '', style: const TextStyle(color: Colors.black54)))
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (c, i) {
                          final u = _results[i] as Map<String, dynamic>;
                          final banned = u['is_banned'] == true;
                          return Card(
                            child: ListTile(
                              title: Text('${u['name'] ?? ''} • ${u['phone'] ?? ''}'),
                              subtitle: Text(
                                  'জয়: ${u['total_wins'] ?? 0} • ম্যাচ: ${u['matches_played'] ?? 0} • কিল: ${u['total_kills'] ?? 0}${banned ? ' • ব্যানড' : ''}'),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'reset') _reset(u);
                                  if (v == 'ban') _ban(u, true);
                                  if (v == 'unban') _ban(u, false);
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'reset', child: Text('পাসওয়ার্ড রিসেট')),
                                  PopupMenuItem(value: 'ban', child: Text('ব্যান করুন')),
                                  PopupMenuItem(value: 'unban', child: Text('ব্যান তুলুন')),
                                ],
                              ),
                              onTap: () => Navigator.push(
                                  context, MaterialPageRoute(builder: (_) => DevUserDetailPage(u: u))),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      );
}

class DevUserDetailPage extends StatefulWidget {
  final Map<String, dynamic> u;
  const DevUserDetailPage({super.key, required this.u});
  @override
  State<DevUserDetailPage> createState() => _DevUserDetailPageState();
}

class _DevUserDetailPageState extends State<DevUserDetailPage> {
  late Future<Map<String, num>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  num _sum(List rows) {
    var s = 0;
    for (final r in rows) {
      s += (r['amount'] as num?)?.toInt() ?? 0;
    }
    return s;
  }

  Future<Map<String, num>> _load() async {
    final uid = widget.u['id'];
    final w = await sb.from('wallets').select('balance').eq('user_id', uid).maybeSingle().catchError((_) => null);    final dep = await sb.from('deposits').select('amount').eq('user_id', uid).eq('status', 'approved') as List;
    final depPend = await sb.from('deposits').select('id').eq('user_id', uid).eq('status', 'pending') as List;
    final wd = await sb.from('withdrawals').select('amount').eq('user_id', uid).eq('status', 'approved') as List;
    final wdPend = await sb.from('withdrawals').select('id').eq('user_id', uid).eq('status', 'pending') as List;
    return {
      'balance': (w as Map?)?['balance'] as num? ?? 0,
      'depTotal': _sum(dep),
      'depPending': depPend.length,
      'wdTotal': _sum(wd),
      'wdPending': wdPend.length,
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: Text('${widget.u['name'] ?? 'ইউজার'}')),
        body: Loader<Map<String, num>>(
          future: _f,
          builder: (m) => ListView(
            padding: const EdgeInsets.all(20),
            children: [
              ListTile(
                title: Text('${widget.u['name'] ?? ''} • ${widget.u['phone'] ?? ''}',
                    style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                subtitle: Text(
                    'জয়: ${widget.u['total_wins'] ?? 0} • ম্যাচ: ${widget.u['matches_played'] ?? 0} • কিল: ${widget.u['total_kills'] ?? 0}',
                    style: const TextStyle(color: Colors.black87)),
                trailing: Text('${m['balance']}৳',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black)),
              ),
              const Divider(),
              ListTile(title: const Text('মোট ডিপোজিট (approved)', style: TextStyle(color: Colors.black)), trailing: Text('${m['depTotal']}৳', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
              ListTile(title: const Text('মোট উইথড্র (approved)', style: TextStyle(color: Colors.black)), trailing: Text('${m['wdTotal']}৳', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
              ListTile(title: const Text('অপেক্ষমাণ ডিপোজিট', style: TextStyle(color: Colors.black)), trailing: Text('${m['depPending']}', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
              ListTile(title: const Text('অপেক্ষমাণ উইথড্র', style: TextStyle(color: Colors.black)), trailing: Text('${m['wdPending']}', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
            ],
          ),
        ),
      );
}

// ===========================================================================
// ৯) MONEY DASHBOARD — ডিপোজিট/উইথড্র মোট (approved), অপেক্ষমাণ সংখ্যা,
//    মাধ্যমভিত্তিক মোট (bKash/Nagad/Rocket), সব ইউজারের ব্যালেন্সের মোট।
// ===========================================================================

class DevMoneyPage extends StatefulWidget {
  const DevMoneyPage({super.key});
  @override
  State<DevMoneyPage> createState() => _DevMoneyPageState();
}

class _DevMoneyPageState extends State<DevMoneyPage> {
  late Future<Map<String, dynamic>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  num _sumAmt(List rows) {
    num s = 0;
    for (final r in rows) {
      s += (r['amount'] as num?) ?? 0;
    }
    return s;
  }

  Future<Map<String, dynamic>> _load() async {
    final depOk = await sb.from('deposits').select('amount, method').eq('status', 'approved').limit(1000) as List;
    final wdOk = await sb.from('withdrawals').select('amount, method').eq('status', 'approved').limit(1000) as List;
    final depPend = await sb.from('deposits').select('id').eq('status', 'pending') as List;
    final wdPend = await sb.from('withdrawals').select('id').eq('status', 'pending') as List;
    final wallets = await sb.from('wallets').select('balance').limit(1000) as List;
    final perMethod = <String, num>{'bkash': 0, 'nagad': 0, 'rocket': 0};
    for (final r in depOk) {
      final m = '${r['method'] ?? ''}';
      if (perMethod.containsKey(m)) perMethod[m] = perMethod[m]! + ((r['amount'] as num?) ?? 0);
    }
    num walletTotal = 0;
    for (final w in wallets) {
      walletTotal += (w['balance'] as num?) ?? 0;
    }
    return {
      'depTotal': _sumAmt(depOk),
      'wdTotal': _sumAmt(wdOk),
      'depPending': depPend.length,
      'wdPending': wdPend.length,
      'perMethod': perMethod,
      'walletTotal': walletTotal,
    };
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Widget _row(String label, String value, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: TextStyle(color: Colors.black, fontSize: 17, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
            Text(value, style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text('Money Dashboard'),
          actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _refresh)],
        ),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (m) {
            final per = m['perMethod'] as Map<String, num>;
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _row('মোট ডিপোজিট (approved)', '${m['depTotal']}৳', bold: true),
                _row('মোট উইথড্র (approved)', '${m['wdTotal']}৳', bold: true),
                _row('সব ইউজারের ব্যালেন্সের মোট', '${m['walletTotal']}৳', bold: true),
                const Divider(height: 28),
                _row('অপেক্ষমাণ ডিপোজিট', '${m['depPending']}টি'),
                _row('অপেক্ষমাণ উইথড্র', '${m['wdPending']}টি'),
                const Divider(height: 28),
                const Text('ডিপোজিট — মাধ্যম অনুযায়ী', style: TextStyle(color: Colors.black, fontSize: 17, fontWeight: FontWeight.bold)),
                _row('bKash', '${per['bkash']}৳'),
                _row('Nagad', '${per['nagad']}৳'),
                _row('Rocket', '${per['rocket']}৳'),
                const SizedBox(height: 12),
                const Text('দ্রষ্টব্য: মোটগুলো সর্বোচ্চ ১০০০টি রো পর্যন্ত গোনা হয়।',
                    style: TextStyle(color: Colors.black54, fontSize: 13)),
              ],
            );
          },
        ),
      );
}

// ===========================================================================
// ১০) NOTICES & PUSH — ঘোষণা পাঠানো (announcements টেবিল, অ্যাডমিনের
//     পুশ পেজের মতোই)।
// ===========================================================================

class DevPushPage extends StatefulWidget {
  const DevPushPage({super.key});
  @override
  State<DevPushPage> createState() => _DevPushPageState();
}

class _DevPushPageState extends State<DevPushPage> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  late Future<List<dynamic>> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('announcements').select().order('created_at', ascending: false).limit(20);
    return rows as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _send() async {
    final title = _title.text.trim();
    final body = _body.text.trim();
    if (title.isEmpty || body.isEmpty) {
      toast(context, 'Title ও Message দুটোই দিন');
      return;
    }
    final ok = await run(context, () => sb.from('announcements').insert({'title': title, 'body': body}),
        ok: 'নোটিফিকেশন পাঠানো হয়েছে');
    if (ok) {
      _title.clear();
      _body.clear();
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Notices & Push')),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            children: [
              const SizedBox(height: 24),
              const Icon(Icons.notifications, color: Colors.black, size: 84),
              const SizedBox(height: 32),
              TextField(
                controller: _title,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black, fontSize: 17),
                decoration: const InputDecoration(
                  hintText: 'Title',
                  hintStyle: TextStyle(color: Colors.black87, fontSize: 16),
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _body,
                maxLines: 3,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black, fontSize: 17),
                decoration: const InputDecoration(
                  hintText: 'Message',
                  hintStyle: TextStyle(color: Colors.black87, fontSize: 16),
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                ),
              ),
              const SizedBox(height: 18),
              tealBtn('SEND', _send),
              const SizedBox(height: 20),
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('আগের নোটিফিকেশন', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Loader<List<dynamic>>(
                  future: _f,
                  builder: (list) => list.isEmpty
                      ? const Center(child: Text('এখনো কিছু পাঠানো হয়নি', style: TextStyle(color: Colors.black54)))
                      : ListView.builder(
                          itemCount: list.length,
                          itemBuilder: (c, i) {
                            final a = list[i] as Map<String, dynamic>;
                            return ListTile(
                              title: Text('${a['title']}', style: const TextStyle(color: Colors.black)),
                              subtitle: Text('${a['body'] ?? ''}', style: const TextStyle(color: Colors.black54)),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      );
}

// ===========================================================================
// ১১) SETTINGS — পেমেন্ট নম্বর (bKash/Nagad/Rocket), সর্বনিম্ন ডিপোজিট ও
//     সর্বনিম্ন উইথড্র। নম্বর payment_numbers key-তে বসে (ইউজার অ্যাপের
//     Wallet এখান থেকেই পড়ে), সর্বনিম্ন অঙ্ক dev_settings key-তে।
// ===========================================================================

class DevSettingsPage extends StatefulWidget {
  const DevSettingsPage({super.key});
  @override
  State<DevSettingsPage> createState() => _DevSettingsPageState();
}

class _DevSettingsPageState extends State<DevSettingsPage> {
  final _bkash = TextEditingController();
  final _nagad = TextEditingController();
  final _rocket = TextEditingController();
  final _minDep = TextEditingController();
  final _minWd = TextEditingController();
  late Future<void> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _bkash.dispose();
    _nagad.dispose();
    _rocket.dispose();
    _minDep.dispose();
    _minWd.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cfg = await loadConfigMap();
    final nums = cfg['payment_numbers'];
    if (nums is Map) {
      _bkash.text = '${nums['bkash'] ?? ''}';
      _nagad.text = '${nums['nagad'] ?? ''}';
      _rocket.text = '${nums['rocket'] ?? ''}';
    }
    final ds = cfg['dev_settings'];
    if (ds is Map) {
      _minDep.text = '${ds['min_deposit'] ?? ''}';
      _minWd.text = '${ds['min_withdraw'] ?? ''}';
    } else {
      final ns = cfg['notice_settings'];
      if (ns is Map) _minWd.text = '${ns['minimum'] ?? ''}';
    }
  }

  Future<void> _save() async {
    await run(context, () => sb.rpc('dev_save_settings', params: {
          'p_settings': {
            'bkash': _bkash.text.trim(),
            'nagad': _nagad.text.trim(),
            'rocket': _rocket.text.trim(),
            'min_deposit': int.tryParse(_minDep.text.trim()) ?? 20,
            'min_withdraw': int.tryParse(_minWd.text.trim()) ?? 0,
          }
        }), ok: 'সেটিংস সেভ হয়েছে');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Settings')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator(color: devTeal));
            }
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text('পেমেন্ট নম্বর', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
                devField(_bkash, 'bKash Number', number: true),
                devField(_nagad, 'Nagad Number', number: true),
                devField(_rocket, 'Rocket Number', number: true),
                const SizedBox(height: 16),
                const Text('সর্বনিম্ন অঙ্ক', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
                devField(_minDep, 'সর্বনিম্ন ডিপোজিট (টাকা)', number: true),
                devField(_minWd, 'সর্বনিম্ন উইথড্র (টাকা)', number: true),
                const SizedBox(height: 20),
                tealBtn('SAVE', _save),
              ],
            );
          },
        ),
      );
}
