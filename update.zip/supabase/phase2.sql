-- ============================================================================
-- Amar E-sports — Phase 2 (ঐচ্ছিক ব্যাকএন্ড)
-- ============================================================================
-- এই ফাইলটি ঐচ্ছিক। অ্যাপের কোড (app/ ও admin_app/) এর কোনো জায়গা থেকেই
-- এই ফাইলের টেবিল বা RPC কল করা হয় না — তাই এটা না চালালেও অ্যাপ চলবে।
--
-- শুধুমাত্র যদি নোটিশ টেবিল, ডেইলি চেক-ইন বা রেফারেল ফিচার অ্যাপে যোগ
-- করতে চান, তবেই Supabase Dashboard > SQL Editor-এ গিয়ে এই ফাইলটি
-- চালাবেন, এবং তারপর অ্যাপের কোডে সংশ্লিষ্ট কল যোগ করতে হবে।
-- চালানোর আগে নিচের TODO জায়গাগুলো আপনার আসল স্কিমার সঙ্গে মিলিয়ে
-- নেবেন (কলামের নাম, অ্যাডমিন চেকের পদ্ধতি ইত্যাদি)।
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) নোটিশ টেবিল (notices)
-- বর্তমান অ্যাপ নোটিশ পড়ে app_config-এর 'notices' key থেকে; এই টেবিলটি
-- ভবিষ্যতে নোটিশ আলাদা টেবিলে রাখতে চাইলে ব্যবহার করবেন।
-- ----------------------------------------------------------------------------
create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  created_at timestamptz not null default now()
);

alter table public.notices enable row level security;

-- সবাই নোটিশ পড়তে পারবে।
drop policy if exists "notices read" on public.notices;
create policy "notices read" on public.notices
  for select using (true);

-- TODO: শুধু অ্যাডমিন লিখতে পারবে — নিচের শর্তটি আপনার অ্যাডমিন চেকের
-- সঙ্গে মিলিয়ে বদলে নিন (যেমন profiles.is_admin কলাম, অথবা
-- auth.jwt() -> 'app_metadata' ->> 'is_admin')।
drop policy if exists "notices write admin only" on public.notices;
create policy "notices write admin only" on public.notices
  for all using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
  );

-- ----------------------------------------------------------------------------
-- 2) ডেইলি চেক-ইন রিওয়ার্ড — RPC স্কেচ
-- ধারণা: ইউজার দিনে একবার চেক-ইন করলে ওয়ালেটে ছোট বোনাস যোগ হবে।
-- নিচের ফাংশনটি একটি খসড়া; চালানোর আগে wallets/ledger টেবিলের আসল
-- কলামের নামের সঙ্গে মিলিয়ে নিন, এবং বোনাসের অঙ্ক ঠিক করুন।
-- ----------------------------------------------------------------------------
-- create or replace function public.daily_checkin()
-- returns jsonb
-- language plpgsql
-- security definer
-- as $$
-- declare
--   v_uid uuid := auth.uid();
--   v_bonus int := 5; -- TODO: দৈনিক বোনাসের অঙ্ক
-- begin
--   if v_uid is null then
--     raise exception 'লগইন প্রয়োজন';
--   end if;
--   -- TODO: শেষ চেক-ইনের তারিখ কোথায় রাখবেন ঠিক করুন
--   -- (যেমন profiles.last_checkin_at কলাম), এবং একই দিনে দুবার
--   -- বোনাস যাতে না যায় সেই চেক এখানে যোগ করুন।
--   update public.wallets set balance = balance + v_bonus where user_id = v_uid;
--   insert into public.ledger (user_id, type, amount) values (v_uid, 'checkin', v_bonus);
--   return jsonb_build_object('bonus', v_bonus);
-- end;
-- $$;

-- ----------------------------------------------------------------------------
-- 3) রেফারেল — টেবিল + RPC স্কেচ
-- ধারণা: নতুন ইউজার কারো রেফারেল কোড দিয়ে জয়েন করলে, রেফারারকে
-- একবার বোনাস দেওয়া হবে। রেজিস্টার ফর্মে ইতিমধ্যে 'রেফারাল কোড
-- (ঐচ্ছিক)' ফিল্ড আছে, কিন্তু বোনাস দেওয়ার লজিক এখনো ব্যাকএন্ডে নেই।
-- ----------------------------------------------------------------------------
create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles (id),
  referred_id uuid not null references public.profiles (id),
  reward_paid boolean not null default false,
  created_at timestamptz not null default now(),
  unique (referred_id)
);

alter table public.referrals enable row level security;

-- নিজের রেফারেল রেকর্ড শুধু নিজে ও অ্যাডমিন দেখতে পারবে (খসড়া নীতি)।
drop policy if exists "referrals read own" on public.referrals;
create policy "referrals read own" on public.referrals
  for select using (referrer_id = auth.uid());

-- RPC স্কেচ: রেফারেল বোনাস দেওয়া (অ্যাডমিন বা সিস্টেম থেকে কল করবেন)।
-- create or replace function public.claim_referral_reward(p_referred uuid)
-- returns jsonb
-- language plpgsql
-- security definer
-- as $$
-- declare
--   v_ref record;
--   v_bonus int := 20; -- TODO: রেফারেল বোনাসের অঙ্ক
-- begin
--   select * into v_ref from public.referrals
--     where referred_id = p_referred and reward_paid = false;
--   if not found then
--     raise exception 'বোনাস দেওয়ার মতো রেফারেল নেই';
--   end if;
--   update public.wallets set balance = balance + v_bonus where user_id = v_ref.referrer_id;
--   insert into public.ledger (user_id, type, amount) values (v_ref.referrer_id, 'referral', v_bonus);
--   update public.referrals set reward_paid = true where id = v_ref.id;
--   return jsonb_build_object('bonus', v_bonus);
-- end;
-- $$;
