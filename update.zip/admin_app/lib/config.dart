const supabaseUrl = 'https://lvswoeczabkfspypxjvi.supabase.co';
// Public anon key (safe to ship in the app; security is enforced by RLS in the database).
const supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx2c3dvZWN6YWJrZnNweXB4anZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ4OTc0OTAsImV4cCI6MjExMDQ3MzQ5MH0.uYz7FR0a7-awJv-8PA2DPbMJkULQ9IfM9g43u4gruPE';
const phoneDomain = 'amaresports.app';

// অ্যাডমিন লগইন: শুধু ৪ সংখ্যার পাসকোড। অ্যাডমিনের Supabase অ্যাকাউন্টের
// ইমেইল এটাই; পাসওয়ার্ড হিসেবে পাসকোডটাই ব্যবহৃত হয় (নিচে দেখুন)।
const adminEmail = 'admin@amaresports.app';

// Supabase Auth-এর পাসওয়ার্ডে পাসকোডটাই বসে। খালি রাখলে পাসকোড নিজেই
// পাসওয়ার্ড। (দ্রষ্টব্য: Supabase Auth সাধারণত কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড
// চায় — ৪ সংখ্যার পাসওয়ার্ডে অ্যাকাউন্ট বানাতে না পারলে Dashboard >
// Authentication-এ সর্বনিম্ন দৈর্ঘ্য কমিয়ে নিন; আর তা-ও না হলে এখানে
// prefix বসান, যেমন 'amaresports-' — তাহলে অ্যাকাউন্টের পাসওয়ার্ড হবে
// prefix + পাসকোড, আর অ্যাপের কোড বদলাতে হবে না।)
const adminPasswordPrefix = '';
String adminAuthPassword(String passcode) => '$adminPasswordPrefix$passcode';
