import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'util.dart';

// ===========================================================================
// পুরনো (Kodular) অ্যাডমিন প্যানেলের মতো দেখতে হোম + ফর্ম।
// কালো ব্যাকগ্রাউন্ড, গাঢ় নেভি হেডার, বড় সাদা মেনু কার্ড, টিল বোতাম।
// ===========================================================================

/// পুরনো স্টাইলের টেক্সট ফিল্ড: মাঝখানে লেখা, নিচে টিল আন্ডারলাইন।
Widget oldField(
  TextEditingController c,
  String label, {
  bool number = false,
  int? maxLength,
}) =>
    TextField(
      controller: c,
      keyboardType: number ? TextInputType.number : TextInputType.text,
      maxLength: maxLength,
      textAlign: TextAlign.center,
      style: const TextStyle(color: Colors.white, fontSize: 18),
      inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
      decoration: InputDecoration(
        hintText: label,
        hintStyle: const TextStyle(color: Colors.white70, fontSize: 17),
        counterText: '',
        border: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
        enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
        focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal, width: 2)),
      ),
    );

/// সাদা ডায়ালগের ভেতরে মাঝখানে লেখা ফিল্ড (Send Money / পাসকোড ডায়ালগ)।
Widget dlgField(
  TextEditingController c,
  String label, {
  bool number = false,
  String? init,
}) =>
    TextField(
      controller: c,
      keyboardType: number ? TextInputType.number : TextInputType.text,
      textAlign: TextAlign.center,
      style: const TextStyle(color: Colors.black, fontSize: 17),
      inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
      decoration: InputDecoration(
        hintText: label,
        hintStyle: const TextStyle(color: Colors.black54, fontSize: 16),
        enabledBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          borderSide: BorderSide(color: adminTeal),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          borderSide: BorderSide(color: adminTeal, width: 2),
        ),
      ),
    );

/// পুরনো স্টাইলের টিল বোতাম।
Widget tealBtn(String label, VoidCallback? onTap, {double height = 52}) => SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: adminTeal,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child: Text(label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );

/// গাঢ় নেভি বোতাম (GET DATA / SEND / HOLD TO SEND)।
Widget darkBtn(String label, VoidCallback? onTap, {double height = 54}) => SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0A1230),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child: Text(label, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      ),
    );

/// পুরনো স্টাইলের পাসকোড ফিল্ড (CHANGE ADMIN PASSWORD ডায়ালগের জন্য):
/// মাঝখানে টিল লেবেল, নিচে টিল আন্ডারলাইন।
Widget passField(TextEditingController c, String label) => TextField(
      controller: c,
      obscureText: true,
      keyboardType: TextInputType.number,
      maxLength: 4,
      textAlign: TextAlign.center,
      style: const TextStyle(color: Colors.black, fontSize: 18),
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      decoration: InputDecoration(
        hintText: label,
        hintStyle: const TextStyle(color: adminTeal, fontSize: 17),
        counterText: '',
        border: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
        enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
        focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal, width: 2)),
      ),
    );

/// "CHANGE ADMIN PASSWORD" ডায়ালগ — পুরনো অ্যাপের মতো ঠিক দুটো ফিল্ড:
/// Old Password, New Password + SAVE / CANCEL (কনফার্ম ফিল্ড নেই)।
Future<void> showChangePasscodeDialog(BuildContext context) async {
  final oldC = TextEditingController();
  final newC = TextEditingController();
  final go = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: Colors.white,
      title: const Text(
        'CHANGE ADMIN PASSWORD',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 19),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          passField(oldC, 'Old Password'),
          const SizedBox(height: 18),
          passField(newC, 'New Password'),
          const SizedBox(height: 26),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: adminTeal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
              ),
              child: const Text('SAVE', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('CANCEL', style: TextStyle(color: adminTeal, fontSize: 16)),
        ),
      ],
    ),
  );
  if (go != true || !context.mounted) return;
  final oldP = oldC.text.trim();
  final newP = newC.text.trim();
  if (!passcodeRe.hasMatch(oldP) || !passcodeRe.hasMatch(newP)) {
    toast(context, 'দুটো পাসকোডই ঠিক ৪ সংখ্যার হতে হবে');
    return;
  }
  if (oldP == newP) {
    toast(context, 'নতুন পাসকোড আগেরটার মতোই');
    return;
  }
  final ok = await run(context, () async {
    // ১) পুরনো পাসকোড যাচাই।
    final verified = await sb.rpc('verify_admin_passcode', params: {'p_code': oldP});
    if (verified != true) throw Exception('ভুল পুরনো পাসকোড');
    // ২) Auth অ্যাকাউন্টের পাসওয়ার্ড বদলান — এটা না হলে app_config বদলানো যাবে না।
    await sb.auth.updateUser(UserAttributes(password: adminAuthPassword(newP)));
    // ৩) তারপর app_config-এ নতুন পাসকোড সেভ (ফাংশনের ভেতরে পুরনোটা আবার যাচাই হয়)।
    await sb.rpc('admin_set_passcode', params: {'p_old': oldP, 'p_new': newP});
  }, ok: 'পাসকোড বদলে গেছে');
  if (ok) {
    // নতুন পাসকোডে আবার লগইন করতে হবে — সেশন সাফ করে পাসকোড স্ক্রিনে ফেরত।
    await sb.auth.signOut();
  }
}

/// "Send Money to Users Wallet" ডায়ালগ — পুরনো অ্যাপের মতো:
/// User's Account Number, Amount, Winnings চেকবক্স, Kills (ডিফল্ট 0),
/// গাঢ় SEND বোতাম, Cancel।
Future<void> showSendMoneyDialog(BuildContext context) async {
  final phoneC = TextEditingController();
  final amtC = TextEditingController();
  final killsC = TextEditingController(text: '0');
  var winnings = false;
  final go = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text(
          'Send Money to Users Wallet',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              dlgField(phoneC, "User's Account Number", number: true),
              const SizedBox(height: 12),
              dlgField(amtC, 'Amount', number: true),
              CheckboxListTile(
                value: winnings,
                onChanged: (v) => set(() => winnings = v ?? false),
                title: const Text('Winnings', style: TextStyle(color: Colors.black, fontSize: 17)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                activeColor: adminTeal,
              ),
              Row(
                children: [
                  const Text('Kills:', style: TextStyle(color: Colors.black, fontSize: 16)),
                  const SizedBox(width: 10),
                  Expanded(child: dlgField(killsC, '', number: true)),
                ],
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0A1230),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                  child: const Text('SEND', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.black, fontSize: 16)),
          ),
        ],
      ),
    ),
  );
  if (go != true || !context.mounted) return;
  final phone = phoneC.text.trim();
  final amount = int.tryParse(amtC.text.trim());
  final kills = int.tryParse(killsC.text.trim()) ?? 0;
  if (!phoneRe.hasMatch(phone)) {
    toast(context, 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)');
    return;
  }
  if (amount == null || amount <= 0) {
    toast(context, 'সঠিক টাকার অঙ্ক দিন');
    return;
  }
  if (kills < 0) {
    toast(context, 'Kills ০ বা তার বেশি হতে হবে');
    return;
  }
  await run(context, () => sb.rpc('admin_send_money', params: {
        'p_phone': phone,
        'p_amount': amount,
        'p_note': '',
        'p_winnings': winnings,
        'p_kills': kills,
      }), ok: 'টাকা পাঠানো হয়েছে');
}

// ===========================================================================
// অ্যাডমিন হোম — পুরনো স্টাইলের বড় সাদা মেনু কার্ড, কোনো ট্যাব নেই।
// ===========================================================================

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  late Future<Map<String, int>> _statsF;

  @override
  void initState() {
    super.initState();
    _statsF = _loadStats();
  }

  Future<Map<String, int>> _loadStats() async {
    try {
      final users = await sb.from('profiles').select('id');
      final dep = await sb.from('deposits').select('id').eq('status', 'pending');
      final wd = await sb.from('withdrawals').select('id').eq('status', 'pending');
      final open = await sb.from('tournaments').select('id').eq('status', 'open');
      return {
        'users': (users as List).length,
        'dep': (dep as List).length,
        'wd': (wd as List).length,
        'open': (open as List).length,
      };
    } catch (_) {
      return {'users': 0, 'dep': 0, 'wd': 0, 'open': 0};
    }
  }

  void _push(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  /// ডিপোজিট/উইথড্র লিস্টের মতো ট্যাব-বডি উইজেটকে পেজ হিসেবে দেখানো।
  void _pushList(BuildContext context, String title, Widget body) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(title: Text(title)),
          body: body,
        ),
      ),
    );
  }

  Widget _menuCard(BuildContext context, IconData icon, String title, String? sub, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Row(
              children: [
                Icon(icon, color: Colors.black, size: 40),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(color: Colors.black, fontSize: 21, fontWeight: FontWeight.w900),
                      ),
                      if (sub != null)
                        Text(
                          sub,
                          style: const TextStyle(color: Colors.black87, fontSize: 14, fontWeight: FontWeight.w700),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _statChip(String label, int value) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF0B1B4A),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Text('$value', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Admin Panel'),
        actions: [
          IconButton(icon: const Icon(Icons.lock), onPressed: () => showChangePasscodeDialog(context)),
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () async {
              await sb.auth.signOut();
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(top: 10, bottom: 20),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: FutureBuilder<Map<String, int>>(
              future: _statsF,
              builder: (context, snap) {
                final m = snap.data ?? const {'users': 0, 'dep': 0, 'wd': 0, 'open': 0};
                return Row(
                  children: [
                    _statChip('ইউজার', m['users'] ?? 0),
                    const SizedBox(width: 8),
                    _statChip('ডিপোজিট', m['dep'] ?? 0),
                    const SizedBox(width: 8),
                    _statChip('উইথড্র', m['wd'] ?? 0),
                    const SizedBox(width: 8),
                    _statChip('চলমান ম্যাচ', m['open'] ?? 0),
                  ],
                );
              },
            ),
          ),
          // ডিপোজিট/উইথড্র রিভিউ — পুরনো স্ক্রিনশটে নেই, তবু দরকার;
          // তাই প্রথম দুটো কার্ড হিসেবে রাখা হলো।
          _menuCard(context, Icons.payments, 'DEPOSIT REQUESTS', null,
              () => _pushList(context, 'Deposit Requests', const AdminDeposits())),
          _menuCard(context, Icons.account_balance_wallet, 'WITHDRAW REQUESTS', null,
              () => _pushList(context, 'Withdraw Requests', const AdminWithdrawals())),
          _menuCard(context, Icons.sports_esports, 'FREE FIRE MATCH DETAILS', 'WITH REQUESTS',
              () => _push(context, const AdminGamePage(game: 'Free Fire'))),
          _menuCard(context, Icons.sports_esports, 'LUDU MATCH DETAILS', null,
              () => _push(context, const AdminGamePage(game: 'Ludo King'))),
          _menuCard(context, Icons.monetization_on, 'SEND MONEY', null, () => showSendMoneyDialog(context)),
          _menuCard(context, Icons.person_search, 'GET USER INFO', null, () => _push(context, const AdminUsers())),
          _menuCard(context, Icons.campaign, 'NOTICE', null, () => _push(context, const AdminNoticesPage())),
          _menuCard(context, Icons.notifications, 'PUSH NOTIFICATION', null, () => _push(context, const AdminPushPage())),
          _menuCard(context, Icons.description, 'FREE FIRE MATCH RULES', null,
              () => _push(context, const AdminRulesPage(game: 'ff'))),
          _menuCard(context, Icons.description, 'LUDU MATCH RULES', null,
              () => _push(context, const AdminRulesPage(game: 'ludo'))),
        ],
      ),
    );
  }
}

// ===========================================================================
// FREE FIRE / LUDU MATCH DETAILS — পুরনো অ্যাপের ফর্ম + নিচের নেভিগেশন
// (Matches | Add Money | Withdraw)।
// ===========================================================================

class AdminGamePage extends StatefulWidget {
  final String game; // 'Free Fire' বা 'Ludo King'
  const AdminGamePage({super.key, required this.game});
  @override
  State<AdminGamePage> createState() => _AdminGamePageState();
}

class _AdminGamePageState extends State<AdminGamePage> {
  bool get isFF => widget.game == 'Free Fire';
  var _tab = 0;
  var _busy = false;
  String? _loadedId;
  var _joined = 0;

  final _cardNo = TextEditingController();
  final _c = <String, TextEditingController>{};
  var _type = 'Solo';
  var _status = 'Not Started';

  static const _ffKeys = [
    'title', 'date', 'fee', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6',
    'perKill', 'seats', 'totalPrize', 'version', 'map', 'roomId', 'roomPw',
  ];
  static const _ludoKeys = [
    'title', 'date', 'fee', 'board', 'seats', 'prize', 'roomId', 'roomPw',
  ];

  @override
  void initState() {
    super.initState();
    for (final k in (isFF ? _ffKeys : _ludoKeys)) {
      _c[k] = TextEditingController();
    }
    _prefillNextCardNo();
  }

  @override
  void dispose() {
    _cardNo.dispose();
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  String _v(String key) => _c[key]?.text.trim() ?? '';
  int? _n(String key) => int.tryParse(_v(key));

  Future<void> _prefillNextCardNo() async {
    try {
      final rows = await sb.from('tournaments').select('card_no').not('card_no', 'is', null).order('card_no', ascending: false).limit(1);
      final list = rows as List;
      final maxNo = list.isEmpty ? 0 : (list.first['card_no'] as num?)?.toInt() ?? 0;
      if (mounted) setState(() => _cardNo.text = '${maxNo + 1}');
    } catch (_) {}
  }

  Future<int> _joinedCount(String tid) async {
    final rows = await sb.from('participants').select('id').eq('tournament_id', tid);
    return (rows as List).length;
  }

  /// Match Card Number দিয়ে ম্যাচ খুঁজে ফর্ম ভরে দেওয়া (GET DETAILS)।
  Future<void> _getDetails() async {
    final no = int.tryParse(_cardNo.text.trim());
    if (no == null) {
      toast(context, 'Match Card Number দিন');
      return;
    }
    setState(() => _busy = true);
    try {
      final row = await sb.from('tournaments').select().eq('card_no', no).maybeSingle();
      if (row == null) {
        setState(() {
          _loadedId = null;
          _joined = 0;
        });
        toast(context, 'এই নম্বরের ম্যাচ পাওয়া যায়নি — নতুন ম্যাচ হিসেবে সেভ হবে');
        return;
      }
      final t = row;
      _loadedId = '${t['id']}';
      _c['title']!.text = '${t['title'] ?? ''}';
      final st = t['starts_at'] == null ? null : DateTime.tryParse('${t['starts_at']}');
      _c['date']!.text = st == null ? '' : when(st);
      _c['fee']!.text = '${t['fee'] ?? ''}';
      _c['seats']!.text = '${t['slots'] ?? ''}';
      _type = '${t['mode'] ?? 'Solo'}';
      if (!['Solo', 'Duo', 'Squad', 'All'].contains(_type)) _type = 'Solo';
      final statusVal = '${t['status'] ?? 'open'}';
      _status = statusVal == 'live'
          ? 'Running'
          : (statusVal == 'finished' || statusVal == 'cancelled' ? 'Finished' : 'Not Started');
      if (isFF) {
        _c['totalPrize']!.text = '${t['prize_pool'] ?? ''}';
        _c['perKill']!.text = '${t['per_kill'] ?? ''}';
        _c['version']!.text = '${t['version'] ?? ''}';
        _c['map']!.text = '${t['board'] ?? ''}';
        final pr = t['prizes'];
        for (var i = 0; i < 6; i++) {
          _c['p${i + 1}']!.text = (pr is List && pr.length > i) ? '${pr[i]}' : '';
        }
      } else {
        _c['prize']!.text = '${t['prize_pool'] ?? ''}';
        _c['board']!.text = '${t['board'] ?? ''}';
      }
      try {
        final room = await sb.from('tournament_rooms').select().eq('tournament_id', _loadedId!).maybeSingle();
        if (room != null) {
          final r = room;
          _c['roomId']!.text = '${r['room_id'] ?? ''}';
          _c['roomPw']!.text = '${r['room_password'] ?? ''}';
        } else {
          _c['roomId']!.clear();
          _c['roomPw']!.clear();
        }
      } catch (_) {}
      final j = await _joinedCount(_loadedId!);
      if (mounted) {
        setState(() => _joined = j);
        toast(context, 'ম্যাচের তথ্য লোড হয়েছে');
      }
    } catch (e) {
      toast(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    final cardNo = int.tryParse(_cardNo.text.trim());
    if (cardNo == null) {
      toast(context, 'Match Card Number দিন');
      return;
    }
    // পুরনো অ্যাপের নিয়ম: কোনো কিছুই খালি রাখা যাবে না।
    final required = isFF
        ? ['title', 'date', 'fee', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'perKill', 'seats', 'totalPrize', 'version', 'map', 'roomId']
        : ['title', 'date', 'fee', 'board', 'seats', 'prize', 'roomId'];
    if (required.any((k) => _v(k).isEmpty)) {
      toast(context, 'কোনো কিছুই খালি রাখা যাবে না');
      return;
    }
    final fee = _n('fee');
    final seats = _n('seats');
    final totalPrize = isFF ? _n('totalPrize') : _n('prize');
    final perKill = isFF ? _n('perKill') : 0;
    final prizes = isFF ? [for (var i = 1; i <= 6; i++) _n('p$i')] : <int?>[];
    if (fee == null || seats == null || totalPrize == null || (isFF && (perKill == null || prizes.any((p) => p == null)))) {
      toast(context, 'সংখ্যার ঘরে সঠিক সংখ্যা দিন');
      return;
    }
    final start = DateTime.tryParse(_v('date').replaceFirst(' ', 'T'));
    if (start == null) {
      toast(context, 'তারিখ লিখুন এভাবে: 2026-11-21 18:00');
      return;
    }
    final statusVal = _status == 'Running' ? 'live' : (_status == 'Finished' ? 'finished' : 'open');
    final data = <String, dynamic>{
      'title': _v('title'),
      'game': widget.game,
      'mode': _type,
      'board': isFF ? _v('map') : _v('board'),
      'fee': fee,
      'prize_pool': totalPrize,
      'slots': seats,
      'starts_at': start.toUtc().toIso8601String(),
      'status': statusVal,
      'card_no': cardNo,
      'per_kill': perKill ?? 0,
      'version': isFF ? _v('version') : '',
      'prizes': isFF ? prizes.map((p) => p ?? 0).toList() : [],
    };
    setState(() => _busy = true);
    try {
      String tid;
      if (_loadedId != null) {
        await sb.from('tournaments').update(data).eq('id', _loadedId!);
        tid = _loadedId!;
      } else {
        final inserted = await sb.from('tournaments').insert(data).select('id').single();
        tid = '${inserted['id']}';
        _loadedId = tid;
      }
      // রুম আইডি/পাসওয়ার্ড (পুরনো অ্যাপে একটাই "INFO / ROOM ID PASS" ফিল্ড
      // ছিল; নতুন অ্যাপে ইউজার পেজে আলাদা দেখায় বলে দুটো ঘরে ভাগ করা হলো)।
      await sb.from('tournament_rooms').upsert({
        'tournament_id': tid,
        'room_id': _v('roomId'),
        'room_password': _v('roomPw'),
      }, onConflict: 'tournament_id');
      if (mounted) toast(context, 'সংরক্ষিত হয়েছে');
    } catch (e) {
      toast(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _showParticipants() async {
    if (_loadedId == null) {
      toast(context, 'আগে GET DETAILS দিয়ে ম্যাচ লোড করুন');
      return;
    }
    List<dynamic> players;
    try {
      players = await sb.from('participants').select().eq('tournament_id', _loadedId!).order('joined_at', ascending: true) as List;
    } catch (e) {
      toast(context, errText(e));
      return;
    }
    if (!mounted) return;
    final cleared = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Player List', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: players.isEmpty
                    ? const Text('কোনো প্লেয়ার নেই', style: TextStyle(color: Colors.black54))
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: players.length,
                        itemBuilder: (c, i) {
                          final p = players[i] as Map<String, dynamic>;
                          return ListTile(
                            title: Text('${p['name'] ?? ''}', style: const TextStyle(color: Colors.black)),
                            subtitle: Text('ID: ${p['game_id'] ?? ''}', style: const TextStyle(color: Colors.black54)),
                          );
                        },
                      ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final yes = await showDialog<bool>(
                      context: ctx,
                      builder: (c2) => AlertDialog(
                        title: const Text('সব প্লেয়ার মুছে ফেলবেন?'),
                        content: const Text('এই ম্যাচের সব জয়েন করা প্লেয়ার মুছে যাবে। টাকা ফেরত দেওয়া হবে না।'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(c2, false), child: const Text('না')),
                          TextButton(onPressed: () => Navigator.pop(c2, true), child: const Text('হ্যাঁ, মুছুন')),
                        ],
                      ),
                    );
                    if (yes == true) Navigator.pop(ctx, true);
                  },
                  icon: const Icon(Icons.delete, color: Colors.red),
                  label: const Text('CLEAR ALL PLAYERS', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.red, width: 1.5)),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CLOSE', style: TextStyle(color: Colors.black))),
        ],
      ),
    );
    if (cleared == true && mounted) {
      final ok = await run(context, () async {
        final n = await sb.rpc('admin_clear_players', params: {'p_tournament': _loadedId});
        return n;
      }, ok: 'সব প্লেয়ার মুছে ফেলা হয়েছে');
      if (ok && _loadedId != null) {
        setState(() => _joined = 0);
      }
    }
  }

  Widget _typeRow(String label) => Column(
        children: [
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 17)),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: ['Solo', 'Duo', 'Squad', 'All'].map((t) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Radio<String>(
                    value: t,
                    groupValue: _type,
                    onChanged: (v) => setState(() => _type = v ?? 'Solo'),
                    activeColor: adminTeal,
                    fillColor: WidgetStateProperty.resolveWith((_) => adminTeal),
                  ),
                  Text(t, style: const TextStyle(color: Colors.white, fontSize: 16)),
                  const SizedBox(width: 6),
                ],
              );
            }).toList(),
          ),
        ],
      );

  Widget _statusDropdown() => DropdownButtonFormField<String>(
        value: _status,
        dropdownColor: const Color(0xFF1A1A1A),
        style: const TextStyle(color: Colors.white, fontSize: 17),
        decoration: const InputDecoration(
          border: UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
          enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
        ),
        items: const ['Not Started', 'Running', 'Finished']
            .map((s) => DropdownMenuItem(value: s, child: Text(s)))
            .toList(),
        onChanged: (v) => setState(() => _status = v ?? 'Not Started'),
      );

  Widget _formTab() {
    final fields = <Widget>[];
    // Match Card Number + GET DETAILS
    fields.add(
      Center(
        child: Container(
          width: 300,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
          child: TextField(
            controller: _cardNo,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: InputDecoration(
              hintText: isFF ? 'Match Card Number' : 'Match Card No.',
              hintStyle: const TextStyle(color: Colors.black87, fontSize: 19, fontWeight: FontWeight.bold),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ),
    );
    fields.add(const SizedBox(height: 14));
    fields.add(
      Center(
        child: SizedBox(
          width: 300,
          height: 52,
          child: ElevatedButton(
            onPressed: _busy ? null : _getDetails,
            style: ElevatedButton.styleFrom(
              backgroundColor: adminTeal,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
            ),
            child: const Text('GET DETAILS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    );
    fields.add(const SizedBox(height: 8));
    fields.add(
      Align(
        alignment: Alignment.centerRight,
        child: TextButton.icon(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AdminTournaments(game: widget.game)),
          ),
          icon: const Icon(Icons.list, color: adminTeal, size: 18),
          label: const Text('ম্যাচের তালিকা', style: TextStyle(color: adminTeal)),
        ),
      ),
    );
    void add(String key, String label, {bool number = false}) {
      fields.add(oldField(_c[key]!, label, number: number));
      fields.add(const SizedBox(height: 18));
    }

    add('title', 'TITLE');
    add('date', 'DATE AND TIME');
    add('fee', 'ENTRY FEE', number: true);
    if (isFF) {
      for (var i = 1; i <= 6; i++) {
        add('p$i', '${['FIRST', 'SECOND', 'THIRD', 'FOURTH', 'FIFTH', 'SIXTH'][i - 1]} PRIZE', number: true);
      }
      add('perKill', 'PER KILL', number: true);
      add('seats', 'TOTAL SEAT', number: true);
      add('totalPrize', 'TOTAL PRIZE', number: true);
      add('version', 'VERSION');
    } else {
      add('board', 'BOARD TYPE');
      add('seats', 'TOTAL SEAT', number: true);
      add('prize', 'PRIZE', number: true);
    }
    fields.add(_typeRow(isFF ? 'TYPE' : 'JOINING TYPE'));
    fields.add(const SizedBox(height: 18));
    add('roomId', isFF ? 'INFO / ROOM ID PASS' : 'INFO / ROOM ID');
    add('roomPw', 'ROOM PASSWORD');
    fields.add(_statusDropdown());
    fields.add(const SizedBox(height: 20));
    fields.add(const Text(
      '*কোনো কিছুই খালি রাখা যাবে না',
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.white, fontSize: 16),
    ));
    fields.add(const SizedBox(height: 12));
    fields.add(tealBtn('SAVE', _busy ? null : _save));
    fields.add(const SizedBox(height: 22));
    fields.add(RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        style: const TextStyle(color: Colors.white, fontSize: 18),
        children: [
          const TextSpan(text: 'Joined Player '),
          TextSpan(text: '$_joined', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        ],
      ),
    ));
    fields.add(const SizedBox(height: 14));
    fields.add(
      SizedBox(
        width: double.infinity,
        height: 52,
        child: ElevatedButton(
          onPressed: _busy ? null : _showParticipants,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.grey[700],
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          ),
          child: const Text('Show Participants', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
      ),
    );

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
      children: fields,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(isFF ? 'FF Match Details' : 'LUDU Match Details', style: const TextStyle(fontSize: 22)),
            if (isFF) const Text('with Requests', style: TextStyle(fontSize: 14, fontWeight: FontWeight.normal)),
          ],
        ),
      ),
      body: IndexedStack(
        index: _tab,
        children: [
          _formTab(),
          const AdminDeposits(),
          const AdminWithdrawals(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: adminNavy,
        selectedItemColor: adminTeal,
        unselectedItemColor: Colors.white54,
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.sports_esports), label: 'Matches'),
          BottomNavigationBarItem(icon: Icon(Icons.payments), label: 'Add Money'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Withdraw'),
        ],
      ),
    );
  }
}

// ===========================================================================
// ডিপোজিট / উইথড্র রিকোয়েস্ট — পুরনো অ্যাপের স্টাইল:
// লাল "DELETE ALL REQUESTS" বোতাম, "Hold any number..." নোট, রো ধরে রাখলে
// Amount ডায়ালগ। পুরনো অ্যাপের "Bad arguments to +" ক্র্যাশটা এখানে নেই:
// অঙ্ক int.tryParse দিয়ে যাচাই করা হয়, খালি স্ট্রিংয়ের সঙ্গে যোগ হয় না।
// ===========================================================================

class AdminDeposits extends StatefulWidget {
  const AdminDeposits({super.key});
  @override
  State<AdminDeposits> createState() => _AdminDepositsState();
}

class _AdminDepositsState extends State<AdminDeposits> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('deposits').select('*, profiles(name, phone)').eq('status', 'pending').order('created_at', ascending: false);
    return rows as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _accept(Map<String, dynamic> d) async {
    final phone = '${(d['profiles'] as Map?)?['phone'] ?? d['sender_number'] ?? ''}';
    final amtC = TextEditingController(text: '${d['amount'] ?? ''}');
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: Text('Sending Money to $phone', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 17)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            dlgField(amtC, 'Amount', number: true),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                child: const Text('DONE', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('CANCEL', style: TextStyle(color: adminTeal, fontSize: 16))),
        ],
      ),
    );
    if (go != true || !mounted) return;
    final amount = int.tryParse(amtC.text.trim());
    if (amount == null || amount <= 0) {
      toast(context, 'সঠিক টাকার অঙ্ক দিন');
      return;
    }
    final ok = await run(context, () => sb.rpc('admin_accept_deposit', params: {'p_id': d['id'], 'p_amount': amount}), ok: 'টাকা পাঠানো হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _deleteAll() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সব রিকোয়েস্ট মুছে ফেলবেন?'),
        content: const Text('সব pending ডিপোজিট রিকোয়েস্ট মুছে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ, মুছুন')),
        ],
      ),
    );
    if (yes != true) return;
    final ok = await run(context, () => sb.rpc('admin_delete_all_requests', params: {'p_kind': 'deposit'}), ok: 'সব রিকোয়েস্ট মুছে ফেলা হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: OutlinedButton.icon(
              onPressed: _deleteAll,
              icon: const Icon(Icons.delete, color: Colors.red),
              label: const Text('DELETE ALL REQUESTS', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold)),
              style: OutlinedButton.styleFrom(
                backgroundColor: Colors.white,
                side: const BorderSide(color: Colors.red, width: 2),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Text('*Hold any number to Accept the Request', style: TextStyle(color: adminTeal, fontSize: 15, fontWeight: FontWeight.bold)),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh, color: adminTeal, size: 28))],
        ),
        Expanded(
          child: Loader<List<dynamic>>(
            future: _f,
            builder: (list) {
              if (list.isEmpty) {
                return const Center(child: Text('NO REQUESTS', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)));
              }
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(color: Colors.white24, height: 1),
                itemBuilder: (c, i) {
                  final d = list[i] as Map<String, dynamic>;
                  final phone = '${(d['profiles'] as Map?)?['phone'] ?? d['sender_number'] ?? ''}';
                  final method = '${d['method'] ?? ''}'.toUpperCase();
                  return InkWell(
                    onTap: () => toast(context, 'Accept করতে নম্বরটি চেপে ধরুন'),
                    onLongPress: () => _accept(d),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                      child: Center(
                        child: Text(
                          '$phone (${d['amount']} TK) - $method',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class AdminWithdrawals extends StatefulWidget {
  const AdminWithdrawals({super.key});
  @override
  State<AdminWithdrawals> createState() => _AdminWithdrawalsState();
}

class _AdminWithdrawalsState extends State<AdminWithdrawals> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('withdrawals').select('*, profiles(name, phone)').eq('status', 'pending').order('created_at', ascending: false);
    return rows as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _review(Map<String, dynamic> d) async {
    final phone = '${(d['profiles'] as Map?)?['phone'] ?? d['number'] ?? ''}';
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Withdraw Request', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: Text(
          '$phone\n${d['amount']} TK - ${'${d['method'] ?? ''}'.toUpperCase()}\nটাকা পাঠানো হয়েছে কি?',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black, fontSize: 17),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'reject'), child: const Text('রিজেক্ট', style: TextStyle(color: Colors.red))),
          TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('বাতিল', style: TextStyle(color: Colors.black54))),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, 'approve'),
            style: FilledButton.styleFrom(backgroundColor: adminTeal),
            child: const Text('পাঠানো হয়েছে'),
          ),
        ],
      ),
    );
    if (choice == null || !mounted) return;
    final ok = await run(
      context,
      () => sb.rpc('review_withdraw', params: {'p_id': d['id'], 'p_approve': choice == 'approve'}),
      ok: choice == 'approve' ? 'উইথড্র সম্পন্ন হয়েছে' : 'রিকোয়েস্ট রিজেক্ট হয়েছে',
    );
    if (ok) _refresh();
  }

  Future<void> _deleteAll() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সব রিকোয়েস্ট মুছে ফেলবেন?'),
        content: const Text('সব pending উইথড্র রিকোয়েস্ট মুছে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ, মুছুন')),
        ],
      ),
    );
    if (yes != true) return;
    final ok = await run(context, () => sb.rpc('admin_delete_all_requests', params: {'p_kind': 'withdraw'}), ok: 'সব রিকোয়েস্ট মুছে ফেলা হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: OutlinedButton.icon(
              onPressed: _deleteAll,
              icon: const Icon(Icons.delete, color: Colors.red),
              label: const Text('DELETE ALL REQUESTS', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold)),
              style: OutlinedButton.styleFrom(
                backgroundColor: Colors.white,
                side: const BorderSide(color: Colors.red, width: 2),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Text('*Hold any number to delete from list', style: TextStyle(color: adminTeal, fontSize: 15, fontWeight: FontWeight.bold)),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh, color: adminTeal, size: 28))],
        ),
        Expanded(
          child: Loader<List<dynamic>>(
            future: _f,
            builder: (list) {
              if (list.isEmpty) {
                return const Center(child: Text('NO REQUESTS', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)));
              }
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(color: Colors.white24, height: 1),
                itemBuilder: (c, i) {
                  final d = list[i] as Map<String, dynamic>;
                  final phone = '${(d['profiles'] as Map?)?['phone'] ?? d['number'] ?? ''}';
                  final method = '${d['method'] ?? ''}'.toUpperCase();
                  return InkWell(
                    onTap: () => toast(context, 'রিভিউ করতে নম্বরটি চেপে ধরুন'),
                    onLongPress: () => _review(d),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                      child: Center(
                        child: Text(
                          '$phone (${d['amount']} TK) - $method',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

// ===========================================================================
// ম্যাচের তালিকা (ম্যাচ ডিটেইলস পেজের "ম্যাচের তালিকা" থেকে খোলে)।
// ===========================================================================

class AdminTournaments extends StatefulWidget {
  final String? game; // null হলে সব গেম, না হলে ওই গেমের ম্যাচ
  const AdminTournaments({super.key, this.game});
  @override
  State<AdminTournaments> createState() => _AdminTournamentsState();
}

class _AdminTournamentsState extends State<AdminTournaments> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    dynamic q = sb.from('tournaments').select('*, tournament_rooms(room_id, room_password)').order('starts_at', ascending: false);
    if (widget.game != null) q = q.eq('game', widget.game!);
    return (await q) as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _create() async {
    final m = await showForm(context, 'নতুন ম্যাচ', [
      const F('title', 'টাইটেল'),
      const F('game', 'গেম', options: ['Free Fire', 'Ludo King']),
      const F('mode', 'মোড', options: ['Solo', 'Duo', 'Squad', 'All']),
      const F('board', 'ম্যাপ / বোর্ড'),
      const F('fee', 'এন্ট্রি ফি (টাকা)', number: true),
      const F('prize_pool', 'মোট পুরস্কার (টাকা)', number: true),
      const F('slots', 'মোট সিট', number: true),
      const F('starts_at', 'শুরুর সময় (YYYY-MM-DD HH:MM)'),
      const F('room_id', 'রুম আইডি'),
      const F('room_pw', 'রুম পাসওয়ার্ড'),
    ], init: {'game': widget.game ?? 'Free Fire', 'mode': 'Solo'});
    if (m == null || !mounted) return;
    final start = DateTime.tryParse(m['starts_at']!.replaceFirst(' ', 'T'));
    if (start == null) {
      toast(context, 'শুরুর সময়ের ফরম্যাট ঠিক করুন (YYYY-MM-DD HH:MM)');
      return;
    }
    final fee = int.tryParse(m['fee']!);
    final pool = int.tryParse(m['prize_pool']!);
    final slots = int.tryParse(m['slots']!);
    if (fee == null || pool == null || slots == null) {
      toast(context, 'ফি / পুরস্কার / সিটে সঠিক সংখ্যা দিন');
      return;
    }
    final ok = await run(context, () async {
      final ins = await sb.from('tournaments').insert({
        'title': m['title'],
        'game': m['game'],
        'mode': m['mode'],
        'board': m['board'],
        'fee': fee,
        'prize_pool': pool,
        'slots': slots,
        'starts_at': start.toUtc().toIso8601String(),
        'status': 'open',
      }).select('id').single();
      final tid = ins['id'];
      await sb.from('tournament_rooms').insert({'tournament_id': tid, 'room_id': m['room_id'], 'room_password': m['room_pw']});
    }, ok: 'ম্যাচ তৈরি হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(title: Text(widget.game == null ? 'সব ম্যাচ' : '${widget.game} ম্যাচ')),
        floatingActionButton: FloatingActionButton(
          backgroundColor: adminTeal,
          onPressed: _create,
          child: const Icon(Icons.add, color: Colors.white),
        ),
        body: Loader<List<dynamic>>(
          future: _f,
          builder: (list) => RefreshIndicator(
            onRefresh: _refresh,
            child: list.isEmpty
                ? ListView(children: [SizedBox(height: 120), Center(child: Text('কোনো ম্যাচ নেই', style: TextStyle(color: Colors.white70)))] )
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final t = list[i] as Map<String, dynamic>;
                      return Card(
                        color: const Color(0xFF111111),
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: ListTile(
                          title: Text('${t['title']}  •  ${t['game']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          subtitle: Text(
                            '${t['card_no'] != null ? 'Card #${t['card_no']}  •  ' : ''}${t['mode']} • ফি ${t['fee']}৳ • পুরস্কার ${t['prize_pool']}৳ • জয়েন ${t['joined'] ?? 0}/${t['slots']}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                          trailing: Text(statusLabel['${t['status'] ?? ''}'] ?? '${t['status'] ?? ''}', style: const TextStyle(color: adminTeal, fontWeight: FontWeight.bold)),
                          onTap: () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => AdminTournamentPage(t: t)));
                            _refresh();
                          },
                        ),
                      );
                    },
                  ),
          ),
        ),
      );
}

// ===========================================================================
// ম্যাচ পরিচালনা (তালিকা থেকে খোলে): স্ট্যাটাস, রেজাল্ট, পার্টিসিপ্যান্ট।
// ===========================================================================

class AdminTournamentPage extends StatefulWidget {
  final Map<String, dynamic> t;
  const AdminTournamentPage({super.key, required this.t});
  @override
  State<AdminTournamentPage> createState() => _AdminTournamentPageState();
}

class _AdminTournamentPageState extends State<AdminTournamentPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('participants').select('*, profiles(name, phone)').eq('tournament_id', widget.t['id']).order('joined_at', ascending: true);
    return rows as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _setStatus(String s) async {
    final ok = await run(context, () => sb.from('tournaments').update({'status': s}).eq('id', widget.t['id']), ok: 'স্ট্যাটাস বদলে গেছে');
    if (ok) Navigator.pop(context);
  }

  Future<void> _publish() async {
    final m = await showForm(context, 'রেজাল্ট প্রকাশ', [
      const F('w1', '১ম (ইউজার আইডি)'),
      const F('w2', '২য় (ইউজার আইডি)'),
      const F('w3', '৩য় (ইউজার আইডি)'),
    ]);
    if (m == null || !mounted) return;
    final winners = [m['w1'], m['w2'], m['w3']].where((e) => (e ?? '').trim().isNotEmpty).map((e) => e!.trim()).toList();
    if (winners.isEmpty) {
      toast(context, 'অন্তত একজন বিজয়ী দিন');
      return;
    }
    final ok = await run(context, () => sb.rpc('publish_result', params: {'p_tournament': widget.t['id'], 'p_winners': winners}), ok: 'রেজাল্ট প্রকাশ হয়েছে');
    if (ok) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ম্যাচ মুছে ফেলবেন?'),
        content: const Text('ম্যাচটি বাতিল হয়ে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ, মুছুন')),
        ],
      ),
    );
    if (yes != true) return;
    final ok = await run(context, () => sb.rpc('cancel_tournament', params: {'p_id': widget.t['id']}), ok: 'ম্যাচ বাতিল হয়েছে');
    if (ok) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(title: Text('${widget.t['title']}')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              ElevatedButton(onPressed: () => _setStatus('open'), style: ElevatedButton.styleFrom(backgroundColor: adminTeal), child: const Text('চালু করুন')),
              ElevatedButton(onPressed: () => _setStatus('live'), style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), child: const Text('লাইভ করুন')),
              ElevatedButton(onPressed: () => _setStatus('finished'), style: ElevatedButton.styleFrom(backgroundColor: Colors.grey[800]), child: const Text('শেষ করুন')),
              ElevatedButton(onPressed: _publish, style: ElevatedButton.styleFrom(backgroundColor: Colors.green), child: const Text('রেজাল্ট প্রকাশ')),
              ElevatedButton(onPressed: _delete, style: ElevatedButton.styleFrom(backgroundColor: Colors.red), child: const Text('বাতিল')),
            ]),
          ),
          Expanded(
            child: Loader<List<dynamic>>(
              future: _f,
              builder: (list) => RefreshIndicator(
                onRefresh: _refresh,
                child: list.isEmpty
                    ? ListView(children: [SizedBox(height: 80), Center(child: Text('কেউ জয়েন করেনি', style: TextStyle(color: Colors.white70)))] )
                    : ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (c, i) {
                          final p = list[i] as Map<String, dynamic>;
                          final prof = p['profiles'] as Map?;
                          return ListTile(
                            title: Text('${prof?['name'] ?? ''} • ${p['game_id'] ?? ''}', style: const TextStyle(color: Colors.white)),
                            subtitle: Text('${prof?['phone'] ?? ''}', style: const TextStyle(color: Colors.white70)),
                            trailing: Text('${p['kills'] ?? 0} কিল', style: const TextStyle(color: Colors.white70)),
                          );
                        },
                      ),
              ),
            ),
          ),
        ]),
      );
}

// ===========================================================================
// GET USER INFO — পুরনো অ্যাপের "User" পেজ: Total Users, নম্বর দিয়ে খোঁজা,
// SHOW ALL USERS।
// ===========================================================================

class AdminUsers extends StatefulWidget {
  const AdminUsers({super.key});
  @override
  State<AdminUsers> createState() => _AdminUsersState();
}

class _AdminUsersState extends State<AdminUsers> {
  final _q = TextEditingController();
  late Future<int> _totalF;
  List<dynamic> _results = [];
  var _searched = false;

  @override
  void initState() {
    super.initState();
    _totalF = _loadTotal();
  }

  Future<int> _loadTotal() async {
    final rows = await sb.from('profiles').select('id');
    return (rows as List).length;
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _q.text.trim();
    if (q.isEmpty) {
      toast(context, 'ইউজারের নম্বর দিন');
      return;
    }
    final ok = await run(context, () async {
      final rows = await sb.from('profiles').select().ilike('phone', '%$q%').order('created_at', ascending: false).limit(20);
      _results = rows as List;
      _searched = true;
    });
    if (ok) setState(() {});
  }

  Future<void> _showAll() async {
    List<dynamic> all;
    try {
      all = await sb.from('profiles').select('phone').order('created_at', ascending: false).limit(200) as List;
    } catch (e) {
      toast(context, errText(e));
      return;
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('All Users', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          height: 420,
          child: all.isEmpty
              ? const Center(child: Text('কোনো ইউজার নেই', style: TextStyle(color: Colors.black54)))
              : ListView.builder(
                  itemCount: all.length,
                  itemBuilder: (c, i) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(
                      '${(all[i] as Map<String, dynamic>)['phone'] ?? ''}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.black, fontSize: 16),
                    ),
                  ),
                ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CLOSE', style: TextStyle(color: Colors.black, fontSize: 16))),
        ],
      ),
    );
  }

  Future<void> _reset(Map<String, dynamic> u) async {
    final m = await showForm(context, 'পাসওয়ার্ড রিসেট', [const F('pass', 'নতুন পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)')], ok: 'রিসেট করুন');
    if (m == null || !mounted) return;
    final p = m['pass'] ?? '';
    if (p.length < 6) {
      toast(context, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      return;
    }
    await run(context, () => sb.rpc('admin_reset_password', params: {'p_user': u['id'], 'p_new': p}), ok: 'পাসওয়ার্ড রিসেট হয়েছে');
  }

  Future<void> _ban(Map<String, dynamic> u, bool ban) async {
    final ok = await run(context, () => sb.rpc('admin_ban_user', params: {'p_user': u['id'], 'p_ban': ban}), ok: ban ? 'ইউজার ব্যান হয়েছে' : 'ব্যান তুলে নেওয়া হয়েছে');
    if (ok) _search();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: const Text('User')),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Column(
          children: [
            FutureBuilder<int>(
              future: _totalF,
              builder: (context, snap) => Column(
                children: [
                  const Text('Total Users:', style: TextStyle(color: Colors.black, fontSize: 22)),
                  const SizedBox(height: 4),
                  Text('${snap.data ?? '—'}', style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 28),
            TextField(
              controller: _q,
              keyboardType: TextInputType.phone,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black, fontSize: 17),
              decoration: const InputDecoration(
                hintText: "Enter User's Number",
                hintStyle: TextStyle(color: Colors.black87, fontSize: 16),
                border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(height: 16),
            darkBtn('GET DATA', _search),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _showAll,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black54,
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                ),
                child: const Text('SHOW ALL USERS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _results.isEmpty
                  ? Center(child: Text(_searched ? 'কোনো ইউজার পাওয়া যায়নি' : '', style: const TextStyle(color: Colors.black54)))
                  : ListView.builder(
                      itemCount: _results.length,
                      itemBuilder: (c, i) {
                        final u = _results[i] as Map<String, dynamic>;
                        final banned = u['is_banned'] == true;
                        return Card(
                          child: ListTile(
                            title: Text('${u['name'] ?? ''} • ${u['phone'] ?? ''}'),
                            subtitle: Text('জয়: ${u['total_wins'] ?? 0} • কিল: ${u['total_kills'] ?? 0}${banned ? ' • ব্যানড' : ''}'),
                            trailing: PopupMenuButton<String>(
                              onSelected: (v) {
                                if (v == 'reset') _reset(u);
                                if (v == 'ban') _ban(u, true);
                                if (v == 'unban') _ban(u, false);
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'reset', child: Text('পাসওয়ার্ড রিসেট')),
                                PopupMenuItem(value: 'ban', child: Text('ব্যান করুন')),
                                PopupMenuItem(value: 'unban', child: Text('ব্যান তুলুন')),
                              ],
                            ),
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AdminUserDetailPage(u: u))),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class AdminUserDetailPage extends StatefulWidget {
  final Map<String, dynamic> u;
  const AdminUserDetailPage({super.key, required this.u});
  @override
  State<AdminUserDetailPage> createState() => _AdminUserDetailPageState();
}

class _AdminUserDetailPageState extends State<AdminUserDetailPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('ledger').select().eq('user_id', widget.u['id']).order('created_at', ascending: false).limit(50);
    return rows as List;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('${widget.u['name'] ?? 'ইউজার'}')),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: sb.from('wallets').select().eq('user_id', widget.u['id']).maybeSingle(),
          builder: (context, snap) {
            final w = snap.data;
            final bal = w == null ? null : (w['balance'] as num?)?.toInt();
            return Column(children: [
              ListTile(
                title: Text('${widget.u['name'] ?? ''} • ${widget.u['phone'] ?? ''}'),
                subtitle: Text('জয়: ${widget.u['total_wins'] ?? 0} • ম্যাচ: ${widget.u['matches_played'] ?? 0} • কিল: ${widget.u['total_kills'] ?? 0}'),
                trailing: Text(bal == null ? '—' : '$bal৳', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              const Divider(),
              Expanded(
                child: Loader<List<dynamic>>(
                  future: _f,
                  builder: (list) => ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final l = list[i] as Map<String, dynamic>;
                      final amt = (l['amount'] as num?)?.toInt() ?? 0;
                      return ListTile(
                        title: Text(ledgerLabel['${l['type'] ?? ''}'] ?? '${l['type'] ?? ''}'),
                        subtitle: Text(when(DateTime.tryParse('${l['created_at']}') ?? DateTime.now())),
                        trailing: Text('${amt >= 0 ? '+' : ''}$amt৳', style: TextStyle(color: amt >= 0 ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
                      );
                    },
                  ),
                ),
              ),
            ]);
          },
        ),
      );
}

// ===========================================================================
// NOTICE — পুরনো ডায়ালগের সেটিংস (Image URL / Visible / Minimum / Visible /
// bKash-Nogod-Rocket নম্বর + SET) + নোটিশের তালিকা।
// ===========================================================================

class AdminNoticesPage extends StatefulWidget {
  const AdminNoticesPage({super.key});
  @override
  State<AdminNoticesPage> createState() => _AdminNoticesPageState();
}

class _AdminNoticesPageState extends State<AdminNoticesPage> {
  late Future<List<Map<String, dynamic>>> _f;
  late Future<void> _settingsF;
  final _img = TextEditingController();
  final _min = TextEditingController();
  final _bkash = TextEditingController();
  final _nagad = TextEditingController();
  final _rocket = TextEditingController();
  var _imgVisible = false;
  var _minVisible = false;

  @override
  void initState() {
    super.initState();
    _f = _load();
    _settingsF = _loadSettings();
  }

  @override
  void dispose() {
    _img.dispose();
    _min.dispose();
    _bkash.dispose();
    _nagad.dispose();
    _rocket.dispose();
    super.dispose();
  }

  // নোটিশ লিস্ট থাকে app_config-এর 'notices' key-তে (update-9-এর মতোই) —
  // কোনো notices টেবিল নেই।
  Future<List<Map<String, dynamic>>> _load() async {
    final row = await sb.from('app_config').select('value').eq('key', 'notices').maybeSingle();
    final v = (row as Map?)?['value'];
    if (v is List) return [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)];
    return [];
  }

  Future<void> _loadSettings() async {
    try {
      final row = await sb.from('app_config').select('value').eq('key', 'notice_settings').maybeSingle();
      final m = (row as Map?)?['value'];
      if (m is Map) {
        _img.text = '${m['image_url'] ?? ''}';
        _imgVisible = m['image_visible'] == true;
        _min.text = '${m['minimum'] ?? ''}';
        _minVisible = m['minimum_visible'] == true;
        _bkash.text = '${m['bkash'] ?? ''}';
        _nagad.text = '${m['nagad'] ?? ''}';
        _rocket.text = '${m['rocket'] ?? ''}';
      }
    } catch (_) {}
  }

  Future<void> _saveSettings() async {
    final minVal = int.tryParse(_min.text.trim());
    final settings = <String, dynamic>{
      'image_url': _img.text.trim(),
      'image_visible': _imgVisible,
      'minimum': minVal ?? 0,
      'minimum_visible': _minVisible,
      'bkash': _bkash.text.trim(),
      'nagad': _nagad.text.trim(),
      'rocket': _rocket.text.trim(),
    };
    await run(context, () => sb.rpc('admin_save_notice_settings', params: {'p_settings': settings}), ok: 'নোটিশ সেটিংস সেভ হয়েছে');
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _saveList(List<Map<String, dynamic>> list) async {
    final ok = await run(context, () => sb.rpc('admin_save_notices', params: {'p_notices': list}), ok: 'নোটিশ সংরক্ষিত হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _add() async {
    final m = await showForm(context, 'নতুন নোটিশ', [const F('title', 'শিরোনাম'), const F('body', 'বিস্তারিত')]);
    if (m == null || !mounted) return;
    if ((m['title'] ?? '').isEmpty) {
      toast(context, 'শিরোনাম দিন');
      return;
    }
    final list = await _f;
    final now = DateTime.now();
    final date = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    list.insert(0, {'title': m['title'], 'body': m['body'] ?? '', 'date': date});
    await _saveList(list);
  }

  Future<void> _delete(int index) async {
    if (!await confirm(context, 'এই নোটিশটি মুছে ফেলবেন?')) return;
    if (!mounted) return;
    final list = await _f;
    list.removeAt(index);
    await _saveList(list);
  }

  Widget _setField(TextEditingController c, String label, {bool number = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: TextField(
          controller: c,
          keyboardType: number ? TextInputType.number : TextInputType.text,
          style: const TextStyle(color: Colors.black, fontSize: 16),
          inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
          decoration: InputDecoration(
            labelText: label,
            labelStyle: const TextStyle(color: Colors.black87),
            border: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
            enabledBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal)),
            focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: adminTeal, width: 2)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('নোটিশ')),
        floatingActionButton: FloatingActionButton(
          backgroundColor: adminTeal,
          onPressed: _add,
          child: const Icon(Icons.add, color: Colors.white),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('নোটিশ সেটিংস', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            FutureBuilder<void>(
              future: _settingsF,
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: adminTeal)));
                }
                return Column(
                  children: [
                    _setField(_img, 'Image URL (with https://) optional'),
                    Row(
                      children: [
                        const Text('Visible', style: TextStyle(color: Colors.black, fontSize: 16)),
                        Switch(value: _imgVisible, activeColor: adminTeal, onChanged: (v) => setState(() => _imgVisible = v)),
                      ],
                    ),
                    _setField(_min, 'Minimum', number: true),
                    Row(
                      children: [
                        const Text('Visible', style: TextStyle(color: Colors.black, fontSize: 16)),
                        Switch(value: _minVisible, activeColor: adminTeal, onChanged: (v) => setState(() => _minVisible = v)),
                      ],
                    ),
                    _setField(_bkash, 'bKash Number:', number: true),
                    _setField(_nagad, 'Nogod Number:', number: true),
                    _setField(_rocket, 'Rocket Number:', number: true),
                    const SizedBox(height: 12),
                    tealBtn('SET', _saveSettings),
                  ],
                );
              },
            ),
            const SizedBox(height: 24),
            const Divider(),
            const Text('নোটিশের তালিকা', style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Loader<List<Map<String, dynamic>>>(
              future: _f,
              builder: (list) => list.isEmpty
                  ? const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('কোনো নোটিশ নেই', style: TextStyle(color: Colors.black54))))
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: list.length,
                      itemBuilder: (c, i) {
                        final n = list[i];
                        return Card(
                          child: ListTile(
                            title: Text('${n['title']}'),
                            subtitle: Text('${n['body'] ?? ''}${n['date'] != null ? '\n${n['date']}' : ''}'),
                            isThreeLine: true,
                            trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => _delete(i)),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      );
}

// ===========================================================================
// PUSH NOTIFICATION — পুরনো অ্যাপের মতো: বেল আইকন, Title, Message,
// "HOLD TO SEND" (চেপে ধরে পাঠাতে হয়)।
// ===========================================================================

class AdminPushPage extends StatefulWidget {
  const AdminPushPage({super.key});
  @override
  State<AdminPushPage> createState() => _AdminPushPageState();
}

class _AdminPushPageState extends State<AdminPushPage> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  late Future<List<dynamic>> _f;
  var _holding = false;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<List<dynamic>> _load() async {
    final rows = await sb.from('announcements').select().order('created_at', ascending: false).limit(20);
    return rows as List;
  }

  Future<void> _refresh() async {
    final f = _load();
    setState(() => _f = f);
    await f;
  }

  Future<void> _send() async {
    final title = _title.text.trim();
    final body = _body.text.trim();
    if (title.isEmpty || body.isEmpty) {
      toast(context, 'Title ও Message দুটোই দিন');
      return;
    }
    final ok = await run(context, () => sb.from('announcements').insert({'title': title, 'body': body}), ok: 'নোটিফিকেশন পাঠানো হয়েছে');
    if (ok) {
      _title.clear();
      _body.clear();
      _refresh();
    }
  }

  Widget _pushField(TextEditingController c, String label, {int maxLines = 1}) => TextField(
        controller: c,
        maxLines: maxLines,
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.black, fontSize: 17),
        decoration: InputDecoration(
          hintText: label,
          hintStyle: const TextStyle(color: Colors.black87, fontSize: 16),
          border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Notification')),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            children: [
              const SizedBox(height: 24),
              const Icon(Icons.notifications, color: Colors.black, size: 84),
              const SizedBox(height: 32),
              _pushField(_title, 'Title'),
              const SizedBox(height: 14),
              _pushField(_body, 'Message', maxLines: 3),
              const SizedBox(height: 18),
              GestureDetector(
                onLongPressStart: (_) => setState(() => _holding = true),
                onLongPressEnd: (_) => setState(() => _holding = false),
                onLongPressCancel: () => setState(() => _holding = false),
                onLongPress: _send,
                child: Container(
                  width: double.infinity,
                  height: 56,
                  decoration: BoxDecoration(
                    color: _holding ? const Color(0xFF1A2450) : const Color(0xFF0A1230),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  alignment: Alignment.center,
                  child: const Text('HOLD TO SEND', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 10),
              const Text('পাঠাতে বোতামটি চেপে ধরে রাখুন', style: TextStyle(color: Colors.black54, fontSize: 13)),
              const SizedBox(height: 20),
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('আগের নোটিফিকেশন', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Loader<List<dynamic>>(
                  future: _f,
                  builder: (list) => list.isEmpty
                      ? const Center(child: Text('এখনো কিছু পাঠানো হয়নি', style: TextStyle(color: Colors.black54)))
                      : ListView.builder(
                          itemCount: list.length,
                          itemBuilder: (c, i) {
                            final a = list[i] as Map<String, dynamic>;
                            return ListTile(
                              title: Text('${a['title']}', style: const TextStyle(color: Colors.black)),
                              subtitle: Text('${a['body'] ?? ''}', style: const TextStyle(color: Colors.black54)),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      );
}

// ===========================================================================
// MATCH RULES — পুরনো অ্যাপের মতো: বড় টেক্সট ফিল্ড (placeholder DEFAULT),
// SAVE বোতাম। FF ও Ludo আলাদা কার্ড থেকে খোলে।
// ===========================================================================

class AdminRulesPage extends StatefulWidget {
  final String game; // 'ff' বা 'ludo'
  const AdminRulesPage({super.key, required this.game});
  @override
  State<AdminRulesPage> createState() => _AdminRulesPageState();
}

class _AdminRulesPageState extends State<AdminRulesPage> {
  final _c = TextEditingController();
  var _otherText = '';
  late Future<void> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  // নিয়ম থাকে app_config-এ আলাদা দুই key-তে (rules_ff / rules_ludo) —
  // এই পেজে শুধু এক গেমেরটা এডিট হয়, অন্যটা যেমন আছে তেমনই সেভ হয়।
  Future<void> _load() async {
    try {
      final rows = await sb.from('app_config').select('key, value').inFilter('key', ['rules_ff', 'rules_ludo']);
      final map = {for (final r in (rows as List)) '${r['key']}': r['value']};
      String txt(String k) {
        final v = map[k];
        if (v is String) return v;
        return v == null ? '' : '$v';
      }

      _c.text = widget.game == 'ff' ? txt('rules_ff') : txt('rules_ludo');
      _otherText = widget.game == 'ff' ? txt('rules_ludo') : txt('rules_ff');
    } catch (_) {}
  }

  Future<void> _save() async {
    final ok = await run(
        context,
        () => sb.rpc('admin_save_rules', params: {
              'p_ff': widget.game == 'ff' ? _c.text.trim() : _otherText,
              'p_ludo': widget.game == 'ludo' ? _c.text.trim() : _otherText,
            }),
        ok: 'নিয়ম সেভ হয়েছে');
    if (ok && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(title: Text(widget.game == 'ff' ? 'Free Fire Match Rules' : 'Ludo Match Rules')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator(color: adminTeal));
            }
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _c,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      style: const TextStyle(color: Colors.black, fontSize: 17),
                      decoration: const InputDecoration(
                        hintText: 'DEFAULT',
                        hintStyle: TextStyle(color: Colors.black38, fontSize: 17),
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  tealBtn('SAVE', _save),
                ],
              ),
            );
          },
        ),
      );
}
