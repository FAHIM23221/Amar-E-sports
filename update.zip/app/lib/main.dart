import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'util.dart';
import 'auth_screens.dart';
import 'home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Amar E-sports',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange, brightness: Brightness.dark),
        ),
        home: const AuthGate(),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (c, s) {
          final session = sb.auth.currentSession;
          if (session == null) return const LoginScreen();
          return ProfileGate(key: ValueKey(session.user.id));
        },
      );
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});
  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late Future<Map<String, dynamic>?> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>?> _load() =>
      sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: _f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (s.hasError) {
            return Scaffold(
              body: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(errText(s.error!)),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: _reload, child: const Text('আবার চেষ্টা করুন')),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
                ]),
              ),
            );
          }
          final p = s.data;
          if (p == null) return CompleteProfileScreen(onDone: _reload);
          if (p['banned'] == true) return const BannedScreen();
          return HomeShell(profile: p, onProfileChanged: _reload);
        },
      );
}
