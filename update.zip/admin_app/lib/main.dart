import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin.dart';
import 'config.dart';
import 'util.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  // অ্যাপ চালু হলেই পুরনো সেশন সাফ: পাসকোড স্ক্রিন এড়িয়ে যাওয়া যাবে না।
  try {
    await sb.auth.signOut();
  } catch (_) {}
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Amar E-sports Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: adminTeal, brightness: Brightness.dark),
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: adminNavy,
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      home: const AdminGate(),
    );
  }
}

class AdminGate extends StatelessWidget {
  const AdminGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, snap) {
        final session = snap.data?.session ?? sb.auth.currentSession;
        if (session == null) return const PasscodeLogin();
        return const AdminCheck();
      },
    );
  }
}

/// পাসকোড দিয়ে লগইন — পুরনো অ্যাপের স্ক্রিনের মতো: কালো ব্যাকগ্রাউন্ড,
/// সাদা তালার আইকন, একটাই "Passcode" ফিল্ড, টিল "Continue" বোতাম।
/// ফোন নম্বর বা পাসওয়ার্ডের কোনো ফিল্ড নেই।
class PasscodeLogin extends StatefulWidget {
  const PasscodeLogin({super.key});

  @override
  State<PasscodeLogin> createState() => _PasscodeLoginState();
}

class _PasscodeLoginState extends State<PasscodeLogin> {
  final _code = TextEditingController();
  var _busy = false;

  Future<void> _continue() async {
    final code = _code.text.trim();
    if (!passcodeRe.hasMatch(code)) {
      toast(context, '৪ সংখ্যার পাসকোড দিন');
      return;
    }
    setState(() => _busy = true);
    try {
      // প্রথমে পাসকোড যাচাই (সার্ভার-সাইড RPC)।
      final ok = await sb.rpc('verify_admin_passcode', params: {'p_code': code});
      if (ok != true) {
        toast(context, 'ভুল পাসকোড');
        _code.clear();
        return;
      }
      // পাসকোড ঠিক হলে ডেডিকেটেড অ্যাডমিন অ্যাকাউন্টে সাইন ইন
      // (পাসওয়ার্ড = পাসকোড)। এতে is_admin() ঠিকঠাক কাজ করে।
      await sb.auth.signInWithPassword(
        email: adminEmail,
        password: adminAuthPassword(code),
      );
    } catch (e) {
      toast(context, errText(e));
      _code.clear();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, color: Colors.white, size: 56),
              const SizedBox(height: 48),
              TextField(
                controller: _code,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 8),
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  hintText: 'Passcode',
                  hintStyle: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 0),
                  counterText: '',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: adminTeal, width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: adminTeal, width: 2),
                  ),
                ),
                onSubmitted: (_) => _continue(),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: _busy ? null : _continue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: adminTeal,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: _busy
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : const Text('Continue', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// সাইন ইন করা অ্যাকাউন্টটি সত্যিই অ্যাডমিন কি না যাচাই করে।
class AdminCheck extends StatelessWidget {
  const AdminCheck({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: sb.rpc('is_admin').then((v) => v == true).catchError((_) => false),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator(color: adminTeal)),
          );
        }
        if (snap.data == true) return const AdminHome();
        return Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('এই অ্যাকাউন্ট অ্যাডমিন নয়', style: TextStyle(color: Colors.white, fontSize: 18)),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                  onPressed: () async {
                    await sb.auth.signOut();
                  },
                  child: const Text('লগআউট'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
