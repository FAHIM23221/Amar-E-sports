import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final sb = Supabase.instance.client;
final phoneRe = RegExp(r'^01\d{9}$');
final passcodeRe = RegExp(r'^\d{4}$');
// ডেভেলপার প্যানেল অ্যাডমিন প্যানেলের মতোই: গাঢ় নেভি হেডার, কালো
// ব্যাকগ্রাউন্ড, বড় সাদা মেনু কার্ড, টিল বোতাম।
const devNavy = Color(0xFF030B2B);
const devTeal = Color(0xFF1FB6C9);
const methods = ['bkash', 'nagad', 'rocket'];

String emailOf(String phone) => '$phone@amaresports.app';

String errText(Object e) {
  String m;
  if (e is PostgrestException) {
    m = e.message;
  } else if (e is AuthException) {
    m = e.message;
  } else if (e is FormatException) {
    return 'সংখ্যা ঠিকভাবে লিখুন';
  } else {
    m = e.toString();
  }
  const map = {
    'Invalid login credentials': 'নম্বর বা পাসওয়ার্ড ভুল',
    'User already registered': 'এই নম্বর দিয়ে আগেই অ্যাকাউন্ট খোলা আছে',
    'Developer only': 'শুধু ডেভেলপার এটা করতে পারেন',
    'Admin only': 'শুধু অ্যাডমিন এটা করতে পারেন',
    'Auth user not found': 'Auth ইউজার পাওয়া যায়নি — Dashboard-এ আগে ইউজার বানান',
  };
  for (final e in map.entries) {
    if (m.contains(e.key)) return e.value;
  }
  return m;
}

void toast(BuildContext c, String m, {bool err = false}) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    content: Text(m),
    backgroundColor: err ? Colors.red.shade700 : null,
  ));
}

Future<bool> run(BuildContext c, Future<dynamic> Function() f, {String? ok}) async {
  try {
    await f();
    if (ok != null && c.mounted) toast(c, ok);
    return true;
  } catch (e) {
    if (c.mounted) toast(c, errText(e), err: true);
    return false;
  }
}

String taka(dynamic v) => '৳${v ?? 0}';

String when(dynamic iso) {
  if (iso == null) return '';
  final d = DateTime.tryParse(iso.toString())?.toLocal();
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
}

class F {
  final String key, label;
  final List<String>? options;
  final bool number, obscure;
  const F(this.key, this.label, {this.options, this.number = false, this.obscure = false});
}

Future<Map<String, String>?> showForm(BuildContext c, String title, List<F> fs,
    {String ok = 'ঠিক আছে', Map<String, String>? init}) {
  final ctrls = {
    for (final f in fs)
      f.key: TextEditingController(text: init?[f.key] ?? (f.options?.first ?? ''))
  };
  return showDialog<Map<String, String>>(
    context: c,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final f in fs)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: f.options != null
                    ? DropdownButtonFormField<String>(
                        value: ctrls[f.key]!.text,
                        decoration: InputDecoration(labelText: f.label),
                        items: [for (final o in f.options!) DropdownMenuItem(value: o, child: Text(o))],
                        onChanged: (v) => set(() => ctrls[f.key]!.text = v!),
                      )
                    : TextField(
                        controller: ctrls[f.key],
                        obscureText: f.obscure,
                        keyboardType: f.number ? TextInputType.number : TextInputType.text,
                        decoration: InputDecoration(labelText: f.label),
                      ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, {for (final e in ctrls.entries) e.key: e.value.text.trim()}),
            child: Text(ok),
          ),
        ],
      ),
    ),
  );
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ')),
      ],
    ),
  );
  return r == true;
}

class Loader<T> extends StatelessWidget {
  final Future<T> future;
  final Widget Function(T data) builder;
  const Loader({super.key, required this.future, required this.builder});
  @override
  Widget build(BuildContext context) => FutureBuilder<T>(
        future: future,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.hasError) {
            return Center(
                child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(errText(s.error!), textAlign: TextAlign.center),
            ));
          }
          return builder(s.data as T);
        },
      );
}
