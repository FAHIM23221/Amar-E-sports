import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'auth_screens.dart';
import 'home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Amar E-sports',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E6BFF), brightness: Brightness.dark),
          scaffoldBackgroundColor: navy,
          appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
          navigationBarTheme: const NavigationBarThemeData(backgroundColor: navy2),
          cardTheme: const CardThemeData(color: navy2),
        ),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  bool _done = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) setState(() => _done = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_done) return const StartupGate();
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Center(child: Image.asset('assets/images/logo.png', width: 150, height: 150)),
        ],
      ),
    );
  }
}

/// অ্যাপ চালুর গেট — প্রতিবার অ্যাপ খুললেই চলে (শুধু প্রথমবার নয়)।
/// মেইনটেন্যান্স চালু থাকলে ভেতরে ঢোকা যায় না; ফোর্স আপডেট থাকলে
/// আপডেট না করে ভেতরে ঢোকা যায় না; সফট আপডেট থাকলে হোমে ব্যানার দেখায়।
class StartupGate extends StatefulWidget {
  const StartupGate({super.key});
  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  late Future<RemoteGate> _f;
  @override
  void initState() {
    super.initState();
    _f = loadRemoteGate();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<RemoteGate>(
        future: _f,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final g = snap.data ?? const RemoteGate();
          if (g.maintenance) return MaintenanceScreen(message: g.maintenanceMessage);
          if (g.needsUpdate && g.forceUpdate) {
            return ForceUpdateScreen(url: g.updateUrl, minVersion: g.minVersion);
          }
          if (g.needsUpdate) {
            pendingSoftUpdate = SoftUpdate(g.minVersion, g.updateUrl);
          }
          return const AuthGate();
        },
      );
}

/// মেইনটেন্যান্স স্ক্রিন — লোগো + মেসেজ, ভেতরে ঢোকার কোনো উপায় নেই।
class MaintenanceScreen extends StatelessWidget {
  final String message;
  const MaintenanceScreen({super.key, required this.message});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo.png', width: 120, height: 120),
                  const SizedBox(height: 28),
                  const Icon(Icons.build, size: 44, color: Colors.black54),
                  const SizedBox(height: 16),
                  const Text('মেইনটেন্যান্স চলছে',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black)),
                  const SizedBox(height: 12),
                  Text(
                    message.isEmpty ? 'অ্যাপটি এখন মেইনটেন্যান্সে আছে। কিছুক্ষণ পর আবার চেষ্টা করুন।' : message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

/// ফোর্স আপডেট স্ক্রিন — আপডেট না করে ভেতরে ঢোকা যায় না।
class ForceUpdateScreen extends StatelessWidget {
  final String url;
  final String minVersion;
  const ForceUpdateScreen({super.key, required this.url, required this.minVersion});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo.png', width: 120, height: 120),
                  const SizedBox(height: 28),
                  const Text('নতুন আপডেট এসেছে',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 12),
                  Text(
                    'চালিয়ে যেতে $minVersion ভার্সনে আপডেট করুন।',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () => openUrl(context, url),
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1FB6C9), foregroundColor: Colors.white),
                      child: const Text('আপডেট করুন', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (c, s) {
          final session = sb.auth.currentSession;
          if (session == null) return const LoginScreen();
          return ProfileGate(key: ValueKey(session.user.id));
        },
      );
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});
  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late Future<Map<String, dynamic>?> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>?> _load() =>
      sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: _f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (s.hasError) {
            return Scaffold(
              body: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(errText(s.error!)),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: _reload, child: const Text('আবার চেষ্টা করুন')),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
                ]),
              ),
            );
          }
          final p = s.data;
          if (p == null) return CompleteProfileScreen(onDone: _reload);
          if (p['banned'] == true) return const BannedScreen();
          return HomeShell(profile: p, onProfileChanged: _reload);
        },
      );
}
