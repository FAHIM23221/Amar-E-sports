import 'package:flutter/material.dart';
import 'util.dart';

const ledgerLabel = {
  'deposit': 'ডিপোজিট',
  'join_fee': 'জয়েন ফি',
  'prize': 'প্রাইজ',
  'withdraw_hold': 'উইথড্র (আটকানো)',
  'withdraw_refund': 'উইথড্র ফেরত',
  'refund': 'ফি ফেরত',
};

class HomeShell extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onProfileChanged;
  const HomeShell({super.key, required this.profile, required this.onProfileChanged});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const MatchesPage(),
      const WalletPage(),
      ProfilePage(profile: widget.profile, onChanged: widget.onProfileChanged),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _i, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'ম্যাচ'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet), label: 'ওয়ালেট'),
          NavigationDestination(icon: Icon(Icons.person), label: 'প্রোফাইল'),
        ],
      ),
    );
  }
}

// ---------------- Matches ----------------
class MatchesPage extends StatefulWidget {
  const MatchesPage({super.key});
  @override
  State<MatchesPage> createState() => _MatchesPageState();
}

class _MatchesPageState extends State<MatchesPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb
      .from('tournaments')
      .select()
      .inFilter('status', ['open', 'live', 'finished'])
      .order('starts_at', ascending: false)
      .limit(50);

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  @override
  Widget build(BuildContext context) => Loader<List<dynamic>>(
        future: _f,
        builder: (list) => RefreshIndicator(
          onRefresh: _refresh,
          child: list.isEmpty
              ? ListView(children: const [SizedBox(height: 200), Center(child: Text('এখন কোনো ম্যাচ নেই'))])
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final t = list[i] as Map<String, dynamic>;
                    return Card(
                      child: ListTile(
                        title: Text('${t['title']}'),
                        subtitle: Text(
                            '${t['game']} • ${t['mode'] ?? ''}\nএন্ট্রি ${taka(t['fee'])} • প্রাইজ ${taka(t['prize_pool'])}\n${when(t['starts_at'])}'),
                        isThreeLine: true,
                        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text('${t['joined']}/${t['slots']}'),
                          Text(statusLabel[t['status']] ?? '${t['status']}', style: const TextStyle(fontSize: 12)),
                        ]),
                        onTap: () async {
                          await Navigator.push(c, MaterialPageRoute(builder: (_) => TournamentPage(id: '${t['id']}')));
                          _refresh();
                        },
                      ),
                    );
                  },
                ),
        ),
      );
}

class TournamentPage extends StatefulWidget {
  final String id;
  const TournamentPage({super.key, required this.id});
  @override
  State<TournamentPage> createState() => _TournamentPageState();
}

class _TournamentPageState extends State<TournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final me = sb.auth.currentUser!.id;
    final p = await sb.from('participants').select().eq('tournament_id', widget.id).eq('user_id', me).maybeSingle();
    Map<String, dynamic>? room;
    if (p != null) {
      room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    }
    return {'t': t, 'joined': p != null, 'room': room};
  }

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ম্যাচের বিবরণ')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final joined = d['joined'] == true;
            final room = d['room'] as Map<String, dynamic>?;
            final open = t['status'] == 'open' && (t['joined'] as int) < (t['slots'] as int);
            final me = sb.auth.currentUser!.id;
            int? myPrize;
            if (t['winners'] is List) {
              for (final w in t['winners']) {
                if (w['user_id'] == me) myPrize = (w['prize'] as num).toInt();
              }
            }
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('${t['title']}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('${t['game']} • ${t['mode'] ?? ''}'),
              Text('শুরু: ${when(t['starts_at'])}'),
              Text('এন্ট্রি ফি: ${taka(t['fee'])}'),
              Text('মোট প্রাইজ: ${taka(t['prize_pool'])}'),
              Text('স্লট: ${t['joined']}/${t['slots']}'),
              Text('অবস্থা: ${statusLabel[t['status']] ?? t['status']}'),
              const SizedBox(height: 16),
              if (myPrize != null)
                Card(child: ListTile(leading: const Icon(Icons.emoji_events), title: Text('আপনি জিতেছেন ${taka(myPrize)}'))),
              if (joined && room != null)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.key),
                    title: Text('রুম আইডি: ${room['room_id'] ?? '-'}'),
                    subtitle: Text('পাসওয়ার্ড: ${room['room_password'] ?? '-'}'),
                  ),
                ),
              if (joined && room == null)
                const Card(child: ListTile(leading: Icon(Icons.hourglass_top), title: Text('রুমের তথ্য শিগগির দেওয়া হবে'))),
              if (joined) const Card(child: ListTile(leading: Icon(Icons.check_circle), title: Text('আপনি এই ম্যাচে জয়েন করেছেন'))),
              if (!joined && open)
                FilledButton(
                  onPressed: () async {
                    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
                    if (!context.mounted) return;
                    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': widget.id}),
                        ok: 'জয়েন সফল হয়েছে');
                    if (ok) _reload();
                  },
                  child: const Text('জয়েন করুন'),
                ),
            ]);
          },
        ),
      );
}

// ---------------- Wallet ----------------
class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select().eq('user_id', me).single();
    final l = await sb.from('ledger').select().eq('user_id', me).order('created_at', ascending: false).limit(30);
    final d = await sb.from('deposits').select().eq('user_id', me).order('created_at', ascending: false).limit(10);
    final wd = await sb.from('withdrawals').select().eq('user_id', me).order('created_at', ascending: false).limit(10);
    final cfg = await sb.from('app_config').select().eq('key', 'payment_numbers').maybeSingle();
    return {'w': w, 'l': l, 'd': d, 'wd': wd, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _deposit(Map<String, dynamic>? cfg) async {
    final nums = (cfg?['value'] is Map) ? cfg!['value'] as Map : {};
    final info = nums.isEmpty ? '' : nums.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final m = await showForm(
      context,
      'টাকা যোগ করুন',
      const [
        F('method', 'মাধ্যম', options: methods),
        F('amount', 'টাকার পরিমাণ (২০ - ৫০,০০০)', number: true),
        F('trx', 'TrxID'),
        F('sender', 'যে নম্বর থেকে পাঠিয়েছেন', number: true),
      ],
      ok: 'জমা দিন',
    );
    if (m == null || !mounted) return;
    if (info.isNotEmpty) toast(context, 'পেমেন্ট নম্বর: $info');
    final ok = await run(context, () => sb.rpc('request_deposit', params: {
          'p_method': m['method'],
          'p_trx': m['trx'],
          'p_amount': int.parse(m['amount']!),
          'p_sender': m['sender'],
        }), ok: 'রিকোয়েস্ট জমা হয়েছে, অ্যাডমিন যাচাই করবেন');
    if (ok) _refresh();
  }

  Future<void> _withdraw() async {
    final m = await showForm(
      context,
      'টাকা তুলুন',
      const [
        F('method', 'মাধ্যম', options: methods),
        F('number', 'যে নম্বরে নিতে চান', number: true),
        F('amount', 'টাকার পরিমাণ', number: true),
      ],
      ok: 'রিকোয়েস্ট দিন',
    );
    if (m == null || !mounted) return;
    final ok = await run(context, () => sb.rpc('request_withdraw', params: {
          'p_method': m['method'],
          'p_number': m['number'],
          'p_amount': int.parse(m['amount']!),
        }), ok: 'উইথড্র রিকোয়েস্ট জমা হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        future: _f,
        builder: (d) {
          final w = d['w'] as Map<String, dynamic>;
          final l = d['l'] as List<dynamic>;
          final dep = d['d'] as List<dynamic>;
          final wd = d['wd'] as List<dynamic>;
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    const Text('আপনার ব্যালেন্স'),
                    Text(taka(w['balance']), style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
                  ]),
                ),
              ),
              Row(children: [
                Expanded(child: FilledButton(onPressed: () => _deposit(d['cfg'] as Map<String, dynamic>?), child: const Text('টাকা যোগ'))),
                const SizedBox(width: 12),
                Expanded(child: OutlinedButton(onPressed: _withdraw, child: const Text('টাকা তুলুন'))),
              ]),
              const SizedBox(height: 16),
              if (dep.any((e) => e['status'] == 'pending') || wd.any((e) => e['status'] == 'pending')) ...[
                const Text('অপেক্ষমাণ রিকোয়েস্ট', style: TextStyle(fontWeight: FontWeight.bold)),
                for (final e in dep.where((e) => e['status'] == 'pending'))
                  ListTile(dense: true, title: Text('ডিপোজিট ${taka(e['amount'])} (${e['method']})'), subtitle: Text('TrxID ${e['trx_id']}')),
                for (final e in wd.where((e) => e['status'] == 'pending'))
                  ListTile(dense: true, title: Text('উইথড্র ${taka(e['amount'])} (${e['method']})'), subtitle: Text('${e['number']}')),
                const SizedBox(height: 8),
              ],
              const Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.bold)),
              if (l.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('এখনো কোনো লেনদেন নেই')),
              for (final e in l)
                ListTile(
                  dense: true,
                  title: Text(ledgerLabel[e['type']] ?? '${e['type']}'),
                  subtitle: Text(when(e['created_at'])),
                  trailing: Text(
                    '${(e['amount'] as num) >= 0 ? '+' : ''}${e['amount']}',
                    style: TextStyle(color: (e['amount'] as num) >= 0 ? Colors.greenAccent : Colors.redAccent, fontWeight: FontWeight.bold),
                  ),
                ),
            ]),
          );
        },
      );
}

// ---------------- Profile ----------------
class ProfilePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const ProfilePage({super.key, required this.profile, required this.onChanged});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 40)),
        const SizedBox(height: 12),
        ListTile(title: const Text('নাম'), subtitle: Text('${profile['name']}')),
        ListTile(title: const Text('গেম আইডি'), subtitle: Text('${profile['game_id']}')),
        ListTile(title: const Text('মোবাইল'), subtitle: Text('${profile['phone']}')),
        ListTile(title: const Text('আপনার রেফারাল কোড'), subtitle: Text('${profile['referral_code']}')),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () async {
            final m = await showForm(context, 'প্রোফাইল এডিট', const [F('name', 'নাম'), F('game_id', 'গেম আইডি')],
                init: {'name': '${profile['name']}', 'game_id': '${profile['game_id']}'});
            if (m == null || !context.mounted) return;
            final ok = await run(context, () => sb.from('profiles').update({'name': m['name'], 'game_id': m['game_id']}).eq('id', sb.auth.currentUser!.id),
                ok: 'আপডেট হয়েছে');
            if (ok) onChanged();
          },
          child: const Text('এডিট করুন'),
        ),
        TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
      ]);
}
