-- ============================================================================
-- Amar E-sports — Update 9 ব্যাকএন্ড
-- ============================================================================
-- এই ফাইলটি চালাতে হবে: Supabase Dashboard > SQL Editor-এ পুরো ফাইলটি
-- পেস্ট করে Run করুন। এটা না চালালে অ্যাডমিনের নতুন সেকশনগুলো (Send Money,
-- নোটিশ ম্যানেজার, ঘোষণা, নিয়ম এডিটর) কাজ করবে না — অ্যাপ এরর দেখাবে।
--
-- ধরে নেওয়া স্কিমা (update-6/7/8-এর কোড অনুযায়ী):
--   profiles(id uuid, phone text, is_admin boolean, ...)
--   wallets(user_id uuid, balance numeric)
--   ledger(user_id uuid, type text, amount numeric, ...)
--   app_config(key text PRIMARY KEY, value jsonb)
-- আপনার প্রজেক্টে কলামের নাম আলাদা হলে নিচের TODO জায়গাগুলো মিলিয়ে নিন।
-- অ্যাডমিন চেক phase2.sql-এর মতোই profiles.is_admin দিয়ে করা হয়েছে।
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) announcements টেবিল — অ্যাডমিনের ঘোষণা (পুশ নোটিফিকেশন পেজ)
-- ইউজার অ্যাপের নোটিশ পেজ এই টেবিল থেকেও ঘোষণা পড়ে দেখায়।
-- ----------------------------------------------------------------------------
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null default '',
  created_at timestamptz not null default now()
);

alter table public.announcements enable row level security;

grant select on public.announcements to anon, authenticated;
grant insert on public.announcements to authenticated;

-- সবাই ঘোষণা পড়তে পারবে।
drop policy if exists "announcements read" on public.announcements;
create policy "announcements read" on public.announcements
  for select using (true);

-- শুধু অ্যাডমিন লিখতে / বদলাতে / মুছতে পারবে।
drop policy if exists "announcements write admin only" on public.announcements;
create policy "announcements write admin only" on public.announcements
  for all using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true)
  )
  with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true)
  );

-- ----------------------------------------------------------------------------
-- 2) admin_send_money — ফোন নম্বর দিয়ে ইউজারের ওয়ালেটে টাকা পাঠানো
-- অ্যাডমিন চেক, অঙ্ক > 0 যাচাই, ইউজার আছে কিনা যাচাই, তারপর ব্যালেন্স
-- বাড়ানো + ledger-এ 'admin_send' এন্ট্রি। p_note লেজারে কোনো নোট কলাম
-- না থাকায় সংরক্ষণ করা হয় না — শুধু ফর্মে অ্যাডমিনের রেফারেন্সের জন্য।
-- ----------------------------------------------------------------------------
create or replace function public.admin_send_money(p_phone text, p_amount numeric, p_note text default '')
returns jsonb
language plpgsql
security definer
as $$
declare
  v_uid uuid;
  v_balance numeric;
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount must be greater than 0';
  end if;
  select id into v_uid from public.profiles where phone = p_phone;
  if v_uid is null then
    raise exception 'ইউজার পাওয়া যায়নি';
  end if;
  update public.wallets set balance = balance + p_amount where user_id = v_uid;
  if not found then
    insert into public.wallets (user_id, balance) values (v_uid, p_amount);
  end if;
  insert into public.ledger (user_id, type, amount) values (v_uid, 'admin_send', p_amount);
  select balance into v_balance from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'balance', v_balance);
end;
$$;

grant execute on function public.admin_send_money(text, numeric, text) to authenticated;

-- ----------------------------------------------------------------------------
-- 3) admin_save_notices — app_config-এর 'notices' key-তে পুরো নোটিশ লিস্ট বসানো
-- অ্যাপ নোটিশ পড়ে এই key থেকেই, তাই এখানে সেভ করলেই ইউজার অ্যাপে দেখাবে।
-- ----------------------------------------------------------------------------
create or replace function public.admin_save_notices(p_notices jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_notices is null or jsonb_typeof(p_notices) <> 'array' then
    raise exception 'Notices must be a JSON array';
  end if;
  insert into public.app_config (key, value) values ('notices', p_notices)
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true, 'count', jsonb_array_length(p_notices));
end;
$$;

grant execute on function public.admin_save_notices(jsonb) to authenticated;

-- ----------------------------------------------------------------------------
-- 4) admin_save_rules — Free Fire ও Ludo নিয়ম app_config-এ বসানো
-- ইউজার অ্যাপের ম্যাচের নিয়ম পেজ পড়ে rules_ff / rules_ludo key থেকে।
-- ----------------------------------------------------------------------------
create or replace function public.admin_save_rules(p_ff text, p_ludo text)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  insert into public.app_config (key, value) values
    ('rules_ff', to_jsonb(p_ff)),
    ('rules_ludo', to_jsonb(p_ludo))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.admin_save_rules(text, text) to authenticated;
