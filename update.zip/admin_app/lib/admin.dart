import 'package:flutter/material.dart';
import 'util.dart';

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 4,
        child: Column(children: const [
          TabBar(isScrollable: true, tabs: [
            Tab(text: 'ডিপোজিট'),
            Tab(text: 'উইথড্র'),
            Tab(text: 'ম্যাচ'),
            Tab(text: 'ইউজার'),
          ]),
          Expanded(
            child: TabBarView(children: [
              AdminDeposits(),
              AdminWithdrawals(),
              AdminTournaments(),
              AdminUsers(),
            ]),
          ),
        ]),
      );
}

// ---------- Deposits ----------
class AdminDeposits extends StatefulWidget {
  const AdminDeposits({super.key});
  @override
  State<AdminDeposits> createState() => _AdminDepositsState();
}

class _AdminDepositsState extends State<AdminDeposits> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb
      .from('deposits')
      .select('*, profiles(name, phone)')
      .eq('status', 'pending')
      .order('created_at');

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _review(String id, bool approve) async {
    if (!await confirm(context, approve ? 'এই ডিপোজিট অ্যাপ্রুভ করবেন? ব্যালেন্সে টাকা যোগ হবে।' : 'রিজেক্ট করবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('review_deposit', params: {'p_id': id, 'p_approve': approve}),
        ok: approve ? 'অ্যাপ্রুভ হয়েছে' : 'রিজেক্ট হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Loader<List<dynamic>>(
        future: _f,
        builder: (list) => RefreshIndicator(
          onRefresh: _refresh,
          child: list.isEmpty
              ? ListView(children: const [SizedBox(height: 160), Center(child: Text('কোনো অপেক্ষমাণ ডিপোজিট নেই'))])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final d = list[i] as Map<String, dynamic>;
                    final p = d['profiles'] as Map<String, dynamic>?;
                    return Card(
                      child: ListTile(
                        title: Text('${taka(d['amount'])} • ${d['method']} • ${d['trx_id']}'),
                        subtitle: Text('${p?['name'] ?? ''} • ${p?['phone'] ?? ''}\nপাঠিয়েছে: ${d['sender_number']}\n${when(d['created_at'])}'),
                        isThreeLine: true,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.check_circle, color: Colors.green), onPressed: () => _review('${d['id']}', true)),
                          IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => _review('${d['id']}', false)),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ---------- Withdrawals ----------
class AdminWithdrawals extends StatefulWidget {
  const AdminWithdrawals({super.key});
  @override
  State<AdminWithdrawals> createState() => _AdminWithdrawalsState();
}

class _AdminWithdrawalsState extends State<AdminWithdrawals> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb
      .from('withdrawals')
      .select('*, profiles(name, phone)')
      .eq('status', 'pending')
      .order('created_at');

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _review(String id, bool paid) async {
    if (!await confirm(context, paid ? 'আপনি কি টাকা পাঠিয়ে দিয়েছেন? "পাঠানো হয়েছে" চিহ্নিত হবে।' : 'রিজেক্ট করলে টাকা ইউজারের ব্যালেন্সে ফেরত যাবে।')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('review_withdraw', params: {'p_id': id, 'p_approve': paid}),
        ok: paid ? 'পাঠানো হয়েছে চিহ্নিত' : 'রিজেক্ট ও টাকা ফেরত');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Loader<List<dynamic>>(
        future: _f,
        builder: (list) => RefreshIndicator(
          onRefresh: _refresh,
          child: list.isEmpty
              ? ListView(children: const [SizedBox(height: 160), Center(child: Text('কোনো অপেক্ষমাণ উইথড্র নেই'))])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final d = list[i] as Map<String, dynamic>;
                    final p = d['profiles'] as Map<String, dynamic>?;
                    return Card(
                      child: ListTile(
                        title: Text('${taka(d['amount'])} • ${d['method']} • ${d['number']}'),
                        subtitle: Text('${p?['name'] ?? ''} • ${p?['phone'] ?? ''}\n${when(d['created_at'])}'),
                        isThreeLine: true,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.send, color: Colors.green), onPressed: () => _review('${d['id']}', true)),
                          IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => _review('${d['id']}', false)),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ---------- Tournaments ----------
class AdminTournaments extends StatefulWidget {
  const AdminTournaments({super.key});
  @override
  State<AdminTournaments> createState() => _AdminTournamentsState();
}

class _AdminTournamentsState extends State<AdminTournaments> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb.from('tournaments').select().order('created_at', ascending: false).limit(60);

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _create() async {
    final m = await showForm(
      context,
      'নতুন ম্যাচ',
      const [
        F('title', 'ম্যাচের নাম'),
        F('mode', 'মোড', options: ['Solo', 'Duo', 'Squad']),
        F('fee', 'এন্ট্রি ফি (টাকা)', number: true),
        F('prize', 'মোট প্রাইজ (টাকা)', number: true),
        F('slots', 'মোট স্লট', number: true),
        F('start', 'শুরুর সময় (যেমন 2026-12-01 20:00)'),
        F('status', 'অবস্থা', options: ['draft', 'open']),
      ],
      ok: 'তৈরি করুন',
    );
    if (m == null || !mounted) return;
    final ok = await run(context, () async {
      final start = DateTime.tryParse(m['start']!.replaceFirst(' ', 'T'));
      if (m['title']!.isEmpty) throw 'ম্যাচের নাম দিন';
      await sb.from('tournaments').insert({
        'title': m['title'],
        'mode': m['mode'],
        'fee': int.parse(m['fee']!),
        'prize_pool': int.parse(m['prize']!),
        'slots': int.parse(m['slots']!),
        'starts_at': start?.toUtc().toIso8601String(),
        'status': m['status'],
      });
    }, ok: 'ম্যাচ তৈরি হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: _create, child: const Icon(Icons.add)),
        body: Loader<List<dynamic>>(
          future: _f,
          builder: (list) => RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (c, i) {
                final t = list[i] as Map<String, dynamic>;
                return Card(
                  child: ListTile(
                    title: Text('${t['title']}'),
                    subtitle: Text('${statusLabel[t['status']] ?? t['status']} • ${t['joined']}/${t['slots']} • ফি ${taka(t['fee'])}\n${when(t['starts_at'])}'),
                    isThreeLine: true,
                    onTap: () async {
                      await Navigator.push(c, MaterialPageRoute(builder: (_) => AdminTournamentPage(id: '${t['id']}')));
                      _refresh();
                    },
                  ),
                );
              },
            ),
          ),
        ),
      );
}

class AdminTournamentPage extends StatefulWidget {
  final String id;
  const AdminTournamentPage({super.key, required this.id});
  @override
  State<AdminTournamentPage> createState() => _AdminTournamentPageState();
}

class _AdminTournamentPageState extends State<AdminTournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final ps = await sb.from('participants').select().eq('tournament_id', widget.id).order('joined_at');
    final room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    return {'t': t, 'ps': ps, 'room': room};
  }

  void _reload() => setState(() => _f = _load());

  Future<void> _setStatus(String s) async {
    final ok = await run(context, () => sb.from('tournaments').update({'status': s}).eq('id', widget.id), ok: 'আপডেট হয়েছে');
    if (ok) _reload();
  }

  Future<void> _room(Map<String, dynamic>? room) async {
    final m = await showForm(context, 'রুমের তথ্য', const [F('rid', 'রুম আইডি'), F('rpw', 'রুম পাসওয়ার্ড')],
        init: {'rid': '${room?['room_id'] ?? ''}', 'rpw': '${room?['room_password'] ?? ''}'});
    if (m == null || !mounted) return;
    final ok = await run(context, () => sb.from('tournament_rooms').upsert({
          'tournament_id': widget.id,
          'room_id': m['rid'],
          'room_password': m['rpw'],
        }), ok: 'রুমের তথ্য সংরক্ষিত');
    if (ok) _reload();
  }

  Future<void> _cancel() async {
    if (!await confirm(context, 'ম্যাচ বাতিল করলে সবার এন্ট্রি ফি ফেরত যাবে। নিশ্চিত?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('cancel_tournament', params: {'p_tournament': widget.id}), ok: 'বাতিল ও ফি ফেরত হয়েছে');
    if (ok) _reload();
  }

  Future<void> _publish(List<dynamic> ps) async {
    final ctrls = {for (final p in ps) '${p['user_id']}': TextEditingController()};
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('বিজয়ীদের প্রাইজ'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: [
            for (final p in ps)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(
                  controller: ctrls['${p['user_id']}'],
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: '${p['name']} (${p['game_id']}) — প্রাইজ ৳'),
                ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('পাবলিশ করুন')),
        ],
      ),
    );
    if (go != true || !mounted) return;
    final winners = <Map<String, dynamic>>[];
    for (final e in ctrls.entries) {
      final v = int.tryParse(e.value.text.trim()) ?? 0;
      if (v > 0) winners.add({'user_id': e.key, 'prize': v});
    }
    if (winners.isEmpty) {
      toast(context, 'কমপক্ষে একজনের প্রাইজ দিন', err: true);
      return;
    }
    if (!await confirm(context, '${winners.length} জনকে প্রাইজ দিয়ে ম্যাচ শেষ করবেন? এটা ফেরানো যাবে না।')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('publish_result', params: {'p_tournament': widget.id, 'p_winners': winners}),
        ok: 'রেজাল্ট পাবলিশ হয়েছে');
    if (ok) _reload();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ম্যাচ ম্যানেজ')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final ps = d['ps'] as List<dynamic>;
            final room = d['room'] as Map<String, dynamic>?;
            final closed = t['status'] == 'finished' || t['status'] == 'cancelled';
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('${t['title']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Text('${statusLabel[t['status']] ?? t['status']} • ${t['joined']}/${t['slots']} • ফি ${taka(t['fee'])} • প্রাইজ ${taka(t['prize_pool'])}'),
              const SizedBox(height: 12),
              if (!closed)
                Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton(onPressed: () => _setStatus('open'), child: const Text('ওপেন')),
                  OutlinedButton(onPressed: () => _setStatus('live'), child: const Text('লাইভ')),
                  OutlinedButton(onPressed: () => _room(room), child: const Text('রুমের তথ্য')),
                  FilledButton(onPressed: ps.isEmpty ? null : () => _publish(ps), child: const Text('রেজাল্ট দিন')),
                  TextButton(onPressed: _cancel, child: const Text('বাতিল ও ফেরত', style: TextStyle(color: Colors.redAccent))),
                ]),
              if (room != null) ListTile(title: Text('রুম: ${room['room_id']}'), subtitle: Text('পাসওয়ার্ড: ${room['room_password']}')),
              const Divider(),
              Text('জয়েন করেছে (${ps.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
              for (final p in ps) ListTile(dense: true, title: Text('${p['name']}'), subtitle: Text('${p['game_id']}')),
            ]);
          },
        ),
      );
}

// ---------- Users ----------
class AdminUsers extends StatefulWidget {
  const AdminUsers({super.key});
  @override
  State<AdminUsers> createState() => _AdminUsersState();
}

class _AdminUsersState extends State<AdminUsers> {
  final _q = TextEditingController();
  Future<List<dynamic>>? _f;

  void _search() {
    final q = _q.text.trim();
    if (q.isEmpty) return;
    setState(() => _f = sb.from('profiles').select('*, wallets(balance)').ilike('phone', '%$q%').limit(20));
  }

  dynamic _bal(Map<String, dynamic> p) {
    final w = p['wallets'];
    if (w is List) return w.isEmpty ? 0 : w.first['balance'];
    if (w is Map) return w['balance'];
    return 0;
  }

  Future<void> _reset(Map<String, dynamic> p) async {
    final m = await showForm(context, 'নতুন পাসওয়ার্ড (${p['phone']})', const [F('pw', 'নতুন পাসওয়ার্ড (কমপক্ষে ৬)')]);
    if (m == null || !mounted) return;
    await run(context, () => sb.rpc('admin_reset_password', params: {'p_user': p['id'], 'p_new_password': m['pw']}),
        ok: 'পাসওয়ার্ড বদলানো হয়েছে, ইউজারকে জানিয়ে দিন');
  }

  Future<void> _ban(Map<String, dynamic> p) async {
    final ban = p['banned'] != true;
    if (!await confirm(context, ban ? '${p['name']}-কে ব্যান করবেন?' : 'ব্যান তুলে নেবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('admin_set_banned', params: {'p_user': p['id'], 'p_banned': ban}), ok: 'সম্পন্ন');
    if (ok) _search();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _q,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'মোবাইল নম্বর দিয়ে খুঁজুন', border: OutlineInputBorder()),
                onSubmitted: (_) => _search(),
              ),
            ),
            IconButton(onPressed: _search, icon: const Icon(Icons.search)),
          ]),
        ),
        Expanded(
          child: _f == null
              ? const Center(child: Text('নম্বর লিখে সার্চ করুন'))
              : Loader<List<dynamic>>(
                  future: _f!,
                  builder: (list) => ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final p = list[i] as Map<String, dynamic>;
                      return Card(
                        child: ListTile(
                          title: Text('${p['name']} • ${p['phone']}'),
                          subtitle: Text('গেম আইডি ${p['game_id']} • ব্যালেন্স ${taka(_bal(p))}${p['banned'] == true ? ' • ব্যান' : ''}'),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) => v == 'pw' ? _reset(p) : _ban(p),
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'pw', child: Text('পাসওয়ার্ড রিসেট')),
                              PopupMenuItem(value: 'ban', child: Text(p['banned'] == true ? 'আনব্যান' : 'ব্যান')),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ]);
}
