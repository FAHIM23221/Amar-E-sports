-- ============================================================================
-- Amar E-sports — Update 16 ব্যাকএন্ড (Developer অ্যাপ)
-- ============================================================================
-- চালানোর ক্রম: update9.sql, তারপর update10.sql, তারপর এই ফাইলটি।
-- Supabase Dashboard > SQL Editor-এ পুরো ফাইলটি পেস্ট করে Run করুন।
--
-- এককালীন সেটআপ (শুধু একবার, Supabase Dashboard-এ):
--   ১. Authentication > Users > Add user:
--        Email:    dev@amaresports.app
--        Password: 1234
--      (দ্রষ্টব্য: Supabase Auth সাধারণত কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড চায়।
--      ৪ সংখ্যার পাসওয়ার্ডে ইউজার বানাতে না পারলে Dashboard >
--      Authentication-এ সর্বনিম্ন দৈর্ঘ্য কমিয়ে নিন — অ্যাডমিন অ্যাকাউন্টের
--      মতোই। আর তা-ও না হলে developer_app/lib/config.dart-এ
--      developerPasswordPrefix বসাতে হবে এবং অ্যাকাউন্টটি সেই
--      পাসওয়ার্ড দিয়ে বানাতে হবে।)
--   ২. ওই অ্যাকাউন্টের প্রোফাইলে is_developer = true করুন:
--        update public.profiles set is_developer = true
--        where phone = 'dev@amaresports.app'::text;  -- অথবা id দিয়ে
--      (প্রোফাইল রো না থাকলে ইমেইল দিয়ে প্রোফাইল তৈরি করে
--      is_developer=true দিন।)
--   ৩. প্রথম লগইনের পরপরই ডেভেলপার প্যানেলের তালা আইকন থেকে পাসকোড
--      বদলে নিন — ডিফল্ট পাসকোড 1234।
--   ৪. admin@amaresports.app অ্যাকাউন্টটি আগের মতোই থাকবে (update10.sql
--      দেখুন)।
--
-- নতুন অ্যাডমিন যোগ করা (Developer অ্যাপ > Admins):
--   • Auth ইউজারটি আগে Dashboard-এ বানাতে হয় (অ্যাপ থেকে অন্যের Auth
--     ইউজার বানানো যায় না — supabase_flutter-এর signUp নিজের সেশন
--     বদলে ফেলে)। Email: <ফোন নম্বর>@amaresports.app, Password: ৪
--     সংখ্যার পাসকোড। অথবা ইউজারটি ইউজার অ্যাপে রেজিস্টার করে থাকলে
--     (তখন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হবে) সেই অ্যাকাউন্টই চলবে।
--   • তারপর Developer অ্যাপে Add Admin-এ ফোন + পাসকোড দিলে
--     dev_add_admin প্রোফাইলে is_admin=true বসায়।
--   • নতুন অ্যাডমিন লগইন করে অ্যাডমিন অ্যাপের পাসকোড স্ক্রিনের নিচের
--     "অন্য অ্যাকাউন্ট দিয়ে লগইন" দিয়ে (ফোন + পাসকোড)।
--
-- এই ফাইলে যা আছে:
--   • verify_developer_passcode / admin_set_developer_passcode —
--     ডেভেলপার পাসকোড লগইন (অ্যাডমিনের মতোই, key 'developer_passcode')
--   • is_developer() / is_admin() হেল্পার
--   • admin_activity_log টেবিল + RLS (অ্যাডমিন লেখে, ডেভেলপার পড়ে)
--   • dev_save_banners / dev_save_contacts / dev_save_maintenance /
--     dev_save_force_update / dev_save_toggles / dev_save_settings
--   • dev_add_admin / dev_reset_admin_passcode / dev_set_admin_banned
--   • dev_set_user_banned / dev_reset_user_password (Users সেকশন)
--   • verify_admin_passcode-এর নতুন সংস্করণ: শেয়ার্ড অ্যাডমিন
--     অ্যাকাউন্ট (admin@amaresports.app) ব্যান থাকলে false ফেরত দেয়।
--     আলাদা অ্যাডমিন অ্যাকাউন্টের ব্যান চেক সাইন-ইনের পর অ্যাপে হয়।
-- ============================================================================

-- পাসওয়ার্ড হ্যাশ (bcrypt) বানাতে pgcrypto লাগে — অ্যাডমিনের পাসকোড
-- রিসেট ও নতুন অ্যাডমিন যোগ করার ফাংশনে ব্যবহৃত হয়।
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- ১) profiles-এ is_developer কলাম (না থাকলে যোগ হয়)।
--    is_banned আগেই থাকার কথা (অ্যাডমিনের ban ফিচার), তবু নিরাপদে যোগ করা।
-- ----------------------------------------------------------------------------
alter table public.profiles add column if not exists is_developer boolean not null default false;
alter table public.profiles add column if not exists is_banned boolean not null default false;

-- ----------------------------------------------------------------------------
-- ২) is_admin() / is_developer() হেল্পার।
--    (is_admin() অ্যাডমিন অ্যাপ আগেই ডাকে; এখানে নিরাপদে আবার বসানো হলো।)
-- ----------------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and coalesce(p.is_admin, false) = true
  );
$$;

grant execute on function public.is_admin() to authenticated;

create or replace function public.is_developer()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and coalesce(p.is_developer, false) = true
  );
$$;

grant execute on function public.is_developer() to authenticated;

-- ----------------------------------------------------------------------------
-- ৩) ডেভেলপার পাসকোড যাচাই — app_config-এর 'developer_passcode' key।
--    রো না থাকলে ডিফল্ট '1234'।
-- ----------------------------------------------------------------------------
create or replace function public.verify_developer_passcode(p_code text)
returns boolean
language plpgsql
security definer
as $$
declare
  v_stored text;
begin
  select value #>> '{}' into v_stored
    from public.app_config where key = 'developer_passcode';
  if v_stored is null or v_stored = '' then
    v_stored := '1234';
  end if;
  return p_code is not null and p_code = v_stored;
end;
$$;

grant execute on function public.verify_developer_passcode(text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- ৪) ডেভেলপার পাসকোড বদলানো — অ্যাডমিনের admin_set_passcode-এর মতোই।
--    শুধু সাইন-ইন করা ডেভেলপারই পারবে। অ্যাপ আগে Auth অ্যাকাউন্টের
--    পাসওয়ার্ডও বদলায়; সেটা না হলে এটা চালালেও লগইন ভেঙে যেত।
-- ----------------------------------------------------------------------------
create or replace function public.admin_set_developer_passcode(p_old text, p_new text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_stored text;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_new is null or p_new !~ '^\d{4}$' then
    raise exception 'Passcode must be exactly 4 digits';
  end if;
  select value #>> '{}' into v_stored
    from public.app_config where key = 'developer_passcode';
  if v_stored is null or v_stored = '' then
    v_stored := '1234';
  end if;
  if p_old is null or p_old <> v_stored then
    raise exception 'Old passcode is wrong';
  end if;
  insert into public.app_config (key, value) values ('developer_passcode', to_jsonb(p_new))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.admin_set_developer_passcode(text, text) to authenticated;

-- ডিফল্ট ডেভেলপার পাসকোড রো (না থাকলে বসানো হয়)।
insert into public.app_config (key, value) values ('developer_passcode', to_jsonb('1234'))
  on conflict (key) do nothing;

-- ----------------------------------------------------------------------------
-- ৫) verify_admin_passcode — নতুন সংস্করণ: শেয়ার্ড অ্যাডমিন অ্যাকাউন্ট
--    (admin@amaresports.app) ব্যান থাকলে পাসকোড ঠিক হলেও false।
--    আলাদা অ্যাডমিন অ্যাকাউন্টের ব্যান চেক সাইন-ইনের পর অ্যাডমিন অ্যাপের
--    AdminCheck-এ হয় (কারণ পাসকোড দেওয়ার আগে কোন অ্যাডমিন লগইন করছে
--    তা জানা যায় না)।
-- ----------------------------------------------------------------------------
create or replace function public.verify_admin_passcode(p_code text)
returns boolean
language plpgsql
security definer
as $$
declare
  v_stored text;
  v_banned boolean;
begin
  select value #>> '{}' into v_stored
    from public.app_config where key = 'admin_passcode';
  if v_stored is null or v_stored = '' then
    v_stored := '1234';
  end if;
  if p_code is null or p_code <> v_stored then
    return false;
  end if;
  select coalesce(p.is_banned, false) into v_banned
    from public.profiles p
    join auth.users u on u.id = p.id
    where u.email = 'admin@amaresports.app';
  if coalesce(v_banned, false) then
    return false;
  end if;
  return true;
end;
$$;

grant execute on function public.verify_admin_passcode(text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- ৬) admin_activity_log — অ্যাডমিন কী করল, কখন করল।
--    অ্যাডমিনরা শুধু নিজের রো INSERT করতে পারে, ডেভেলপার সব পড়তে পারে।
-- ----------------------------------------------------------------------------
create table if not exists public.admin_activity_log (
  id uuid primary key default gen_random_uuid(),
  admin_phone text not null default '',
  action text not null default '',
  detail text not null default '',
  created_at timestamptz not null default now()
);

alter table public.admin_activity_log enable row level security;

grant insert, select on public.admin_activity_log to authenticated;

drop policy if exists "admin_activity_log insert admin" on public.admin_activity_log;
create policy "admin_activity_log insert admin" on public.admin_activity_log
  for insert with check (
    exists (select 1 from public.profiles p
            where p.id = auth.uid() and coalesce(p.is_admin, false) = true)
  );

drop policy if exists "admin_activity_log select developer" on public.admin_activity_log;
create policy "admin_activity_log select developer" on public.admin_activity_log
  for select using (
    exists (select 1 from public.profiles p
            where p.id = auth.uid() and coalesce(p.is_developer, false) = true)
  );

-- ----------------------------------------------------------------------------
-- ৭) ডেভেলপার সেভ ফাংশনগুলো — সবগুলো SECURITY DEFINER, ভেতরে
--    is_developer() চেক; ডেভেলপার না হলে 'Developer only' এরর।
-- ----------------------------------------------------------------------------

-- ব্যানার (app_config key 'banners'): [{image, title, link, order, visible}]
create or replace function public.dev_save_banners(p_banners jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_banners is null or jsonb_typeof(p_banners) <> 'array' then
    raise exception 'Banners must be a JSON array';
  end if;
  insert into public.app_config (key, value) values ('banners', p_banners)
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true, 'count', jsonb_array_length(p_banners));
end;
$$;

grant execute on function public.dev_save_banners(jsonb) to authenticated;

-- যোগাযোগ (whatsapp / email / telegram — আলাদা key হিসেবে বসে)।
create or replace function public.dev_save_contacts(p_contacts jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_contacts is null or jsonb_typeof(p_contacts) <> 'object' then
    raise exception 'Contacts must be a JSON object';
  end if;
  insert into public.app_config (key, value) values
    ('whatsapp', to_jsonb(coalesce(p_contacts ->> 'whatsapp', ''))),
    ('email', to_jsonb(coalesce(p_contacts ->> 'email', ''))),
    ('telegram', to_jsonb(coalesce(p_contacts ->> 'telegram', '')))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_save_contacts(jsonb) to authenticated;

-- মেইনটেন্যান্স মোড: maintenance_user / maintenance_admin (bool),
-- maintenance_message (text)।
create or replace function public.dev_save_maintenance(p_maintenance jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_maintenance is null or jsonb_typeof(p_maintenance) <> 'object' then
    raise exception 'Maintenance must be a JSON object';
  end if;
  insert into public.app_config (key, value) values
    ('maintenance_user', to_jsonb(coalesce((p_maintenance ->> 'maintenance_user')::boolean, false))),
    ('maintenance_admin', to_jsonb(coalesce((p_maintenance ->> 'maintenance_admin')::boolean, false))),
    ('maintenance_message', to_jsonb(coalesce(p_maintenance ->> 'maintenance_message', '')))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_save_maintenance(jsonb) to authenticated;

-- ফোর্স আপডেট: min_version_user/admin, update_url_user/admin (text),
-- force_user/force_admin (bool)।
create or replace function public.dev_save_force_update(p_force jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_force is null or jsonb_typeof(p_force) <> 'object' then
    raise exception 'Force update must be a JSON object';
  end if;
  insert into public.app_config (key, value) values
    ('min_version_user', to_jsonb(coalesce(p_force ->> 'min_version_user', ''))),
    ('min_version_admin', to_jsonb(coalesce(p_force ->> 'min_version_admin', ''))),
    ('update_url_user', to_jsonb(coalesce(p_force ->> 'update_url_user', ''))),
    ('update_url_admin', to_jsonb(coalesce(p_force ->> 'update_url_admin', ''))),
    ('force_user', to_jsonb(coalesce((p_force ->> 'force_user')::boolean, false))),
    ('force_admin', to_jsonb(coalesce((p_force ->> 'force_admin')::boolean, false)))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_save_force_update(jsonb) to authenticated;

-- ফিচার টগল (app_config key 'feature_toggles'): JSON অবজেক্ট।
create or replace function public.dev_save_toggles(p_toggles jsonb)
returns jsonb
language plpgsql
security definer
as $$
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_toggles is null or jsonb_typeof(p_toggles) <> 'object' then
    raise exception 'Toggles must be a JSON object';
  end if;
  insert into public.app_config (key, value) values ('feature_toggles', p_toggles)
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_save_toggles(jsonb) to authenticated;

-- সেটিংস: পেমেন্ট নম্বর (bkash/nagad/rocket), সর্বনিম্ন ডিপোজিট/উইথড্র।
-- payment_numbers key (ইউজার অ্যাপের Wallet এখান থেকেই নম্বর পড়ে),
-- dev_settings key (min_deposit/min_withdraw — ইউজার অ্যাপের ফর্ম পড়ে),
-- আর notice_settings.minimum-ও আপডেট করা হয় যাতে আগের উইথড্র
-- মিনিমাম দেখানো ঠিক থাকে।
create or replace function public.dev_save_settings(p_settings jsonb)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_nums jsonb;
  v_old_notice jsonb;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_settings is null or jsonb_typeof(p_settings) <> 'object' then
    raise exception 'Settings must be a JSON object';
  end if;
  v_nums := jsonb_build_object(
    'bkash', coalesce(p_settings ->> 'bkash', ''),
    'nagad', coalesce(p_settings ->> 'nagad', ''),
    'rocket', coalesce(p_settings ->> 'rocket', '')
  );
  insert into public.app_config (key, value) values
    ('payment_numbers', v_nums),
    ('dev_settings', jsonb_build_object(
      'min_deposit', coalesce((p_settings ->> 'min_deposit')::int, 20),
      'min_withdraw', coalesce((p_settings ->> 'min_withdraw')::int, 0)
    ))
    on conflict (key) do update set value = excluded.value;
  -- আগের notice_settings থাকলে তার minimum-ও মিলিয়ে নেওয়া হয়।
  select value into v_old_notice from public.app_config where key = 'notice_settings';
  if v_old_notice is not null and jsonb_typeof(v_old_notice) = 'object' then
    insert into public.app_config (key, value) values
      ('notice_settings', v_old_notice || jsonb_build_object(
        'minimum', coalesce((p_settings ->> 'min_withdraw')::int, 0)))
      on conflict (key) do update set value = excluded.value;
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_save_settings(jsonb) to authenticated;

-- ----------------------------------------------------------------------------
-- ৮) নতুন অ্যাডমিন যোগ করা।
--    Auth ইউজারটি আগে Dashboard-এ বানাতে হয় (ফাইলের মাথার নোট দেখুন) —
--    এখানে শুধু প্রোফাইলে is_admin=true বসানো হয়, আর Auth পাসওয়ার্ডটি
--    পাসকোডের সঙ্গে মিলিয়ে নেওয়া হয় (bcrypt, pgcrypto দিয়ে)।
-- ----------------------------------------------------------------------------
create or replace function public.dev_add_admin(p_phone text, p_passcode text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_uid uuid;
  v_email text;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_phone is null or p_phone !~ '^01\d{9}$' then
    raise exception 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)';
  end if;
  if p_passcode is null or p_passcode !~ '^\d{4}$' then
    raise exception 'Passcode must be exactly 4 digits';
  end if;
  v_email := p_phone || '@amaresports.app';
  select id into v_uid from auth.users where email = v_email;
  if v_uid is null then
    raise exception 'Auth user not found — Dashboard > Authentication-এ আগে ইউজার বানান (%)', v_email;
  end if;
  update auth.users
    set encrypted_password = crypt(p_passcode, gen_salt('bf')),
        email_confirmed_at = coalesce(email_confirmed_at, now())
    where id = v_uid;
  insert into public.profiles (id, phone, is_admin, is_banned)
    values (v_uid, p_phone, true, false)
    on conflict (id) do update set phone = excluded.phone, is_admin = true, is_banned = false;
  return jsonb_build_object('ok', true, 'user_id', v_uid);
end;
$$;

grant execute on function public.dev_add_admin(text, text) to authenticated;

-- ----------------------------------------------------------------------------
-- ৯) অ্যাডমিনের পাসকোড রিসেট (আলাদা অ্যাডমিন অ্যাকাউন্টের জন্য)।
--    দ্রষ্টব্য: এটা শুধু ওই অ্যাকাউন্টের Auth পাসওয়ার্ড বদলায়;
--    শেয়ার্ড অ্যাডমিন অ্যাকাউন্টের (admin@amaresports.app) পাসকোড
--    app_config-এর 'admin_passcode'-তে থাকে — সেটা অ্যাডমিন অ্যাপের
--    তালা আইকন দিয়ে বদলাতে হয়, এখানে নয়।
-- ----------------------------------------------------------------------------
create or replace function public.dev_reset_admin_passcode(p_phone text, p_new text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_uid uuid;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_phone is null or p_phone !~ '^01\d{9}$' then
    raise exception 'সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)';
  end if;
  if p_new is null or p_new !~ '^\d{4}$' then
    raise exception 'Passcode must be exactly 4 digits';
  end if;
  select id into v_uid from auth.users where email = p_phone || '@amaresports.app';
  if v_uid is null then
    raise exception 'Admin account not found';
  end if;
  update auth.users
    set encrypted_password = crypt(p_new, gen_salt('bf'))
    where id = v_uid;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_reset_admin_passcode(text, text) to authenticated;

-- ----------------------------------------------------------------------------
-- ১০) অ্যাডমিন ব্যান/আনব্যান (ফোন নম্বর দিয়ে, শুধু is_admin প্রোফাইলে)।
-- ----------------------------------------------------------------------------
create or replace function public.dev_set_admin_banned(p_phone text, p_ban boolean)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  update public.profiles set is_banned = coalesce(p_ban, false)
    where phone = p_phone and coalesce(is_admin, false) = true;
  get diagnostics v_count = row_count;
  if v_count = 0 then
    raise exception 'Admin not found';
  end if;
  return jsonb_build_object('ok', true, 'banned', coalesce(p_ban, false));
end;
$$;

grant execute on function public.dev_set_admin_banned(text, boolean) to authenticated;

-- ----------------------------------------------------------------------------
-- ১০ক) অ্যাডমিন মুছা — is_admin ফ্ল্যাগ তুলে নেওয়া (প্রোফাইল রো থাকে,
--    অ্যাকাউন্ট মুছে না; ইউজার হিসেবে আবার ব্যবহার করা যায়)।
-- ----------------------------------------------------------------------------
create or replace function public.dev_remove_admin(p_phone text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  update public.profiles set is_admin = false, is_banned = false
    where phone = p_phone and coalesce(is_admin, false) = true;
  get diagnostics v_count = row_count;
  if v_count = 0 then
    raise exception 'Admin not found';
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_remove_admin(text) to authenticated;

-- ----------------------------------------------------------------------------
-- ১১) ইউজার ব্যান/আনব্যান + ইউজারের পাসওয়ার্ড রিসেট (Users সেকশন)।
-- ----------------------------------------------------------------------------
create or replace function public.dev_set_user_banned(p_user uuid, p_ban boolean)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  update public.profiles set is_banned = coalesce(p_ban, false) where id = p_user;
  get diagnostics v_count = row_count;
  if v_count = 0 then
    raise exception 'User not found';
  end if;
  return jsonb_build_object('ok', true, 'banned', coalesce(p_ban, false));
end;
$$;

grant execute on function public.dev_set_user_banned(uuid, boolean) to authenticated;

create or replace function public.dev_reset_user_password(p_user uuid, p_new text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if not public.is_developer() then
    raise exception 'Developer only';
  end if;
  if p_new is null or length(p_new) < 6 then
    raise exception 'Password must be at least 6 characters';
  end if;
  update auth.users
    set encrypted_password = crypt(p_new, gen_salt('bf'))
    where id = p_user;
  get diagnostics v_count = row_count;
  if v_count = 0 then
    raise exception 'User not found';
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.dev_reset_user_password(uuid, text) to authenticated;
