-- ============================================================================
-- Amar E-sports — Update 10 ব্যাকএন্ড
-- ============================================================================
-- এই ফাইলটি চালাতে হবে: Supabase Dashboard > SQL Editor-এ পুরো ফাইলটি
-- পেস্ট করে Run করুন। তার আগে update9.sql (যদি এখনো না চালিয়ে থাকেন)
-- চালিয়ে নিন।
--
-- এককালীন সেটআপ (শুধু একবার, Supabase Dashboard-এ):
--   ১. Authentication > Users > Add user:
--        Email:    admin@amaresports.app
--        Password: 1234
--      (দ্রষ্টব্য: Supabase Auth সাধারণত কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড চায়।
--      ৪ সংখ্যার পাসওয়ার্ডে ইউজার বানাতে না পারলে Dashboard >
--      Authentication-এ সর্বনিম্ন দৈর্ঘ্য কমিয়ে নিন। আর তা-ও না হলে
--      অ্যাডমিন অ্যাপের config.dart-এ adminPasswordPrefix বসাতে হবে
--      এবং অ্যাকাউন্টটি সেই পাসওয়ার্ড দিয়ে বানাতে হবে।)
--   ২. ওই অ্যাকাউন্টের প্রোফাইলে is_admin = true করুন:
--        update public.profiles set is_admin = true
--        where phone = 'admin@amaresports.app'::text;  -- অথবা id দিয়ে
--      (প্রোফাইল রো না থাকলে ইমেইল দিয়ে প্রোফাইল তৈরি করে is_admin=true দিন।)
--   ৩. প্রথম লগইনের পরপরই অ্যাডমিন প্যানেলের তালা আইকন থেকে পাসকোড
--      বদলে নিন — ডিফল্ট পাসকোড 1234।
--
-- এই ফাইলে যা আছে:
--   • verify_admin_passcode / admin_set_passcode — ৪ সংখ্যার পাসকোড লগইন
--   • tournaments-এ নতুন কলাম: card_no, per_kill, version, prizes
--   • admin_accept_deposit — রিকোয়েস্ট ধরে রেখে Amount দিয়ে অ্যাকসেপ্ট
--     (পুরনো অ্যাপের "Bad arguments to +" ক্র্যাশের কারণে অ্যামাউন্ট
--     এখানে সংখ্যা হিসেবে যাচাই করে ক্রেডিট করা হয়)
--   • admin_delete_all_requests — সব pending ডিপোজিট/উইথড্র রিকোয়েস্ট মুছা
--   • admin_clear_players — ম্যাচের সব পার্টিসিপ্যান্ট মুছা
--   • admin_send_money (নতুন ৫-প্যারামিটার সংস্করণ) — Winnings + Kills সহ
--   • admin_save_notice_settings — নোটিশ সেটিংস + পেমেন্ট নম্বর
-- ============================================================================

-- ----------------------------------------------------------------------------
-- ১) পাসকোড যাচাই — app_config-এর 'admin_passcode' key-র সঙ্গে মেলানো।
--    রো না থাকলে ডিফল্ট '1234' ধরা হয়।
-- ----------------------------------------------------------------------------
create or replace function public.verify_admin_passcode(p_code text)
returns boolean
language plpgsql
security definer
as $$
declare
  v_stored text;
begin
  select value #>> '{}' into v_stored
    from public.app_config where key = 'admin_passcode';
  if v_stored is null or v_stored = '' then
    v_stored := '1234';
  end if;
  return p_code is not null and p_code = v_stored;
end;
$$;

grant execute on function public.verify_admin_passcode(text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- ২) পাসকোড বদলানো — পুরনো পাসকোড ফাংশনের ভেতরেই যাচাই করা হয়,
--    তারপর app_config আপডেট হয়। শুধু সাইন-ইন করা অ্যাডমিনই পারবে।
--    (অ্যাপ আগে Auth অ্যাকাউন্টের পাসওয়ার্ডও বদলায়; সেটা না হলে এটা
--    চালালেও লগইন ভেঙে যেত — তাই অ্যাপ updateUser সফল হলেই এটা ডাকে।)
-- ----------------------------------------------------------------------------
create or replace function public.admin_set_passcode(p_old text, p_new text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_stored text;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_new is null or p_new !~ '^\d{4}$' then
    raise exception 'Passcode must be exactly 4 digits';
  end if;
  select value #>> '{}' into v_stored
    from public.app_config where key = 'admin_passcode';
  if v_stored is null or v_stored = '' then
    v_stored := '1234';
  end if;
  if p_old is null or p_old <> v_stored then
    raise exception 'Old passcode is wrong';
  end if;
  insert into public.app_config (key, value) values ('admin_passcode', to_jsonb(p_new))
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.admin_set_passcode(text, text) to authenticated;

-- ডিফল্ট পাসকোড রো (না থাকলে বসানো হয়)।
insert into public.app_config (key, value) values ('admin_passcode', to_jsonb('1234'))
  on conflict (key) do nothing;

-- ----------------------------------------------------------------------------
-- ৩) tournaments-এ পুরনো অ্যাপের ফর্মের ফিল্ডগুলোর কলাম
--    card_no    — Match Card Number (GET DETAILS দিয়ে খোঁজা হয়)
--    per_kill   — প্রতি কিলের প্রাইজ
--    version    — FF ভার্সন (Mobile / Clash ইত্যাদি)
--    prizes     — ১ম–৬ষ্ঠ প্রাইজের অ্যারে (jsonb)
--    board/mode/status/fee/prize_pool/slots/starts_at/title আগেই ছিল।
-- ----------------------------------------------------------------------------
alter table public.tournaments add column if not exists card_no int;
alter table public.tournaments add column if not exists per_kill int not null default 0;
alter table public.tournaments add column if not exists version text not null default '';
alter table public.tournaments add column if not exists prizes jsonb not null default '[]'::jsonb;

create unique index if not exists tournaments_card_no_uidx
  on public.tournaments (card_no) where card_no is not null;

-- ----------------------------------------------------------------------------
-- ৪) admin_clear_players — ম্যাচের সব পার্টিসিপ্যান্ট মুছা
--    (Player List ডায়ালগের CLEAR ALL PLAYERS)। টাকা ফেরত দেওয়া হয় না —
--    পুরনো অ্যাপের মতো শুধু লিস্ট সাফ হয়। joined কাউন্ট ০ করা হয়।
-- ----------------------------------------------------------------------------
create or replace function public.admin_clear_players(p_tournament uuid)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  delete from public.participants where tournament_id = p_tournament;
  get diagnostics v_count = row_count;
  update public.tournaments set joined = 0 where id = p_tournament;
  return jsonb_build_object('ok', true, 'cleared', v_count);
end;
$$;

grant execute on function public.admin_clear_players(uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- ৫) admin_accept_deposit — ডিপোজিট রিকোয়েস্ট অ্যাকসেপ্ট করে ওয়ালেটে
--    টাকা পাঠানো। অ্যামাউন্ট সংখ্যা হিসেবে আসে (p_amount numeric) — খালি
--    স্ট্রিংয়ের সঙ্গে যোগ করার পুরনো ক্র্যাশ এখানে হতে পারে না।
--    শুধু pending রিকোয়েস্ট অ্যাকসেপ্ট হয় (ডাবল ক্রেডিট রোধে)।
-- ----------------------------------------------------------------------------
create or replace function public.admin_accept_deposit(p_id uuid, p_amount numeric)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_uid uuid;
  v_status text;
  v_balance numeric;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount must be greater than 0';
  end if;
  select user_id, status into v_uid, v_status
    from public.deposits where id = p_id;
  if v_uid is null then
    raise exception 'Deposit request not found';
  end if;
  if v_status <> 'pending' then
    raise exception 'Request already processed';
  end if;
  update public.wallets set balance = balance + p_amount where user_id = v_uid;
  if not found then
    insert into public.wallets (user_id, balance) values (v_uid, p_amount);
  end if;
  insert into public.ledger (user_id, type, amount) values (v_uid, 'deposit', p_amount);
  update public.deposits set status = 'approved' where id = p_id;
  select balance into v_balance from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'balance', v_balance);
end;
$$;

grant execute on function public.admin_accept_deposit(uuid, numeric) to authenticated;

-- ----------------------------------------------------------------------------
-- ৬) admin_delete_all_requests — সব pending ডিপোজিট বা উইথড্র
--    রিকোয়েস্ট একসাথে মুছা (DELETE ALL REQUESTS বোতাম)।
--    p_kind: 'deposit' বা 'withdraw'
-- ----------------------------------------------------------------------------
create or replace function public.admin_delete_all_requests(p_kind text)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_count int;
begin
  if auth.uid() is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_kind = 'deposit' then
    delete from public.deposits where status = 'pending';
    get diagnostics v_count = row_count;
  elsif p_kind = 'withdraw' then
    delete from public.withdrawals where status = 'pending';
    get diagnostics v_count = row_count;
  else
    raise exception 'Unknown request kind';
  end if;
  return jsonb_build_object('ok', true, 'deleted', v_count);
end;
$$;

grant execute on function public.admin_delete_all_requests(text) to authenticated;

-- ----------------------------------------------------------------------------
-- ৭) admin_send_money — নতুন সংস্করণ: Winnings চেকবক্স + Kills সহ।
--    আগের ৩-প্যারামিটার সংস্করণটি সরিয়ে ৫-প্যারামিটার সংস্করণ বসানো হলো।
--    Winnings হলে ইউজারের total_kills বাড়ে এবং total_wins ১ বাড়ে।
-- ----------------------------------------------------------------------------
drop function if exists public.admin_send_money(text, numeric, text);

create or replace function public.admin_send_money(
  p_phone text,
  p_amount numeric,
  p_note text default '',
  p_winnings boolean default false,
  p_kills int default 0
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_uid uuid;
  v_balance numeric;
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount must be greater than 0';
  end if;
  select id into v_uid from public.profiles where phone = p_phone;
  if v_uid is null then
    raise exception 'ইউজার পাওয়া যায়নি';
  end if;
  update public.wallets set balance = balance + p_amount where user_id = v_uid;
  if not found then
    insert into public.wallets (user_id, balance) values (v_uid, p_amount);
  end if;
  insert into public.ledger (user_id, type, amount) values (v_uid, 'admin_send', p_amount);
  if coalesce(p_winnings, false) then
    update public.profiles
      set total_kills = coalesce(total_kills, 0) + greatest(coalesce(p_kills, 0), 0),
          total_wins = coalesce(total_wins, 0) + 1
      where id = v_uid;
  end if;
  select balance into v_balance from public.wallets where user_id = v_uid;
  return jsonb_build_object('ok', true, 'balance', v_balance);
end;
$$;

grant execute on function public.admin_send_money(text, numeric, text, boolean, int) to authenticated;

-- ----------------------------------------------------------------------------
-- ৮) admin_save_notice_settings — নোটিশ সেটিংস (Image URL / Visible /
--    Minimum / Visible / bKash-Nogod-Rocket নম্বর) সেভ করা।
--    পেমেন্ট নম্বরগুলো 'payment_numbers' key-তেও বসানো হয়, কারণ ইউজার
--    অ্যাপের Wallet সেই key থেকেই নম্বর পড়ে দেখায়। Image URL / Minimum
--    'notice_settings' key-তে থাকে (ইউজার অ্যাপ এখনো ব্যানার দেখায় না;
--    Minimum উইথড্র ফর্মে লাল লেবেল হিসেবে দেখায়)।
-- ----------------------------------------------------------------------------
create or replace function public.admin_save_notice_settings(p_settings jsonb)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_nums jsonb;
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and coalesce(p.is_admin, false) = true) then
    raise exception 'Admin only';
  end if;
  if p_settings is null or jsonb_typeof(p_settings) <> 'object' then
    raise exception 'Settings must be a JSON object';
  end if;
  insert into public.app_config (key, value) values ('notice_settings', p_settings)
    on conflict (key) do update set value = excluded.value;
  v_nums := jsonb_build_object(
    'bkash', coalesce(p_settings ->> 'bkash', ''),
    'nagad', coalesce(p_settings ->> 'nagad', ''),
    'rocket', coalesce(p_settings ->> 'rocket', '')
  );
  insert into public.app_config (key, value) values ('payment_numbers', v_nums)
    on conflict (key) do update set value = excluded.value;
  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.admin_save_notice_settings(jsonb) to authenticated;
