import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'wallet.dart';

const ledgerLabel = {
  'deposit': 'ডিপোজিট',
  'join_fee': 'জয়েন ফি',
  'prize': 'প্রাইজ',
  'withdraw_hold': 'উইথড্র (আটকানো)',
  'withdraw_refund': 'উইথড্র ফেরত',
  'refund': 'ফি ফেরত',
  'admin_send': 'অ্যাডমিন পাঠিয়েছে',
};

const _statusLabels = {
  'all': 'সবগুলো',
  'open': 'খোলা',
  'live': 'লাইভ',
};

String maskPhone(String p) {
  final s = p.trim();
  if (s.length < 5) return s.isEmpty ? '-' : '****';
  return '${s.substring(0, 3)}****${s.substring(s.length - 2)}';
}

// কপি বোতামসহ এক লাইনের তথ্য (রুম আইডি / পাসওয়ার্ড)।
Widget _copyRow(BuildContext context, String label, String value) => Row(children: [
  Expanded(child: Text('$label: $value', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
  IconButton(
    icon: const Icon(Icons.copy, size: 20),
    tooltip: 'কপি করুন',
    onPressed: () async {
      await Clipboard.setData(ClipboardData(text: value));
      if (context.mounted) toast(context, 'কপি হয়েছে');
    },
  ),
]);

// starts_at পর্যন্ত লাইভ কাউন্টডাউন (প্রতি সেকেন্ডে আপডেট হয়)।
class _CountdownText extends StatefulWidget {
  final String? startsAt;
  final TextStyle? style;
  const _CountdownText({required this.startsAt, this.style});
  @override
  State<_CountdownText> createState() => _CountdownTextState();
}

class _CountdownTextState extends State<_CountdownText> {
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) { if (mounted) setState(() {}); });
  }
  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final start = DateTime.tryParse('${widget.startsAt ?? ''}');
    if (start == null) return const SizedBox.shrink();
    final d = start.difference(DateTime.now());
    if (d.inSeconds <= 0) return Text('শুরু হয়েছে', style: widget.style);
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final s = d.inSeconds % 60;
    return Text('${two(h)}:${two(m)}:${two(s)}', style: widget.style);
  }
}

// ---------------- Shell: Play / Me ----------------
class HomeShell extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onProfileChanged;
  const HomeShell({super.key, required this.profile, required this.onProfileChanged});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF030B2B),
        body: SafeArea(
          child: IndexedStack(index: _i, children: [
            const PlayPage(),
            ProfilePage(profile: widget.profile, onChanged: widget.onProfileChanged),
          ]),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            height: 52,
            decoration: const BoxDecoration(color: Color(0xFF030B2B)),
            child: Row(children: [
              _navItem(Icons.games, 'Play', 0),
              _navItem(Icons.account_circle, 'Me', 1),
            ]),
          ),
        ),
      );

  Widget _navItem(IconData icon, String label, int index) {
    final selected = _i == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _i = index),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 24, color: selected ? const Color(0xFFE6E9F5) : Colors.white38),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 12, color: selected ? const Color(0xFFE6E9F5) : Colors.white38)),
        ]),
      ),
    );
  }
}

// ---------------- Home (Play) ----------------
const _defaultBanners = [
  {'title': 'কিভাবে খেলবেন?', 'subtitle': 'ভিডিওটি দেখুন', 'url': '', 'image': '', 'asset': 'assets/images/how_to_play_banner.jpg'},
  {'title': 'Join our WhatsApp Community', 'subtitle': '', 'url': '', 'image': '', 'asset': 'assets/images/whatsapp_community_banner.jpg'},
  {'title': 'Join our Telegram Community', 'subtitle': '', 'url': '', 'image': '', 'asset': 'assets/images/telegram_community_banner.jpg'},
];

const _bannerColors = [
  [Color(0xFF3B0A2A), Color(0xFF0B1B4A)],
  [Color(0xFF0A3D62), Color(0xFF1B1464)],
  [Color(0xFF0B4F2B), Color(0xFF062A16)],
];

class PlayPage extends StatefulWidget {
  const PlayPage({super.key});
  @override
  State<PlayPage> createState() => _PlayPageState();
}

class _PlayPageState extends State<PlayPage> {
  late Future<Map<String, dynamic>> _f;
  final _pc = PageController();
  Timer? _timer;
  int _page = 0;
  int _count = 3;
  var _noticeShown = false;

  @override
  void initState() {
    super.initState();
    _f = _load();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!_pc.hasClients || _count < 2) return;
      _pc.animateToPage((_page + 1) % _count, duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select('balance').eq('user_id', me).maybeSingle();
    final cfg = await loadConfig();
    return {'balance': w?['balance'] ?? 0, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 19, bottom: 20),
        child: Row(children: [
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600, letterSpacing: 0.2, fontSize: 20, color: Colors.white)),
          ),
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
        ]),
      );

  String _fallbackBannerAsset(Map b, int i) {
    final title = '${b['title'] ?? ''}'.toLowerCase();
    if (title.contains('whatsapp') || title.contains('হোয়াটসঅ্যাপ')) {
      return 'assets/images/whatsapp_community_banner.jpg';
    }
    if (title.contains('telegram') || title.contains('টেলিগ্রাম')) {
      return 'assets/images/telegram_community_banner.jpg';
    }
    if (title.contains('play') || title.contains('খেল') || title.contains('ভিডিও') || title.contains('video')) {
      return 'assets/images/how_to_play_banner.jpg';
    }
    const defaults = [
      'assets/images/how_to_play_banner.jpg',
      'assets/images/telegram_community_banner.jpg',
      'assets/images/whatsapp_community_banner.jpg',
    ];
    return defaults[i % defaults.length];
  }

  Widget _banner(Map b, int i, Map<String, dynamic> cfg) {
    final colors = _bannerColors[i % _bannerColors.length];
    final img = '${b['image'] ?? ''}'.trim();
    final configuredAsset = '${b['asset'] ?? ''}'.trim();
    // Keep configured remote images/assets; use the supplied original artwork
    // whenever a banner record has no image configured.
    final asset = configuredAsset.isNotEmpty ? configuredAsset : (img.isEmpty ? _fallbackBannerAsset(b, i) : '');
    return GestureDetector(
      onTap: () => openUrl(context, '${b['url'] ?? ''}'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 1),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (asset.isNotEmpty)
            Image.asset(asset, fit: BoxFit.cover, alignment: Alignment.center, filterQuality: FilterQuality.high)
          else
            Image.network(
              img,
              fit: BoxFit.cover,
              alignment: Alignment.center,
              filterQuality: FilterQuality.high,
              errorBuilder: (_, __, ___) => Image.asset(
                _fallbackBannerAsset(b, i),
                fit: BoxFit.cover,
                alignment: Alignment.center,
                filterQuality: FilterQuality.high,
              ),
            ),
        ]),
      ),
    );
  }

  // পুরনো হোমের মতো ২ কলামের বড় কার্ড: Free Fire + Ludo King পাশাপাশি।
  Widget _gameCard(GameInfo g, [String? asset, double aspect = 1.67]) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GameMatchesPage(game: g))),
        child: AspectRatio(
          aspectRatio: aspect,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(7),
            child: asset != null
                ? Image.asset(asset, fit: BoxFit.cover, filterQuality: FilterQuality.high)
                : Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: g.gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(g.icon, color: Colors.white, size: 30),
                      const SizedBox(height: 4),
                      Text(g.title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                      const Text('টুর্নামেন্ট', style: TextStyle(color: Colors.white70, fontSize: 11)),
                    ]),
                  ),
          ),
        ),
      );

  // হোম লোড হলেই নোটিশ পপআপ (পুরনো অ্যাপের মতো) — এক সেশনে একবার।
  void _maybeShowNotice(List<dynamic> notices) {
    if (_noticeShown || notices.isEmpty || !mounted) return;
    _noticeShown = true;
    final n = notices.first as Map;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('${n['title'] ?? 'নোটিশ'}'),
          content: Text('${n['body'] ?? ''}'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        future: _f,
        builder: (d) {
          final cfg = d['cfg'] as Map<String, dynamic>;
          final notices = cfg['notices'] is List ? (cfg['notices'] as List) : const [];
          _maybeShowNotice(notices);
          final raw = cfg['banners'];
          final banners = (raw is List && raw.isNotEmpty) ? raw : _defaultBanners;
          _count = banners.length;
          return Stack(children: [
            RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(padding: const EdgeInsets.fromLTRB(12, 8, 12, 88), children: [
                LayoutBuilder(builder: (context, constraints) {
                  final compact = constraints.maxWidth < 380;
          final logoSize = 34.0;
                  final titleSize = compact ? 18.0 : 21.0;
                  return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                    ClipOval(child: Image.asset('assets/images/logo.png', width: logoSize, height: logoSize, fit: BoxFit.cover)),
                    SizedBox(width: compact ? 8 : 10),
                    Expanded(
                      child: Text('Amar E-sports', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: titleSize, fontWeight: FontWeight.w900, letterSpacing: .2, color: Colors.white)),
                    ),
                    Stack(children: [
                      IconButton(
                        icon: const Icon(Icons.notifications, color: Colors.white, size: 24),
                        tooltip: 'নোটিশ',
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NoticesPage())),
                      ),
                      if (notices.isNotEmpty)
                        Positioned(
                          right: 6,
                          top: 6,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                            child: Text('${notices.length}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                          ),
                        ),
                    ]),
                    const SizedBox(width: 7),
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()));
                        _refresh();
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: compact ? 9 : 10),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.account_balance_wallet_outlined, color: const Color(0xFF07112E), size: compact ? 22 : 24),
                          const SizedBox(width: 5),
                          Text('${money(d['balance']).replaceAll('.00', '').replaceAll('৳', '').trim()} ৳',
                            style: TextStyle(color: const Color(0xFF07112E), fontSize: compact ? 17 : 19, fontWeight: FontWeight.w900)),
                        ]),
                      ),
                    ),
                  ]);
                }),
                const SizedBox(height: 10),
                AspectRatio(
                  aspectRatio: 1.84,
                  child: Stack(children: [
                    PageView.builder(
                      controller: _pc,
                      itemCount: banners.length,
                      onPageChanged: (v) => setState(() => _page = v),
                      itemBuilder: (c, i) => _banner(banners[i] as Map, i, cfg),
                    ),
                    Positioned(
                      bottom: 10,
                      left: 0,
                      right: 0,
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        for (var i = 0; i < banners.length; i++)
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: i == _page ? Colors.white70 : Colors.white38),
                          ),
                      ]),
                    ),
                  ]),
                ),
                _title('DAILY MATCHES'),
                Row(children: [
                  Expanded(child: _gameCard(games[0], 'assets/images/freefire_card_resource.jpg')),
                  const SizedBox(width: 10),
                  Expanded(child: _gameCard(games[1], 'assets/images/ludo_king_card_resource.jpg')),
                ]),
              ]),
            ),
            Positioned(
              right: 18,
              bottom: 18,
              child: Material(
                color: Colors.white,
                elevation: 4,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => openUrl(context, linkOf(cfg, 'whatsapp')),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: const BoxDecoration(color: Color(0xFF08A85A), shape: BoxShape.circle),
                      child: Image.asset('assets/images/whatsapp_icon.png', width: 22, height: 22),
                    ),
                  ),
                ),
              ),
            ),
          ]);
        },
      );
}

// ---------------- Matches of one game ----------------
class GameMatchesPage extends StatefulWidget {
  final GameInfo game;
  const GameMatchesPage({super.key, required this.game});
  @override
  State<GameMatchesPage> createState() => _GameMatchesPageState();
}

class _GameMatchesPageState extends State<GameMatchesPage> {
  late Future<Map<String, dynamic>> _f;
  String _query = '';
  String _status = 'all';
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final list = await sb
        .from('tournaments')
        .select()
        .eq('game', widget.game.key)
        .inFilter('status', ['open', 'live'])
        .order('starts_at', ascending: true)
        .limit(50);
    final mine = await sb.from('participants').select('tournament_id').eq('user_id', me);
    return {'list': list, 'mine': {for (final m in mine) '${m['tournament_id']}'}};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _join(Map<String, dynamic> t) async {
    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': t['id']}), ok: 'জয়েন সফল হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _room(Map<String, dynamic> t, bool joined) async {
    if (!joined) {
      toast(context, 'আপনি এখনো ম্যাচটিতে জয়েন করেননি');
      return;
    }
    try {
      final r = await sb.from('tournament_rooms').select().eq('tournament_id', t['id']).maybeSingle();
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('ROOM INFO'),
          content: r == null || ('${r['room_id'] ?? ''}'.isEmpty)
              ? const Text('রুমের তথ্য এখনো দেওয়া হয়নি। ম্যাচ শুরুর আগে এখানে দেখতে পাবেন।')
              : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _copyRow(context, 'রুম আইডি', '${r['room_id']}'),
                  const SizedBox(height: 6),
                  _copyRow(context, 'পাসওয়ার্ড', '${r['room_password'] ?? '-'}'),
                ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
        ),
      );
    } catch (e) {
      if (mounted) toast(context, errText(e), err: true);
    }
  }

  Widget _stat(String label, Widget value) => Expanded(
        child: Column(children: [
          Text(label, style: const TextStyle(color: Colors.black87, fontSize: 13)),
          const SizedBox(height: 6),
          value,
        ]),
      );

  Widget _coin(dynamic v) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset('assets/images/coin.png', width: 22, height: 22),
        const SizedBox(width: 6),
        Text('$v', style: const TextStyle(color: Colors.black, fontSize: 22, fontWeight: FontWeight.bold)),
      ]);

  Widget _txt(String v) => Text(v, style: const TextStyle(color: Colors.black, fontSize: 21, fontWeight: FontWeight.bold));

  Widget _card(Map<String, dynamic> t, bool joined) {
    final g = widget.game;
    final slots = (t['slots'] as num).toInt();
    final cnt = (t['joined'] as num).toInt();
    final full = cnt >= slots;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Row(children: [
          CircleAvatar(radius: 28, backgroundColor: g.gradient.last, child: Icon(g.icon, color: Colors.white, size: 32)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${t['title']}', style: const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)),
              const Row(children: [
                Icon(Icons.flash_on, color: Colors.amber, size: 18),
                Icon(Icons.flash_on, color: Colors.amber, size: 18),
              ]),
              Text(whenShort(t['starts_at']), style: const TextStyle(color: Color(0xFFC40000), fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
        const SizedBox(height: 6),
        Row(children: [
          const Icon(Icons.timer_outlined, size: 16, color: Colors.black54),
          const SizedBox(width: 4),
          _CountdownText(startsAt: '${t['starts_at']}', style: const TextStyle(color: Colors.black87, fontSize: 15, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 14),
        // পুরনো অ্যাপের মতো: FF-তে TOTAL PRIZE / PER KILL / ENTRY FEE,
        // Ludo-তে WIN PRIZE / ENTRY FEE।
        Row(children: [
          _stat(widget.game.key == 'Free Fire' ? 'TOTAL PRIZE' : 'WIN PRIZE', _coin(t['prize_pool'])),
          if (widget.game.key == 'Free Fire') _stat('PER KILL', _coin(t['per_kill'] ?? 0)),
          _stat('ENTRY FEE', _coin(t['fee'])),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          _stat('TYPE', _txt('${t['mode'] ?? '-'}')),
          if (widget.game.key == 'Free Fire') _stat('VERSION', _txt('${t['version'] ?? '-'}')),
          _stat(g.boardLabel, _txt('${t['board'] ?? '-'}'.toUpperCase())),
        ]),
        const SizedBox(height: 12),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              LinearProgressIndicator(value: slots == 0 ? 0 : cnt / slots, minHeight: 4, backgroundColor: Colors.black12, color: const Color(0xFF6EC6F0)),
              const SizedBox(height: 10),
              Padding(padding: const EdgeInsets.only(right: 12), child: Text('$cnt / $slots', style: const TextStyle(color: Colors.black87, fontSize: 16))),
            ]),
          ),
          const SizedBox(width: 12),
          Material(
            color: Colors.white,
            elevation: 3,
            borderRadius: BorderRadius.circular(6),
            child: InkWell(
              borderRadius: BorderRadius.circular(6),
              onTap: (joined || full) ? null : () => _join(t),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
                child: Text(joined ? 'JOINED' : (full ? 'Seat Full' : 'JOIN'),
                    style: TextStyle(color: (joined || full) ? Colors.black38 : Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: _darkBtn('DETAILS', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TournamentPage(id: '${t['id']}')))),
          ),
          const SizedBox(width: 12),
          Expanded(child: _darkBtn('ROOM INFO', () => _room(t, joined))),
        ]),
      ]),
    );
  }

  Widget _darkBtn(String label, VoidCallback onTap) => Material(
        color: cardDark,
        borderRadius: BorderRadius.circular(6),
        child: InkWell(
          borderRadius: BorderRadius.circular(6),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17))),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(
          backgroundColor: widget.game.appBar,
          foregroundColor: Colors.white,
          title: Text('${widget.game.title.replaceAll('Ludu King', 'Ludu')} Matches', style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: CircleAvatar(
                backgroundColor: const Color(0xFF1E88E5),
                child: IconButton(
                  icon: const Icon(Icons.ios_share, color: Colors.white),
                  onPressed: () async {
                    await Clipboard.setData(const ClipboardData(text: 'Amar E-sports-এ দৈনিক ম্যাচ খেলুন এবং জিতুন প্রাইজ!'));
                    if (context.mounted) toast(context, 'শেয়ারের লেখা কপি হয়েছে');
                  },
                ),
              ),
            ),
          ],
        ),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final all = d['list'] as List<dynamic>;
            final q = _query.trim().toLowerCase();
            final list = all.where((e) {
              final t = e as Map<String, dynamic>;
              if (q.isNotEmpty && !'${t['title'] ?? ''}'.toLowerCase().contains(q)) return false;
              if (_status == 'open' && t['status'] != 'open') return false;
              if (_status == 'live' && t['status'] != 'live') return false;
              return true;
            }).toList();
            final mine = d['mine'] as Set<String>;
            return Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
                child: TextField(
                  decoration: const InputDecoration(hintText: 'ম্যাচ খুঁজুন…', prefixIcon: Icon(Icons.search), border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
                  onChanged: (v) => setState(() => _query = v),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Row(children: [
                  for (final e in _statusLabels.entries)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: _status == e.key,
                        onSelected: (_) => setState(() => _status = e.key),
                      ),
                    ),
                ]),
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _refresh,
                  child: list.isEmpty
                      ? ListView(children: const [SizedBox(height: 200), Center(child: Text('এখন কোনো ম্যাচ নেই'))])
                      : ListView(children: [for (final t in list) _card(t as Map<String, dynamic>, mine.contains('${t['id']}'))]),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.info_outline, color: Color(0xFF6EC6F0), size: 20),
                  SizedBox(width: 8),
                  Text('Join a match and win exciting prizes. Good luck!', style: TextStyle(color: Colors.white70)),
                ]),
              ),
            ]);
          },
        ),
      );
}

// ---------------- Match details ----------------
class TournamentPage extends StatefulWidget {
  final String id;
  const TournamentPage({super.key, required this.id});
  @override
  State<TournamentPage> createState() => _TournamentPageState();
}

class _TournamentPageState extends State<TournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final me = sb.auth.currentUser!.id;
    final p = await sb.from('participants').select().eq('tournament_id', widget.id).eq('user_id', me).maybeSingle();
    Map<String, dynamic>? room;
    if (p != null) room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    final cfg = await loadConfig();
    return {'t': t, 'joined': p != null, 'room': room, 'cfg': cfg};
  }

  void _reload() => setState(() => _f = _load());

  Future<void> _showParticipants() async {
    List<dynamic> players;
    try {
      players = await sb.from('participants').select().eq('tournament_id', widget.id).order('joined_at', ascending: true) as List;
    } catch (e) {
      if (mounted) toast(context, errText(e), err: true);
      return;
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Participants', textAlign: TextAlign.center),
        content: SizedBox(
          width: double.maxFinite,
          child: players.isEmpty
              ? const Text('কেউ জয়েন করেনি')
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: players.length,
                  itemBuilder: (c, i) {
                    final p = players[i] as Map<String, dynamic>;
                    return ListTile(
                      title: Text('${p['name'] ?? ''}'),
                      subtitle: Text('ID: ${p['game_id'] ?? ''}'),
                    );
                  },
                ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CLOSE'))],
      ),
    );
  }

  Widget _prizeBox(String label, String value) => Expanded(
        child: Container(
          height: 64,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.black12),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(label, style: const TextStyle(color: Colors.black87, fontSize: 13)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(title: const Text('DETAILS')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final joined = d['joined'] == true;
            final room = d['room'] as Map<String, dynamic>?;
            final cfg = d['cfg'] as Map<String, dynamic>;
            final g = gameOf('${t['game']}');
            final open = t['status'] == 'open' && (t['joined'] as int) < (t['slots'] as int);
            final me = sb.auth.currentUser!.id;
            int? myPrize;
            if (t['winners'] is List) {
              for (final w in t['winners']) {
                if (w['user_id'] == me) myPrize = (w['prize'] as num).toInt();
              }
            }
            // প্রাইজ ব্রেকডাউন: অ্যাডমিনের দেওয়া ১ম–৫ম প্রাইজ (prizes অ্যারে)।
            final pr = t['prizes'];
            String prizeAt(int i) {
              if (pr is List && pr.length > i && pr[i] != null) return '${pr[i]}';
              return '';
            }

            // এই গেমের নিয়ম (app_config rules_ff / rules_ludo); না থাকলে DEFAULT।
            final rulesKey = g.key == 'Ludo King' ? 'rules_ludo' : 'rules_ff';
            var rules = '';
            final rv = cfg[rulesKey];
            if (rv is String) rules = rv.trim();
            if (rules.isEmpty) rules = 'DEFAULT';
            final bannerAsset = g.key == 'Ludo King'
                ? 'assets/images/ludo_king_card_resource.jpg'
                : 'assets/images/freefire_background.jpg';
            return ListView(padding: const EdgeInsets.all(16), children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(bannerAsset, height: 170, width: double.infinity, fit: BoxFit.cover),
              ),
              const SizedBox(height: 14),
              Text('${t['title']}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(whenShort(t['starts_at']), style: const TextStyle(color: Color(0xFFC40000), fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.timer_outlined, size: 16, color: Colors.white70),
                const SizedBox(width: 4),
                _CountdownText(startsAt: '${t['starts_at']}', style: const TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.bold)),
              ]),
              const SizedBox(height: 16),
              Row(children: [
                _prizeBox('1st Prize', prizeAt(0)),
                _prizeBox('2nd Prize', prizeAt(1)),
                _prizeBox('3rd Prize', prizeAt(2)),
                _prizeBox('4th Prize', prizeAt(3)),
                _prizeBox('5th Prize', prizeAt(4)),
              ]),
              const SizedBox(height: 20),
              const Text('RULES AND REGULATIONS', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(rules, style: const TextStyle(color: Colors.white, fontSize: 16, height: 1.6)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _showParticipants,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                  ),
                  child: const Text('SHOW PARTICIPANTS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 16),
              if (myPrize != null) Card(child: ListTile(leading: const Icon(Icons.emoji_events, color: Colors.amber), title: Text('আপনি জিতেছেন ${taka(myPrize)}'))),
              if (joined && room != null && '${room['room_id'] ?? ''}'.isNotEmpty)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      _copyRow(context, 'রুম আইডি', '${room['room_id']}'),
                      const SizedBox(height: 6),
                      _copyRow(context, 'পাসওয়ার্ড', '${room['room_password'] ?? '-'}'),
                    ]),
                  ),
                ),
              if (joined && (room == null || '${room['room_id'] ?? ''}'.isEmpty))
                const Card(child: ListTile(leading: Icon(Icons.hourglass_top), title: Text('রুমের তথ্য শিগগির দেওয়া হবে'))),
              if (joined) const Card(child: ListTile(leading: Icon(Icons.check_circle, color: Colors.greenAccent), title: Text('আপনি এই ম্যাচে জয়েন করেছেন'))),
              if (!joined && open)
                FilledButton(
                  onPressed: () async {
                    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
                    if (!context.mounted) return;
                    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': widget.id}), ok: 'জয়েন সফল হয়েছে');
                    if (ok) _reload();
                  },
                  child: const Text('JOIN'),
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RulesPage(initialGame: g.key))),
                icon: const Icon(Icons.rule),
                label: const Text('ম্যাচের নিয়ম'),
              ),
            ]);
          },
        ),
      );
}

// ---------------- আমার ম্যাচ ----------------
class MyMatchesPage extends StatefulWidget {
  const MyMatchesPage({super.key});
  @override
  State<MyMatchesPage> createState() => _MyMatchesPageState();
}

class _MyMatchesPageState extends State<MyMatchesPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    return sb.from('participants').select('*, tournaments(*)').eq('user_id', me).order('joined_at', ascending: false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(title: const Text('আমার ম্যাচ')),
        body: Loader<List<dynamic>>(
          future: _f,
          builder: (list) {
            if (list.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('আপনি এখনো কোনো ম্যাচে জয়েন করেননি', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
                ),
              );
            }
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (c, idx) {
                final part = list[idx] as Map<String, dynamic>;
                final t = (part['tournaments'] as Map<String, dynamic>?) ?? {};
                final g = gameOf('${t['game']}');
                final me = sb.auth.currentUser!.id;
                int? myPrize;
                if (t['winners'] is List) {
                  for (final w in t['winners']) {
                    if (w is Map && w['user_id'] == me) myPrize = (w['prize'] as num?)?.toInt();
                  }
                }
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(backgroundColor: g.gradient.last, child: Icon(g.icon, color: Colors.white)),
                    title: Text('${t['title'] ?? '-'}'),
                    subtitle: Text(
                      '${statusLabel[t['status']] ?? t['status'] ?? ''} • ${whenShort(t['starts_at'])}${myPrize != null ? '\nআপনি জিতেছেন ${taka(myPrize)}' : ''}',
                    ),
                    isThreeLine: myPrize != null,
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TournamentPage(id: '${t['id']}'))),
                  ),
                );
              },
            );
          },
        ),
      );
}

// ---------------- রেজাল্ট ও লিডারবোর্ড ----------------
class ResultsLeaderboardPage extends StatefulWidget {
  const ResultsLeaderboardPage({super.key});
  @override
  State<ResultsLeaderboardPage> createState() => _ResultsLeaderboardPageState();
}

class _ResultsLeaderboardPageState extends State<ResultsLeaderboardPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final finished = await sb.from('tournaments').select().eq('status', 'finished').order('starts_at', ascending: false).limit(20);
    final board = await sb
        .from('profiles')
        .select('name, phone, total_wins, total_kills')
        .order('total_wins', ascending: false)
        .order('total_kills', ascending: false)
        .limit(20);
    // বিজয়ীদের নাম দেখাতে তাদের প্রোফাইল একবারে নেওয়া হয়।
    final ids = <String>{};
    for (final t in finished) {
      if (t['winners'] is List) {
        for (final w in t['winners']) {
          if (w is Map && w['user_id'] != null) ids.add('${w['user_id']}');
        }
      }
    }
    final names = <String, String>{};
    if (ids.isNotEmpty) {
      final ps = await sb.from('profiles').select('id, name').inFilter('id', ids.toList());
      for (final pr in ps) {
        names['${pr['id']}'] = '${pr['name'] ?? ''}';
      }
    }
    return {'finished': finished, 'board': board, 'names': names};
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(title: const Text('রেজাল্ট ও লিডারবোর্ড')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final finished = d['finished'] as List<dynamic>;
            final board = d['board'] as List<dynamic>;
            final names = d['names'] as Map<String, String>;
            return ListView(padding: const EdgeInsets.all(12), children: [
              const Text('সাম্প্রতিক রেজাল্ট', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (finished.isEmpty)
                const Card(child: ListTile(title: Text('এখনো কোনো ম্যাচ শেষ হয়নি'))),
              for (final t in finished) ...[
                Card(
                  child: ListTile(
                    title: Text('${t['title']}'),
                    subtitle: Text(whenShort(t['starts_at'])),
                    isThreeLine: true,
                  ),
                ),
                if (t['winners'] is List && (t['winners'] as List).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 8, bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (final w in t['winners'])
                          Text(
                            '${names['${w['user_id']}'] ?? '—'} — ${taka(w['prize'])}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                      ],
                    ),
                  ),
              ],
              const SizedBox(height: 16),
              const Text('লিডারবোর্ড (টপ ২০)', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (board.isEmpty) const Card(child: ListTile(title: Text('এখনো কোনো তথ্য নেই'))),
              for (var idx = 0; idx < board.length; idx++)
                Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${idx + 1}')),
                    title: Text('${board[idx]['name'] ?? ''}'),
                    subtitle: Text(maskPhone('${board[idx]['phone'] ?? ''}')),
                    trailing: Text('জয় ${board[idx]['total_wins'] ?? 0}  •  কিল ${board[idx]['total_kills'] ?? 0}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
            ]);
          },
        ),
      );
}

// ---------------- নোটিশ ----------------
class NoticesPage extends StatefulWidget {
  const NoticesPage({super.key});
  @override
  State<NoticesPage> createState() => _NoticesPageState();
}

class _NoticesPageState extends State<NoticesPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() async {
    final cfg = await loadConfig();
    final out = <Map<String, dynamic>>[];
    final n = cfg['notices'];
    if (n is List) {
      for (final e in n) {
        if (e is Map) out.add(Map<String, dynamic>.from(e));
      }
    }
    // অ্যাডমিনের পাঠানো ঘোষণাও (announcements টেবিল) একই পেজে দেখায়।
    try {
      final ann = await sb
          .from('announcements')
          .select('title, body, created_at')
          .order('created_at', ascending: false)
          .limit(20);
      for (final e in (ann as List)) {
        if (e is Map) {
          out.add({'title': e['title'], 'body': e['body'], 'date': whenShort(e['created_at'])});
        }
      }
    } catch (_) {
      // announcements টেবিল এখনো না থাকলে শুধু নোটিশই দেখাবে।
    }
    return out;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(title: const Text('নোটিশ')),
        body: Loader<List<dynamic>>(
          future: _f,
          builder: (list) {
            if (list.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.notifications_off_outlined, size: 56, color: Colors.white38),
                    SizedBox(height: 12),
                    Text('এখনো কোনো নোটিশ নেই', style: TextStyle(color: Colors.white70, fontSize: 17)),
                    SizedBox(height: 6),
                    Text('নতুন নোটিশ এলে এখানে দেখতে পাবেন', style: TextStyle(color: Colors.white38)),
                  ]),
                ),
              );
            }
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (c, idx) {
                final n = list[idx] as Map<String, dynamic>;
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.campaign_outlined),
                    title: Text('${n['title'] ?? 'নোটিশ'}'),
                    subtitle: Text('${n['body'] ?? ''}${n['date'] != null ? '\n${n['date']}' : ''}'),
                    isThreeLine: true,
                  ),
                );
              },
            );
          },
        ),
      );
}


// ---------------- ম্যাচের নিয়ম ----------------
// নিয়ম আসে app_config থেকে (rules_ff / rules_ludo)।
// কোনো গেমের নিয়ম না থাকলে 'শিগগির আসছে' দেখায়।
class RulesPage extends StatefulWidget {
  final String initialGame;
  const RulesPage({super.key, this.initialGame = 'Free Fire'});
  @override
  State<RulesPage> createState() => _RulesPageState();
}

class _RulesPageState extends State<RulesPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = loadConfig();
  }

  int _tabIndex() {
    final k = widget.initialGame.toLowerCase();
    if (k.contains('ludo')) return 1;
    return 0;
  }

  String _text(Map<String, dynamic> cfg, String key) {
    final v = cfg[key];
    if (v is String) return v.trim();
    if (v == null) return '';
    return '$v'.trim();
  }

  Widget _body(String text) {
    if (text.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.rule, size: 56, color: Colors.white38),
            SizedBox(height: 12),
            Text('নিয়ম শিগগির আসছে', style: TextStyle(color: Colors.white70, fontSize: 17)),
            SizedBox(height: 6),
            Text('এই গেমের নিয়ম এখনো দেওয়া হয়নি', style: TextStyle(color: Colors.white38)),
          ]),
        ),
      );
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 16, height: 1.6)),
    );
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        initialIndex: _tabIndex(),
        child: Scaffold(
          backgroundColor: navy,
          appBar: AppBar(
            title: const Text('ম্যাচের নিয়ম'),
            bottom: const TabBar(tabs: [
              Tab(text: 'Free Fire'),
              Tab(text: 'Ludo King'),
            ]),
          ),
          body: Loader<Map<String, dynamic>>(
            future: _f,
            builder: (cfg) => TabBarView(children: [
              _body(_text(cfg, 'rules_ff')),
              _body(_text(cfg, 'rules_ludo')),
            ]),
          ),
        ),
      );
}


// ---------------- Me ----------------
class ProfilePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const ProfilePage({super.key, required this.profile, required this.onChanged});

  Widget _statCard(String value, String label) => Expanded(
        child: Container(
          height: 106,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(7)),
          alignment: Alignment.center,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(value, style: const TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(label, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black, fontSize: 16, height: 1.12, fontWeight: FontWeight.w800)),
          ]),
        ),
      );

  Widget _menu(BuildContext context, IconData icon, String title, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
          child: InkWell(
            borderRadius: BorderRadius.circular(5),
            onTap: onTap,
            child: SizedBox(height: 48, child: Row(children: [
              const SizedBox(width: 27),
              Icon(icon, color: Colors.black, size: 21),
              const SizedBox(width: 20),
              Expanded(child: Text(title, style: const TextStyle(color: Colors.black, fontSize: 19, fontWeight: FontWeight.w800))),
            ])),
          ),
        ),
      );

  /// পুরনো অ্যাপের প্রোফাইল শিট: মোবাইল নম্বর, মেইল ঠিকানা, এডিটেবল
  /// নাম/গেম আইডি, টিল SAVE ও CHANGE PASSWORD বোতাম।
  Future<void> _edit(BuildContext context) async {
    final phone = '${profile['phone'] ?? ''}';
    final nameC = TextEditingController(text: '${profile['name'] ?? ''}');
    final gameC = TextEditingController(text: '${profile['game_id'] ?? ''}');
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('My Profile', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Your Mobile Number', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
              Text(phone, style: const TextStyle(color: Colors.black, fontSize: 17)),
              const SizedBox(height: 12),
              const Text('Your Mail Address', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
              Text(emailOf(phone), style: const TextStyle(color: Colors.black, fontSize: 17)),
              const SizedBox(height: 16),
              TextField(controller: nameC, decoration: const InputDecoration(labelText: 'নাম', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(controller: gameC, decoration: const InputDecoration(labelText: 'গেম আইডি', border: OutlineInputBorder())),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, 'save'),
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1FB6C9), foregroundColor: Colors.white),
                  child: const Text('SAVE', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, 'password'),
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1FB6C9), foregroundColor: Colors.white),
                  child: const Text('CHANGE PASSWORD', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (choice == 'save' && context.mounted) {
      final ok = await run(context, () => sb.from('profiles').update({'name': nameC.text.trim(), 'game_id': gameC.text.trim()}).eq('id', sb.auth.currentUser!.id), ok: 'আপডেট হয়েছে');
      if (ok) onChanged();
    } else if (choice == 'password' && context.mounted) {
      _changePassword(context);
    }
  }

  /// পুরনো অ্যাপের Customer Support ডায়ালগ: TELEGRAM / MAIL US / ORDER AN APP।
  Future<void> _support(BuildContext context) async {
    final cfg = await loadConfig();
    final links = cfg['links'];
    String url(String key) => links is Map ? '${links[key] ?? ''}' : '';
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Customer Support', textAlign: TextAlign.center, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _supportBtn('TELEGRAM', () async {
              Navigator.pop(ctx);
              await openUrl(context, url('telegram'));
            }),
            const SizedBox(height: 10),
            _supportBtn('MAIL US', () async {
              Navigator.pop(ctx);
              final mail = url('email');
              if (mail.isEmpty) {
                toast(context, 'ইমেইল এখনো সেট করা হয়নি');
                return;
              }
              await openUrl(context, mail.startsWith('mailto:') ? mail : 'mailto:$mail');
            }),
            const SizedBox(height: 10),
            _supportBtn('ORDER AN APP', () async {
              Navigator.pop(ctx);
              await openUrl(context, url('order_app'));
            }),
          ],
        ),
      ),
    );
  }

  Widget _supportBtn(String label, VoidCallback onTap) => SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton(
          onPressed: onTap,
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A0A1F), foregroundColor: Colors.white),
          child: Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ),
      );

  Future<void> _changePassword(BuildContext context) async {
    final m = await showForm(context, 'পাসওয়ার্ড বদলান', const [
      F('current', 'বর্তমান পাসওয়ার্ড', obscure: true),
      F('new', 'নতুন পাসওয়ার্ড (কমপক্ষে ৬)', obscure: true),
      F('confirm', 'নতুন পাসওয়ার্ড আবার', obscure: true),
    ], ok: 'বদলান');
    if (m == null || !context.mounted) return;
    if (m['new']!.length < 6) {
      toast(context, 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে', err: true);
      return;
    }
    if (m['new'] != m['confirm']) {
      toast(context, 'দুটো নতুন পাসওয়ার্ড মিলছে না', err: true);
      return;
    }
    final phone = '${profile['phone'] ?? ''}';
    await run(context, () async {
      // বর্তমান পাসওয়ার্ড দিয়ে আবার লগইন করে পরিচয় যাচাই, তারপর নতুন পাসওয়ার্ড বসানো হয়।
      await sb.auth.signInWithPassword(email: emailOf(phone), password: m['current']!);
      await sb.auth.updateUser(UserAttributes(password: m['new']!));
    }, ok: 'পাসওয়ার্ড বদলানো হয়েছে');
  }

  Future<void> _openConfigured(BuildContext context, String key) async {
    try {
      final cfg = await loadConfig();
      final links = cfg['links'];
      final url = links is Map ? '${links[key] ?? ''}' : '';
      if (context.mounted) await openUrl(context, url);
    } catch (_) {
      if (context.mounted) toast(context, 'লিংক লোড করা যায়নি', err: true);
    }
  }

  Future<void> _openWhatsApp(BuildContext context) async {
    try {
      final cfg = await loadConfig();
      if (context.mounted) await openUrl(context, linkOf(cfg, 'whatsapp'));
    } catch (_) {
      if (context.mounted) toast(context, 'লিংক লোড করা যায়নি', err: true);
    }
  }

  Widget _header(BuildContext context) => LayoutBuilder(builder: (context, constraints) {
        return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          ClipOval(child: Image.asset('assets/images/logo.png', width: 34, height: 34, fit: BoxFit.cover)),
          const SizedBox(width: 9),
          const Expanded(child: Text('Amar E-sports', maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: .2, color: Colors.white))),
          const SizedBox(width: 6),
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage())),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFF07112E), size: 22),
                const SizedBox(width: 5),
                Text('${money(profile['balance'] ?? 0).replaceAll('.00', '').replaceAll('৳', '').trim()} ৳',
                    style: const TextStyle(color: Color(0xFF07112E), fontSize: 18, fontWeight: FontWeight.w900)),
              ]),
            ),
          ),
        ]);
      });

  @override
  Widget build(BuildContext context) {
    final phone = '${profile['phone'] ?? ''}';
    final played = '${profile['matches_played'] ?? 0}';
    final kills = '${profile['total_kills'] ?? 0}';
    final wins = '${profile['total_wins'] ?? 0}';
    return LayoutBuilder(builder: (context, constraints) {
      final horizontal = constraints.maxWidth < 380 ? 12.0 : 15.0;
      return Stack(children: [
        ListView(padding: EdgeInsets.fromLTRB(horizontal, 8, horizontal, 78), children: [
          _header(context),
          const SizedBox(height: 17),
          const Center(child: Icon(Icons.sports_esports, size: 34, color: Colors.white)),
          const SizedBox(height: 7),
          Center(child: Text(phone, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: .5))),
          const SizedBox(height: 30),
          Container(height: 106, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(7)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${profile['balance'] ?? 0}', style: const TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('Available Balance', style: TextStyle(color: Colors.black, fontSize: 17, fontWeight: FontWeight.w800)),
            ])),
          const SizedBox(height: 11),
          Row(children: [_statCard(played, 'Match\nPlayed'), _statCard(kills, 'Total Kills'), _statCard(wins, 'Total Wins')]),
          const SizedBox(height: 12),
          _menu(context, Icons.account_circle, 'My Profile', () => _edit(context)),
          _menu(context, Icons.account_balance_wallet, 'My Wallet', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()))),
          _menu(context, Icons.help, 'Customer Support', () => _support(context)),
          _menu(context, Icons.shopping_bag, 'Topup Diamonds', () => _openConfigured(context, 'topup')),
          _menu(context, Icons.play_circle, 'How to play?', () => _openConfigured(context, 'how_to_play')),
          _menu(context, Icons.play_circle, 'YouTube Channel', () => _openConfigured(context, 'youtube')),
          _menu(context, Icons.sports_score, 'আমার ম্যাচ', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyMatchesPage()))),
          _menu(context, Icons.leaderboard, 'রেজাল্ট ও লিডারবোর্ড', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ResultsLeaderboardPage()))),
          _menu(context, Icons.notifications, 'নোটিশ', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NoticesPage()))),
          _menu(context, Icons.rule, 'ম্যাচের নিয়ম', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RulesPage()))),
          _menu(context, Icons.lock_reset, 'পাসওয়ার্ড বদলান', () => _changePassword(context)),
          _menu(context, Icons.person, 'Logout', () => sb.auth.signOut()),
          const SizedBox(height: 2),
          const Center(child: Text('Version: 1.1', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800))),
        ]),
        Positioned(
          right: 18,
          bottom: 18,
          child: Material(
            color: Colors.white,
            elevation: 3,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => _openWhatsApp(context),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(color: Color(0xFF08A85A), shape: BoxShape.circle),
                  child: Image.asset('assets/images/whatsapp_icon.png', width: 22, height: 22),
                ),
              ),
            ),
          ),
        ),
      ]);
    });
  }
}
