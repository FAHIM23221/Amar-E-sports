const supabaseUrl = 'https://lvswoeczabkfspypxjvi.supabase.co';
// Public anon key (safe to ship in the app; security is enforced by RLS in the database).
const supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx2c3dvZWN6YWJrZnNweXB4anZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ4OTc0OTAsImV4cCI6MjExMDQ3MzQ5MH0.uYz7FR0a7-awJv-8PA2DPbMJkULQ9IfM9g43u4gruPE';
const phoneDomain = 'amaresports.app';
