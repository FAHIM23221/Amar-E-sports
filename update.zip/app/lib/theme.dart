import 'package:flutter/material.dart';

const navy = Color(0xFF050B1F);
const navy2 = Color(0xFF0B1330);
const cardDark = Color(0xFF0A0A1F);
const ffTeal = Color(0xFF0E9F85);
const ludoGreen = Color(0xFF0B6B1A);
const ludoRed = Color(0xFFB30000);
const csOrange = Color(0xFFE65100);

class GameInfo {
  final String key; // stored in tournaments.game
  final String title;
  final Color appBar;
  final List<Color> gradient;
  final IconData icon;
  final String boardLabel;
  const GameInfo(this.key, this.title, this.appBar, this.gradient, this.icon, this.boardLabel);
}

const games = [
  GameInfo('Free Fire', 'Free Fire', ffTeal, [Color(0xFF0B7D6A), Color(0xFF12B398)], Icons.local_fire_department, 'MAP'),
  GameInfo('Ludo King', 'Ludu King', ludoGreen, [Color(0xFF8E0000), Color(0xFFD10F0F)], Icons.casino, 'BOARD TYPE'),
  // CS: key 'cs' — কোনো ছবি নেই বলে গ্রেডিয়েন্ট কার্ড দিয়ে দেখানো হয় (home.dart-এ _gameCard দেখুন)।
  GameInfo('cs', 'CS', csOrange, [Color(0xFF7A3E00), Color(0xFFFF8F00)], Icons.gps_fixed, 'MAP'),
];

GameInfo gameOf(String? key) {
  final k = (key ?? '').toLowerCase();
  return games.firstWhere((g) => g.key.toLowerCase() == k, orElse: () => games.first);
}
