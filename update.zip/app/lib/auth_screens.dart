import 'dart:math';
import 'package:android_id/android_id.dart';
import 'package:flutter/material.dart';
import 'util.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  bool _register = false;
  bool _busy = false;

  Future<void> _submit() async {
    final phone = _phone.text.trim();
    final pass = _pass.text;
    if (!phoneRe.hasMatch(phone)) {
      toast(context, 'সঠিক মোবাইল নম্বর দিন (যেমন 01XXXXXXXXX)', err: true);
      return;
    }
    if (pass.length < 6) {
      toast(context, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে', err: true);
      return;
    }
    setState(() => _busy = true);
    await run(context, () async {
      if (_register) {
        final r = await sb.auth.signUp(email: emailOf(phone), password: pass);
        if (r.session == null) {
          throw 'অ্যাকাউন্ট খোলা যায়নি, অ্যাডমিনের সঙ্গে যোগাযোগ করুন';
        }
      } else {
        await sb.auth.signInWithPassword(email: emailOf(phone), password: pass);
      }
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.sports_esports, size: 72),
                const SizedBox(height: 8),
                const Text('Amar E-sports', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                const SizedBox(height: 24),
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  maxLength: 11,
                  decoration: const InputDecoration(labelText: 'মোবাইল নম্বর', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'পাসওয়ার্ড', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: Text(_register ? 'অ্যাকাউন্ট খুলুন' : 'লগইন'),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() => _register = !_register),
                  child: Text(_register ? 'আগে থেকে অ্যাকাউন্ট আছে? লগইন করুন' : 'নতুন অ্যাকাউন্ট খুলুন'),
                ),
                const Text('পাসওয়ার্ড ভুলে গেলে অ্যাডমিনের সঙ্গে যোগাযোগ করুন',
                    style: TextStyle(fontSize: 12), textAlign: TextAlign.center),
              ]),
            ),
          ),
        ),
      );
}

class CompleteProfileScreen extends StatefulWidget {
  final VoidCallback onDone;
  const CompleteProfileScreen({super.key, required this.onDone});
  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final _name = TextEditingController();
  final _game = TextEditingController();
  final _ref = TextEditingController();
  bool _busy = false;

  Future<String> _deviceId() async {
    try {
      final id = await AndroidId().getId();
      if (id != null && id.isNotEmpty) return id;
    } catch (_) {}
    return 'rnd-${Random.secure().nextInt(1 << 31)}-${DateTime.now().microsecondsSinceEpoch}';
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _game.text.trim().isEmpty) {
      toast(context, 'নাম ও গেম আইডি দিন', err: true);
      return;
    }
    setState(() => _busy = true);
    final dev = await _deviceId();
    final ok = await run(context, () => sb.rpc('create_profile', params: {
          'p_name': _name.text.trim(),
          'p_game_id': _game.text.trim(),
          'p_device': dev,
          'p_referral': _ref.text.trim(),
        }));
    if (ok) widget.onDone();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('প্রোফাইল সম্পূর্ণ করুন'), actions: [
          TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
        ]),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'আপনার নাম', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _game, decoration: const InputDecoration(labelText: 'Free Fire / গেম আইডি', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _ref, decoration: const InputDecoration(labelText: 'রেফারাল কোড (ঐচ্ছিক)', border: OutlineInputBorder())),
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('সংরক্ষণ করুন')),
        ]),
      );
}

class BannedScreen extends StatelessWidget {
  const BannedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.block, size: 64, color: Colors.red),
              const SizedBox(height: 12),
              const Text('আপনার অ্যাকাউন্ট ব্যান করা হয়েছে। অ্যাডমিনের সঙ্গে যোগাযোগ করুন।',
                  textAlign: TextAlign.center),
              TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
            ]),
          ),
        ),
      );
}
