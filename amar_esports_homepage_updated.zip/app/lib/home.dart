import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'wallet.dart';

const ledgerLabel = {
  'deposit': 'ডিপোজিট',
  'join_fee': 'জয়েন ফি',
  'prize': 'প্রাইজ',
  'withdraw_hold': 'উইথড্র (আটকানো)',
  'withdraw_refund': 'উইথড্র ফেরত',
  'refund': 'ফি ফেরত',
};

// ---------------- Shell: Play / Me ----------------
class HomeShell extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onProfileChanged;
  const HomeShell({super.key, required this.profile, required this.onProfileChanged});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF030B2B),
        body: SafeArea(
          child: IndexedStack(index: _i, children: [
            const PlayPage(),
            ProfilePage(profile: widget.profile, onChanged: widget.onProfileChanged),
          ]),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            height: 76,
            decoration: const BoxDecoration(color: Color(0xFF030B2B)),
            child: Row(children: [
              _navItem(Icons.games, 'Play', 0),
              _navItem(Icons.account_circle, 'Me', 1),
            ]),
          ),
        ),
      );

  Widget _navItem(IconData icon, String label, int index) {
    final selected = _i == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _i = index),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 32, color: selected ? const Color(0xFFE6E9F5) : Colors.white38),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 16, color: selected ? const Color(0xFFE6E9F5) : Colors.white38)),
        ]),
      ),
    );
  }
}

// ---------------- Home (Play) ----------------
const _defaultBanners = [
  {'title': 'কিভাবে খেলবেন?', 'subtitle': 'ভিডিওটি দেখুন', 'url': '', 'image': ''},
  {'title': 'Telegram কমিউনিটিতে যোগ দিন', 'subtitle': '', 'url': '', 'image': ''},
  {'title': 'WhatsApp সাপোর্ট', 'subtitle': '', 'url': '', 'image': ''},
];

const _bannerColors = [
  [Color(0xFF3B0A2A), Color(0xFF0B1B4A)],
  [Color(0xFF0A3D62), Color(0xFF1B1464)],
  [Color(0xFF0B4F2B), Color(0xFF062A16)],
];

class PlayPage extends StatefulWidget {
  const PlayPage({super.key});
  @override
  State<PlayPage> createState() => _PlayPageState();
}

class _PlayPageState extends State<PlayPage> {
  late Future<Map<String, dynamic>> _f;
  final _pc = PageController();
  Timer? _timer;
  int _page = 0;
  int _count = 3;

  @override
  void initState() {
    super.initState();
    _f = _load();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!_pc.hasClients || _count < 2) return;
      _pc.animateToPage((_page + 1) % _count, duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select('balance').eq('user_id', me).maybeSingle();
    final cfg = await loadConfig();
    return {'balance': w?['balance'] ?? 0, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 30, bottom: 34),
        child: Row(children: [
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600, letterSpacing: 0.2, fontSize: 23, color: Colors.white)),
          ),
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
        ]),
      );

  Widget _banner(Map b, int i, Map<String, dynamic> cfg) {
    final colors = _bannerColors[i % _bannerColors.length];
    final img = '${b['image'] ?? ''}'.trim();
    final useReferenceBanner = img.isEmpty && i == 0;
    final hasImage = img.isNotEmpty || useReferenceBanner;
    return GestureDetector(
      onTap: () => openUrl(context, '${b['url'] ?? ''}'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 1),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (useReferenceBanner)
            Image.asset('assets/images/home_banner_reference.jpg', fit: BoxFit.cover)
          else if (img.isNotEmpty)
            Image.network(img, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
          if (!hasImage)
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${b['title'] ?? ''}',
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, height: 1.1, shadows: [Shadow(blurRadius: 8, color: Colors.black54)])),
                if ('${b['subtitle'] ?? ''}'.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text('${b['subtitle']}', style: const TextStyle(fontSize: 20, color: Color(0xFF2DFFA0), fontWeight: FontWeight.w600)),
                  ),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _gameCard(GameInfo g, String asset) => Expanded(
        child: GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GameMatchesPage(game: g))),
          child: AspectRatio(
            aspectRatio: 1.67,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(7),
              child: Image.asset(asset, fit: BoxFit.cover),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        future: _f,
        builder: (d) {
          final cfg = d['cfg'] as Map<String, dynamic>;
          final raw = cfg['banners'];
          final banners = (raw is List && raw.isNotEmpty) ? raw : _defaultBanners;
          _count = banners.length;
          return Stack(children: [
            RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 100), children: [
                Row(children: [
                  ClipOval(child: Image.asset('assets/images/logo.png', width: 48, height: 48, fit: BoxFit.cover)),
                  const SizedBox(width: 14),
                  const Expanded(child: Text('Tournament Zone', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: Colors.white))),
                  InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()));
                      _refresh();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFF07112E), size: 28),
                        const SizedBox(width: 7),
                        Text(money(d['balance']).replaceAll('.00', ''), style: const TextStyle(color: Color(0xFF07112E), fontSize: 22, fontWeight: FontWeight.w800)),
                      ]),
                    ),
                  ),
                ]),
                const SizedBox(height: 18),
                AspectRatio(
                  aspectRatio: 1.84,
                  child: Stack(children: [
                    PageView.builder(
                      controller: _pc,
                      itemCount: banners.length,
                      onPageChanged: (v) => setState(() => _page = v),
                      itemBuilder: (c, i) => _banner(banners[i] as Map, i, cfg),
                    ),
                    Positioned(
                      bottom: 10,
                      left: 0,
                      right: 0,
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        for (var i = 0; i < banners.length; i++)
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: 17,
                            height: 17,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: i == _page ? Colors.white70 : Colors.white38),
                          ),
                      ]),
                    ),
                  ]),
                ),
                _title('DAILY MATCHES'),
                Row(children: [
                  _gameCard(games[0], 'assets/images/home_freefire_card.jpg'),
                  const SizedBox(width: 28),
                  _gameCard(games[1], 'assets/images/home_ludo_card.jpg'),
                ]),
              ]),
            ),
            Positioned(
              right: 18,
              bottom: 18,
              child: Material(
                color: Colors.white,
                elevation: 4,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => openUrl(context, linkOf(cfg, 'whatsapp')),
                  child: Padding(
                    padding: const EdgeInsets.all(17),
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: const BoxDecoration(color: Color(0xFF08A85A), shape: BoxShape.circle),
                      child: const Icon(Icons.chat, color: Colors.white, size: 23),
                    ),
                  ),
                ),
              ),
            ),
          ]);
        },
      );
}

// ---------------- Matches of one game ----------------
class GameMatchesPage extends StatefulWidget {
  final GameInfo game;
  const GameMatchesPage({super.key, required this.game});
  @override
  State<GameMatchesPage> createState() => _GameMatchesPageState();
}

class _GameMatchesPageState extends State<GameMatchesPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final list = await sb
        .from('tournaments')
        .select()
        .eq('game', widget.game.key)
        .inFilter('status', ['open', 'live'])
        .order('starts_at', ascending: true)
        .limit(50);
    final mine = await sb.from('participants').select('tournament_id').eq('user_id', me);
    return {'list': list, 'mine': {for (final m in mine) '${m['tournament_id']}'}};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _join(Map<String, dynamic> t) async {
    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': t['id']}), ok: 'জয়েন সফল হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _room(Map<String, dynamic> t, bool joined) async {
    if (!joined) {
      toast(context, 'রুমের তথ্য দেখতে আগে ম্যাচে জয়েন করুন');
      return;
    }
    try {
      final r = await sb.from('tournament_rooms').select().eq('tournament_id', t['id']).maybeSingle();
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('ROOM INFO'),
          content: r == null || ('${r['room_id'] ?? ''}'.isEmpty)
              ? const Text('রুমের তথ্য এখনো দেওয়া হয়নি। ম্যাচ শুরুর আগে এখানে দেখতে পাবেন।')
              : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Room ID: ${r['room_id']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('Password: ${r['room_password'] ?? '-'}', style: const TextStyle(fontSize: 18)),
                ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
        ),
      );
    } catch (e) {
      if (mounted) toast(context, errText(e), err: true);
    }
  }

  Widget _stat(String label, Widget value) => Expanded(
        child: Column(children: [
          Text(label, style: const TextStyle(color: Colors.black87, fontSize: 15)),
          const SizedBox(height: 6),
          value,
        ]),
      );

  Widget _coin(dynamic v) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset('assets/images/coin.png', width: 26, height: 26),
        const SizedBox(width: 6),
        Text('$v', style: const TextStyle(color: Colors.black, fontSize: 26, fontWeight: FontWeight.bold)),
      ]);

  Widget _txt(String v) => Text(v, style: const TextStyle(color: Colors.black, fontSize: 21, fontWeight: FontWeight.bold));

  Widget _card(Map<String, dynamic> t, bool joined) {
    final g = widget.game;
    final slots = (t['slots'] as num).toInt();
    final cnt = (t['joined'] as num).toInt();
    final full = cnt >= slots;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Row(children: [
          CircleAvatar(radius: 28, backgroundColor: g.gradient.last, child: Icon(g.icon, color: Colors.white, size: 32)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${t['title']}', style: const TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
              Text(whenShort(t['starts_at']), style: const TextStyle(color: Color(0xFFC40000), fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
        const SizedBox(height: 14),
        Row(children: [_stat('WIN PRIZE', _coin(t['prize_pool'])), _stat('ENTRY FEE', _coin(t['fee']))]),
        const SizedBox(height: 14),
        Row(children: [
          _stat('TYPE', _txt('${t['mode'] ?? '-'}')),
          _stat(g.boardLabel, _txt('${t['board'] ?? '-'}'.toUpperCase())),
        ]),
        const SizedBox(height: 12),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              LinearProgressIndicator(value: slots == 0 ? 0 : cnt / slots, minHeight: 4, backgroundColor: Colors.black12, color: const Color(0xFF6EC6F0)),
              const SizedBox(height: 10),
              Padding(padding: const EdgeInsets.only(right: 12), child: Text('$cnt / $slots', style: const TextStyle(color: Colors.black87, fontSize: 16))),
            ]),
          ),
          const SizedBox(width: 12),
          Material(
            color: Colors.white,
            elevation: 3,
            borderRadius: BorderRadius.circular(6),
            child: InkWell(
              borderRadius: BorderRadius.circular(6),
              onTap: (joined || full) ? null : () => _join(t),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
                child: Text(joined ? 'JOINED' : (full ? 'FULL' : 'JOIN'),
                    style: TextStyle(color: (joined || full) ? Colors.black38 : Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: _darkBtn('DETAILS', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TournamentPage(id: '${t['id']}')))),
          ),
          const SizedBox(width: 12),
          Expanded(child: _darkBtn('ROOM INFO', () => _room(t, joined))),
        ]),
      ]),
    );
  }

  Widget _darkBtn(String label, VoidCallback onTap) => Material(
        color: cardDark,
        borderRadius: BorderRadius.circular(6),
        child: InkWell(
          borderRadius: BorderRadius.circular(6),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17))),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(
          backgroundColor: widget.game.appBar,
          foregroundColor: Colors.white,
          title: Text('${widget.game.title.replaceAll('Ludu King', 'Ludu')} Matches', style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: CircleAvatar(
                backgroundColor: const Color(0xFF1E88E5),
                child: IconButton(
                  icon: const Icon(Icons.ios_share, color: Colors.white),
                  onPressed: () async {
                    await Clipboard.setData(const ClipboardData(text: 'Amar E-sports-এ দৈনিক ম্যাচ খেলুন এবং জিতুন প্রাইজ!'));
                    if (context.mounted) toast(context, 'শেয়ারের লেখা কপি হয়েছে');
                  },
                ),
              ),
            ),
          ],
        ),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final list = d['list'] as List<dynamic>;
            final mine = d['mine'] as Set<String>;
            return Column(children: [
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _refresh,
                  child: list.isEmpty
                      ? ListView(children: const [SizedBox(height: 200), Center(child: Text('এখন কোনো ম্যাচ নেই'))])
                      : ListView(children: [for (final t in list) _card(t as Map<String, dynamic>, mine.contains('${t['id']}'))]),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.info_outline, color: Color(0xFF6EC6F0), size: 20),
                  SizedBox(width: 8),
                  Text('Join a match and win exciting prizes. Good luck!', style: TextStyle(color: Colors.white70)),
                ]),
              ),
            ]);
          },
        ),
      );
}

// ---------------- Match details ----------------
class TournamentPage extends StatefulWidget {
  final String id;
  const TournamentPage({super.key, required this.id});
  @override
  State<TournamentPage> createState() => _TournamentPageState();
}

class _TournamentPageState extends State<TournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final me = sb.auth.currentUser!.id;
    final p = await sb.from('participants').select().eq('tournament_id', widget.id).eq('user_id', me).maybeSingle();
    Map<String, dynamic>? room;
    if (p != null) room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    return {'t': t, 'joined': p != null, 'room': room};
  }

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('DETAILS')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final joined = d['joined'] == true;
            final room = d['room'] as Map<String, dynamic>?;
            final g = gameOf('${t['game']}');
            final open = t['status'] == 'open' && (t['joined'] as int) < (t['slots'] as int);
            final me = sb.auth.currentUser!.id;
            int? myPrize;
            if (t['winners'] is List) {
              for (final w in t['winners']) {
                if (w['user_id'] == me) myPrize = (w['prize'] as num).toInt();
              }
            }
            Widget row(String a, String b) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(children: [Expanded(child: Text(a, style: const TextStyle(color: Colors.white70))), Text(b, style: const TextStyle(fontWeight: FontWeight.bold))]),
                );
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('${t['title']}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              row('গেম', g.title),
              row('শুরু', whenShort(t['starts_at'])),
              row('টাইপ', '${t['mode'] ?? '-'}'),
              row(g.boardLabel, '${t['board'] ?? '-'}'),
              row('এন্ট্রি ফি', taka(t['fee'])),
              row('মোট প্রাইজ', taka(t['prize_pool'])),
              row('স্লট', '${t['joined']}/${t['slots']}'),
              const SizedBox(height: 14),
              if (myPrize != null) Card(child: ListTile(leading: const Icon(Icons.emoji_events, color: Colors.amber), title: Text('আপনি জিতেছেন ${taka(myPrize)}'))),
              if (joined && room != null && '${room['room_id'] ?? ''}'.isNotEmpty)
                Card(child: ListTile(leading: const Icon(Icons.key), title: Text('রুম আইডি: ${room['room_id']}'), subtitle: Text('পাসওয়ার্ড: ${room['room_password'] ?? '-'}'))),
              if (joined && (room == null || '${room['room_id'] ?? ''}'.isEmpty))
                const Card(child: ListTile(leading: Icon(Icons.hourglass_top), title: Text('রুমের তথ্য শিগগির দেওয়া হবে'))),
              if (joined) const Card(child: ListTile(leading: Icon(Icons.check_circle, color: Colors.greenAccent), title: Text('আপনি এই ম্যাচে জয়েন করেছেন'))),
              if (!joined && open)
                FilledButton(
                  onPressed: () async {
                    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
                    if (!context.mounted) return;
                    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': widget.id}), ok: 'জয়েন সফল হয়েছে');
                    if (ok) _reload();
                  },
                  child: const Text('JOIN'),
                ),
            ]);
          },
        ),
      );
}

// ---------------- Me ----------------
class ProfilePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const ProfilePage({super.key, required this.profile, required this.onChanged});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        const SizedBox(height: 8),
        const Center(child: CircleAvatar(radius: 40, child: Icon(Icons.person, size: 44))),
        const SizedBox(height: 16),
        ListTile(title: const Text('নাম'), subtitle: Text('${profile['name']}')),
        ListTile(title: const Text('গেম আইডি'), subtitle: Text('${profile['game_id']}')),
        ListTile(title: const Text('মোবাইল'), subtitle: Text('${profile['phone']}')),
        ListTile(title: const Text('আপনার রেফারাল কোড'), subtitle: Text('${profile['referral_code']}')),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () async {
            final m = await showForm(context, 'প্রোফাইল এডিট', const [F('name', 'নাম'), F('game_id', 'গেম আইডি')],
                init: {'name': '${profile['name']}', 'game_id': '${profile['game_id']}'});
            if (m == null || !context.mounted) return;
            final ok = await run(context, () => sb.from('profiles').update({'name': m['name'], 'game_id': m['game_id']}).eq('id', sb.auth.currentUser!.id),
                ok: 'আপডেট হয়েছে');
            if (ok) onChanged();
          },
          child: const Text('এডিট করুন'),
        ),
        TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
      ]);
}
