import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'theme.dart';
import 'util.dart';
import 'auth_screens.dart';
import 'home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Amar E-sports',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E6BFF), brightness: Brightness.dark),
          scaffoldBackgroundColor: navy,
          appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
          navigationBarTheme: const NavigationBarThemeData(backgroundColor: navy2),
          cardTheme: const CardThemeData(color: navy2),
        ),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  bool _done = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) setState(() => _done = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_done) return const AuthGate();
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(child: Image.asset('assets/images/logo.png', width: 150, height: 150)),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (c, s) {
          final session = sb.auth.currentSession;
          if (session == null) return const LoginScreen();
          return ProfileGate(key: ValueKey(session.user.id));
        },
      );
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});
  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late Future<Map<String, dynamic>?> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>?> _load() =>
      sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: _f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (s.hasError) {
            return Scaffold(
              body: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(errText(s.error!)),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: _reload, child: const Text('আবার চেষ্টা করুন')),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
                ]),
              ),
            );
          }
          final p = s.data;
          if (p == null) return CompleteProfileScreen(onDone: _reload);
          if (p['banned'] == true) return const BannedScreen();
          return HomeShell(profile: p, onProfileChanged: _reload);
        },
      );
}
