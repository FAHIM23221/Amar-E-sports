import 'package:flutter/material.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'home.dart' show ledgerLabel;

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});
  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select().eq('user_id', me).single();
    final l = await sb.from('ledger').select().eq('user_id', me).order('created_at', ascending: false).limit(30);
    final dep = await sb.from('deposits').select().eq('user_id', me).eq('status', 'pending');
    final wd = await sb.from('withdrawals').select().eq('user_id', me).eq('status', 'pending');
    final cfg = await loadConfig();
    return {'w': w, 'l': l, 'dep': dep, 'wd': wd, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _deposit(Map<String, dynamic> cfg, {String method = 'bkash'}) async {
    final nums = cfg['payment_numbers'] is Map ? cfg['payment_numbers'] as Map : {};
    final lines = <String>[];
    for (final k in methods) {
      final n = '${nums[k] ?? ''}'.trim();
      if (n.isNotEmpty) lines.add('$k: $n');
    }
    final note = lines.isEmpty
        ? 'পেমেন্ট নম্বরের জন্য সাপোর্টে যোগাযোগ করুন।'
        : 'প্রথমে নিচের নম্বরে Send Money করুন, তারপর TrxID দিন:\n${lines.join('\n')}';
    final m = await showForm(
      context,
      'টাকা যোগ করুন',
      [
        const F('method', 'মাধ্যম', options: methods),
        const F('amount', 'টাকার পরিমাণ (২০ - ৫০,০০০)', number: true),
        const F('trx', 'TrxID'),
        const F('sender', 'যে নম্বর থেকে পাঠিয়েছেন', number: true),
      ],
      ok: 'জমা দিন',
      init: {'method': method},
      note: note,
    );
    if (m == null || !mounted) return;
    final ok = await run(context, () => sb.rpc('request_deposit', params: {
          'p_method': m['method'],
          'p_trx': m['trx'],
          'p_amount': int.parse(m['amount']!),
          'p_sender': m['sender'],
        }), ok: 'রিকোয়েস্ট জমা হয়েছে, অ্যাডমিন যাচাই করবেন');
    if (ok) _refresh();
  }

  Future<void> _withdraw() async {
    final m = await showForm(
      context,
      'টাকা তুলুন',
      const [
        F('method', 'মাধ্যম', options: methods),
        F('number', 'যে নম্বরে নিতে চান', number: true),
        F('amount', 'টাকার পরিমাণ', number: true),
      ],
      ok: 'রিকোয়েস্ট দিন',
    );
    if (m == null || !mounted) return;
    final ok = await run(context, () => sb.rpc('request_withdraw', params: {
          'p_method': m['method'],
          'p_number': m['number'],
          'p_amount': int.parse(m['amount']!),
        }), ok: 'উইথড্র রিকোয়েস্ট জমা হয়েছে');
    if (ok) _refresh();
  }

  void _howTo(Map<String, dynamic> cfg) {
    final url = linkOf(cfg, 'howto');
    if (url.isNotEmpty) {
      openUrl(context, url);
      return;
    }
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('টাকা যোগ করার নিয়ম'),
        content: const Text('১. bKash / নগদ / রকেটের যেকোনো একটি বেছে নিন।\n'
            '২. দেওয়া নম্বরে Send Money করুন।\n'
            '৩. TrxID ও যে নম্বর থেকে পাঠিয়েছেন তা লিখে জমা দিন।\n'
            '৪. অ্যাডমিন যাচাই করলে ব্যালেন্সে টাকা যোগ হবে।'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
      ),
    );
  }

  Widget _action(IconData icon, String label, VoidCallback onTap) => Expanded(
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(children: [
              Icon(icon, size: 30, color: Colors.black87),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 19, color: Colors.black87)),
            ]),
          ),
        ),
      );

  Widget _blackBtn(String label, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.fromLTRB(46, 0, 46, 8),
        child: Material(
          color: Colors.black,
          elevation: 3,
          borderRadius: BorderRadius.circular(6),
          child: InkWell(
            borderRadius: BorderRadius.circular(6),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18))),
            ),
          ),
        ),
      );

  Widget _provider(String asset, VoidCallback onTap) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: AspectRatio(
            aspectRatio: 0.78,
            child: Material(
              color: Colors.white,
              elevation: 3,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: onTap,
                child: Padding(padding: const EdgeInsets.all(14), child: Image.asset(asset)),
              ),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Theme(
        data: ThemeData(useMaterial3: true, brightness: Brightness.light, colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue)),
        child: Scaffold(
          backgroundColor: const Color(0xFFF7F8FB),
          appBar: AppBar(
            backgroundColor: navy,
            foregroundColor: Colors.white,
            title: const Text('Wallet', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          body: Loader<Map<String, dynamic>>(
            future: _f,
            builder: (d) {
              final w = d['w'] as Map<String, dynamic>;
              final l = d['l'] as List<dynamic>;
              final dep = d['dep'] as List<dynamic>;
              final wd = d['wd'] as List<dynamic>;
              final cfg = d['cfg'] as Map<String, dynamic>;
              return RefreshIndicator(
                onRefresh: _refresh,
                child: ListView(padding: EdgeInsets.zero, children: [
                  Container(
                    width: double.infinity,
                    color: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 46),
                    child: Column(children: [
                      const Text('Available Balance', style: TextStyle(color: Colors.white, fontSize: 22)),
                      const SizedBox(height: 14),
                      Text(money(w['balance']), style: const TextStyle(color: Colors.white, fontSize: 46, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  Material(
                    color: Colors.white,
                    elevation: 4,
                    child: Row(children: [
                      _action(Icons.add, 'Add Money', () => _deposit(cfg)),
                      _action(Icons.payments_outlined, 'Withdraw', _withdraw),
                    ]),
                  ),
                  const SizedBox(height: 28),
                  _blackBtn('SUPPORT', () {
                    final s = linkOf(cfg, 'support');
                    openUrl(context, s.isNotEmpty ? s : linkOf(cfg, 'whatsapp'));
                  }),
                  _blackBtn('HOW TO ADD MONEY?', () => _howTo(cfg)),
                  const SizedBox(height: 22),
                  const Center(child: Text('মোবাইল রিচার্জ প্রোভাইডার সমূহ', style: TextStyle(color: Colors.black54, fontSize: 16))),
                  const SizedBox(height: 18),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(children: [
                      _provider('assets/images/bkash.png', () => _deposit(cfg, method: 'bkash')),
                      _provider('assets/images/nagad.png', () => _deposit(cfg, method: 'nagad')),
                      _provider('assets/images/rocket.png', () => _deposit(cfg, method: 'rocket')),
                    ]),
                  ),
                  const SizedBox(height: 24),
                  if (dep.isNotEmpty || wd.isNotEmpty) ...[
                    const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('অপেক্ষমাণ রিকোয়েস্ট', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                    for (final e in dep)
                      ListTile(dense: true, title: Text('ডিপোজিট ${taka(e['amount'])} (${e['method']})'), subtitle: Text('TrxID ${e['trx_id']}')),
                    for (final e in wd)
                      ListTile(dense: true, title: Text('উইথড্র ${taka(e['amount'])} (${e['method']})'), subtitle: Text('${e['number']}')),
                    const SizedBox(height: 8),
                  ],
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('লেনদেনের ইতিহাস', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                  if (l.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('এখনো কোনো লেনদেন নেই')),
                  for (final e in l)
                    ListTile(
                      dense: true,
                      title: Text(ledgerLabel[e['type']] ?? '${e['type']}'),
                      subtitle: Text(when(e['created_at'])),
                      trailing: Text(
                        '${(e['amount'] as num) >= 0 ? '+' : ''}${e['amount']}',
                        style: TextStyle(color: (e['amount'] as num) >= 0 ? Colors.green.shade700 : Colors.red.shade700, fontWeight: FontWeight.bold),
                      ),
                    ),
                  const SizedBox(height: 30),
                ]),
              );
            },
          ),
        ),
      );
}
