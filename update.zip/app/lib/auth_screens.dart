import 'dart:math';
import 'package:android_id/android_id.dart';
import 'package:flutter/material.dart';
import 'util.dart';
import 'links.dart';

const _bg = Color(0xFF020618);
const _cyan = Color(0xFF00BCD4);
const _cyanText = Color(0xFF29D3F0);
const _fieldBorder = Color(0xFF7FE9F5);

/// Data typed on the register form; picked up by the profile step right after sign-up.
class Pending {
  static Map<String, String>? data;
}

Future<String> deviceId() async {
  try {
    final id = await AndroidId().getId();
    if (id != null && id.isNotEmpty) return id;
  } catch (_) {}
  return 'rnd-${Random.secure().nextInt(1 << 31)}-${DateTime.now().microsecondsSinceEpoch}';
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _entryController;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(vsync: this, duration: const Duration(milliseconds: 850));
    _fade = CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(begin: const Offset(0, 0.075), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic));
    _entryController.forward();
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  Future<void> _switchMode() async {
    await _entryController.reverse();
    if (!mounted) return;
    setState(() => _register = !_register);
    _entryController.forward();
  }
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _game = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  final _ref = TextEditingController();
  bool _register = false;
  bool _busy = false;
  bool _hide = true;

  Widget _field(IconData icon, TextEditingController c, String hint,
      {bool obscure = false, TextInputType? kb, Widget? suffix, int? maxLen}) {
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: _fieldBorder, width: 1.5));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Icon(icon, color: Colors.black87, size: 22),
        const SizedBox(width: 12),
        Expanded(
          child: TextField(
            controller: c,
            obscureText: obscure,
            keyboardType: kb,
            maxLength: maxLen,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.black, fontSize: 16),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.black87),
              counterText: '',
              contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
              enabledBorder: border,
              focusedBorder: border.copyWith(borderSide: const BorderSide(color: _cyan, width: 2)),
              border: border,
            ),
          ),
        ),
        suffix ?? const SizedBox(width: 24),
      ]),
    );
  }

  Widget _eye() => GestureDetector(
        onTap: () => setState(() => _hide = !_hide),
        child: Padding(
          padding: const EdgeInsets.only(left: 4),
          child: Icon(_hide ? Icons.visibility_off : Icons.visibility, color: Colors.black87, size: 20),
        ),
      );

  Widget _btn(String label, VoidCallback? onTap, {double v = 16}) => SizedBox(
        width: double.infinity,
        child: Material(
          color: _cyan,
          borderRadius: BorderRadius.circular(3),
          child: InkWell(
            borderRadius: BorderRadius.circular(3),
            onTap: onTap,
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: v),
              child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
            ),
          ),
        ),
      );

  Future<void> _login() async {
    final phone = _phone.text.trim();
    if (!phoneRe.hasMatch(phone)) {
      toast(context, 'সঠিক মোবাইল নম্বর দিন (যেমন 01XXXXXXXXX)', err: true);
      return;
    }
    if (_pass.text.isEmpty) {
      toast(context, 'পাসওয়ার্ড দিন', err: true);
      return;
    }
    setState(() => _busy = true);
    await run(context, () => sb.auth.signInWithPassword(email: emailOf(phone), password: _pass.text));
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _signUp() async {
    final phone = _phone.text.trim();
    if (_name.text.trim().isEmpty || _game.text.trim().isEmpty) {
      toast(context, 'নাম ও গেম আইডি দিন', err: true);
      return;
    }
    if (!phoneRe.hasMatch(phone)) {
      toast(context, 'সঠিক মোবাইল নম্বর দিন (যেমন 01XXXXXXXXX)', err: true);
      return;
    }
    if (_pass.text.length < 6) {
      toast(context, 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে', err: true);
      return;
    }
    if (_pass.text != _pass2.text) {
      toast(context, 'দুটো পাসওয়ার্ড মিলছে না', err: true);
      return;
    }
    setState(() => _busy = true);
    Pending.data = {'name': _name.text.trim(), 'game': _game.text.trim(), 'ref': _ref.text.trim()};
    final ok = await run(context, () async {
      final r = await sb.auth.signUp(email: emailOf(phone), password: _pass.text);
      if (r.session == null) throw 'অ্যাকাউন্ট খোলা যায়নি, অ্যাডমিনের সঙ্গে যোগাযোগ করুন';
    });
    if (!ok) Pending.data = null;
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _forgot() async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: const Center(child: Text('Forgot Password?', style: TextStyle(color: _cyan, fontWeight: FontWeight.bold, fontSize: 20))),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('পাসওয়ার্ড ভুলে গেলে অ্যাডমিনের সঙ্গে যোগাযোগ করুন। যাচাই করে অ্যাডমিন নতুন পাসওয়ার্ড দিয়ে দেবেন।',
              style: TextStyle(color: Colors.black87), textAlign: TextAlign.center),
          const SizedBox(height: 14),
          _btn('CONTACT', () async {
            Navigator.pop(ctx);
            String url = '';
            try {
              final r = await sb.rpc('get_public_links');
              if (r is Map) {
                final s = '${r['support'] ?? ''}'.trim();
                url = s.isNotEmpty ? s : '${r['whatsapp'] ?? ''}';
              }
            } catch (_) {}
            if (mounted) openUrl(context, url);
          }, v: 14),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL', style: TextStyle(color: Color(0xFF00897B))))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: _bg,
        body: SafeArea(
          child: Stack(children: [
            Positioned(top: -95, right: -75, child: Container(width: 230, height: 230, decoration: BoxDecoration(shape: BoxShape.circle, color: _cyan.withOpacity(.10)))),
            Positioned(bottom: -110, left: -85, child: Container(width: 260, height: 260, decoration: BoxDecoration(shape: BoxShape.circle, color: _cyanText.withOpacity(.07)))),
            Center(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (!_register) ...[
                  const Text('WELCOME TO', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600, letterSpacing: 1)),
                  const Text('AMAR E-SPORTS', style: TextStyle(color: _cyanText, fontSize: 38, fontWeight: FontWeight.bold)),
                  const Text('গেইম খেলে টাকা কামাও', style: TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 40),
                  const Text('LOG IN', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                ] else
                  const Text('CREATE NEW ACCOUNT', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)),
                  child: Column(children: [
                    if (_register) _field(Icons.person, _name, 'Your Name'),
                    _field(Icons.phone, _phone, 'Phone Number', kb: TextInputType.phone, maxLen: 11),
                    if (_register) _field(Icons.sports_esports, _game, 'Game ID (Free Fire UID)'),
                    _field(Icons.lock, _pass, _register ? 'Enter Password' : 'Password', obscure: _hide, suffix: _eye()),
                    if (_register) _field(Icons.lock, _pass2, 'Confirm Password', obscure: _hide),
                    if (_register) _field(Icons.card_giftcard, _ref, 'Referral Code (optional)'),
                    if (!_register)
                      TextButton(
                        onPressed: _forgot,
                        child: const Text('Forgot Password?', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                      ),
                    const SizedBox(height: 8),
                    _btn(_register ? 'Register' : 'LOG IN', _busy ? null : (_register ? _signUp : _login)),
                  ]),
                ),
                const SizedBox(height: 22),
                _btn(_register ? 'Already have an account?' : 'CREATE NEW ACCOUNT', _busy ? null : _switchMode, v: 15),
              ]),
                ),
              ),
            ),
          ),
          ]),
        ),
      );
}

class CompleteProfileScreen extends StatefulWidget {
  final VoidCallback onDone;
  const CompleteProfileScreen({super.key, required this.onDone});
  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final _name = TextEditingController();
  final _game = TextEditingController();
  final _ref = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final p = Pending.data;
    if (p != null) {
      _name.text = p['name'] ?? '';
      _game.text = p['game'] ?? '';
      _ref.text = p['ref'] ?? '';
      Pending.data = null;
      WidgetsBinding.instance.addPostFrameCallback((_) => _save());
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _game.text.trim().isEmpty) {
      toast(context, 'নাম ও গেম আইডি দিন', err: true);
      return;
    }
    setState(() => _busy = true);
    final dev = await deviceId();
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('create_profile', params: {
          'p_name': _name.text.trim(),
          'p_game_id': _game.text.trim(),
          'p_device': dev,
          'p_referral': _ref.text.trim(),
        }));
    if (ok) widget.onDone();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('প্রোফাইল সম্পূর্ণ করুন'), actions: [
          TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
        ]),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'আপনার নাম', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _game, decoration: const InputDecoration(labelText: 'Free Fire / গেম আইডি', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _ref, decoration: const InputDecoration(labelText: 'রেফারাল কোড (ঐচ্ছিক)', border: OutlineInputBorder())),
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('সংরক্ষণ করুন')),
        ]),
      );
}

class BannedScreen extends StatelessWidget {
  const BannedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.block, size: 64, color: Colors.red),
              const SizedBox(height: 12),
              const Text('আপনার অ্যাকাউন্ট ব্যান করা হয়েছে। অ্যাডমিনের সঙ্গে যোগাযোগ করুন।', textAlign: TextAlign.center),
              TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
            ]),
          ),
        ),
      );
}
