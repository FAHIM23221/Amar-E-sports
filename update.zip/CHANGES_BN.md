# Update 16 — পরিবর্তন (সংক্ষেপে)

## নতুন: Developer অ্যাপ (`developer_app/`)
- পাসকোড লগইন (ডিফল্ট 1234 — প্রথমেই বদলাতে হবে), অ্যাকাউন্ট `dev@amaresports.app`
- ১১ সেকশন: Banners & Links, Contacts, Maintenance Mode, Force Update, Admins, Feature Control (৮ টগল), Admin Activity, Users, Money Dashboard, Notices & Push, Settings
- আইকনে DEV ব্যান্ড (অ্যাডমিন অ্যাপ থেকে আলাদা চেনা যায়)

## ইউজার অ্যাপ (`app/`)
- মেইনটেন্যান্স স্ক্রিন, ফোর্স/সফট আপডেট (প্রতিবার অ্যাপ খুললে চেক)
- Wallet-এ ফিচার টগল (user_withdraw / user_topup)
- ব্যানার এখন ডেভেলপার প্যানেল থেকে আসে (visible/order/link)
- স্পেসিং: কার্ডের ফাঁক ১৮ dp, ব্যানারের পাশের ফাঁক ৭ dp (আপডেট-১৫-এর -৬ নেগেটিভ margin বাদ — Flutter Container নেগেটিভ margin নেয় না)

## অ্যাডমিন অ্যাপ (`admin_app/`)
- মেইনটেন্যান্স ও ফোর্স/সফট আপডেট গেট (লগইনের পর)
- অ্যাডমিন ব্যান চেক (ব্যান থাকলে প্যানেলে ঢোকা যায় না)
- "অন্য অ্যাকাউন্ট দিয়ে লগইন" (আলাদা অ্যাডমিনদের জন্য)
- ফিচার টগলে কার্ড/পেজ লুকানো + "এই ফিচারটি বন্ধ করা হয়েছে"
- অ্যাক্টিভিটি লগ (`admin_activity_log`)

## ব্যাকএন্ড (`supabase/update16.sql`)
- `verify_developer_passcode` / `admin_set_developer_passcode` (ডিফল্ট 1234)
- `is_developer()` হেল্পার, `admin_activity_log` টেবিল + RLS
- `dev_save_*` (banners/contacts/maintenance/force_update/toggles/settings)
- `dev_add_admin` / `dev_reset_admin_passcode` / `dev_set_admin_banned` / `dev_remove_admin`
- `dev_set_user_banned` / `dev_reset_user_password`
- `verify_admin_passcode` নতুন সংস্করণ: শেয়ার্ড অ্যাডমিন অ্যাকাউন্ট ব্যান থাকলে false

## সেটআপ
- ক্রম: update9.sql → update10.sql → update16.sql (Supabase SQL Editor)
- Dashboard-এ `dev@amaresports.app` বানিয়ে প্রোফাইলে `is_developer=true` করুন
- প্রথম লগইনে ডেভেলপার পাসকোড বদলে নিন
- GitHub workflow-এ developer_app-এর জন্য তৃতীয় build job যোগ করতে হবে

## যাচাই (Flutter 3.50.1)
- analyze: তিন অ্যাপেই ০ error
- kernel_snapshot_program: তিন অ্যাপেই exit 0 (app.dill ৩৬–৩৮ MB)
- APK বানানো হয়নি — GitHub workflow-কে বিল্ড করতে হবে
