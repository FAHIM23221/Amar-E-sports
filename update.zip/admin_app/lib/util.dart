import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final sb = Supabase.instance.client;
final phoneRe = RegExp(r'^01\d{9}$');
final passcodeRe = RegExp(r'^\d{4}$');
// পুরনো অ্যাডমিন প্যানেলের রং: গাঢ় নেভি হেডার, কালো ব্যাকগ্রাউন্ড, টিল বোতাম।
const adminNavy = Color(0xFF030B2B);
const adminTeal = Color(0xFF1FB6C9);
const methods = ['bkash', 'nagad', 'rocket'];

const statusLabel = {
  'draft': 'ড্রাফট',
  'open': 'জয়েন চলছে',
  'live': 'লাইভ',
  'finished': 'শেষ',
  'cancelled': 'বাতিল',
};

/// লেজার এন্ট্রির ধরনের বাংলা লেবেল (ইউজার অ্যাপের home.dart-এর ম্যাপের মতোই)।
const ledgerLabel = {
  'deposit': 'ডিপোজিট',
  'join_fee': 'জয়েন ফি',
  'prize': 'প্রাইজ',
  'withdraw_hold': 'উইথড্র (আটকানো)',
  'withdraw_refund': 'উইথড্র ফেরত',
  'refund': 'ফি ফেরত',
  'admin_send': 'অ্যাডমিন পাঠিয়েছে',
};

String emailOf(String phone) => '$phone@amaresports.app';

/// ভার্সন তুলনা, অংশ ধরে ধরে: '1.0.0' < '1.0.1', '1.9.0' < '1.10.0'।
int compareVersions(String a, String b) {
  final pa = a.split('.').map((s) => int.tryParse(s.trim()) ?? 0).toList();
  final pb = b.split('.').map((s) => int.tryParse(s.trim()) ?? 0).toList();
  final n = pa.length > pb.length ? pa.length : pb.length;
  for (var i = 0; i < n; i++) {
    final x = i < pa.length ? pa[i] : 0;
    final y = i < pb.length ? pb[i] : 0;
    if (x != y) return x < y ? -1 : 1;
  }
  return 0;
}

/// ফিচার টগল — AdminCheck লোড করে; key না থাকলে ডিফল্ট চালু।
Map<String, dynamic> featureToggles = {};
bool featureOn(String key) => featureToggles[key] != false;

/// সফট আপডেট নোটিশ — AdminCheck সেট করে, AdminHome ব্যানার দেখায়।
class SoftUpdate {
  final String minVersion;
  final String url;
  const SoftUpdate(this.minVersion, this.url);
}

SoftUpdate? adminSoftUpdate;

/// বন্ধ ফিচারের পেজ — রুট সরাসরি খোলা হলেও এটাই দেখাবে।
Widget featureOffPage(String title) => Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text(title)),
      body: const Center(
        child: Text('এই ফিচারটি বন্ধ করা হয়েছে',
            style: TextStyle(color: Colors.white, fontSize: 18)),
      ),
    );

/// অ্যাডমিন অ্যাক্টিভিটি লগ — admin_activity_log-এ রো লেখে।
/// ভেতরে try/catch আছে, তাই লগ লিখতে না পারলেও মূল কাজ ভাঙবে না।
Future<void> logAdmin(String action, String detail) async {
  try {
    final email = sb.auth.currentUser?.email ?? '';
    final phone = email.endsWith('@amaresports.app')
        ? email.replaceAll('@amaresports.app', '')
        : email;
    await sb.from('admin_activity_log').insert({
      'admin_phone': phone,
      'action': action,
      'detail': detail,
    });
  } catch (_) {
    // লগ ব্যর্থ হলে কিছুই করার নেই — মূল অ্যাকশন ঠিকই হয়েছে।
  }
}

String errText(Object e) {
  String m;
  if (e is PostgrestException) {
    m = e.message;
  } else if (e is AuthException) {
    m = e.message;
  } else if (e is FormatException) {
    return 'সংখ্যা ঠিকভাবে লিখুন';
  } else {
    m = e.toString();
  }
  const map = {
    'Invalid login credentials': 'নম্বর বা পাসওয়ার্ড ভুল',
    'User already registered': 'এই নম্বর দিয়ে আগেই অ্যাকাউন্ট খোলা আছে',
    'Insufficient balance': 'ব্যালেন্স যথেষ্ট নয়',
    'Tournament is full': 'সব স্লট পূর্ণ হয়ে গেছে',
    'Tournament not open': 'এই ম্যাচে এখন জয়েন করা যাবে না',
    'Already joined': 'আপনি আগেই জয়েন করেছেন',
    'Too many accounts on this device': 'এই ডিভাইসে আর নতুন অ্যাকাউন্ট খোলা যাবে না',
    'This transaction ID was already submitted': 'এই TrxID আগেই জমা দেওয়া হয়েছে',
    'Too many pending deposits': 'আগের ডিপোজিট রিকোয়েস্ট শেষ হওয়ার অপেক্ষা করুন',
    'Too many pending withdrawals': 'আগের উইথড্র রিকোয়েস্ট শেষ হওয়ার অপেক্ষা করুন',
    'Account banned': 'আপনার অ্যাকাউন্ট ব্যান করা হয়েছে',
    'Invalid deposit details': 'ডিপোজিটের তথ্য ঠিক নয়',
    'Admin only': 'শুধু অ্যাডমিন এটা করতে পারেন',
  };
  for (final e in map.entries) {
    if (m.contains(e.key)) return e.value;
  }
  if (m.startsWith('Amount must be between')) return 'অঙ্ক সীমার বাইরে: $m';
  return m;
}

void toast(BuildContext c, String m, {bool err = false}) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    content: Text(m),
    backgroundColor: err ? Colors.red.shade700 : null,
  ));
}

Future<bool> run(BuildContext c, Future<dynamic> Function() f, {String? ok}) async {
  try {
    await f();
    if (ok != null && c.mounted) toast(c, ok);
    return true;
  } catch (e) {
    if (c.mounted) toast(c, errText(e), err: true);
    return false;
  }
}

String taka(dynamic v) => '৳${v ?? 0}';

String when(dynamic iso) {
  if (iso == null) return '';
  final d = DateTime.tryParse(iso.toString())?.toLocal();
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
}

class F {
  final String key, label;
  final List<String>? options;
  final bool number, obscure;
  const F(this.key, this.label, {this.options, this.number = false, this.obscure = false});
}

Future<Map<String, String>?> showForm(BuildContext c, String title, List<F> fs,
    {String ok = 'ঠিক আছে', Map<String, String>? init}) {
  final ctrls = {
    for (final f in fs)
      f.key: TextEditingController(text: init?[f.key] ?? (f.options?.first ?? ''))
  };
  return showDialog<Map<String, String>>(
    context: c,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final f in fs)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: f.options != null
                    ? DropdownButtonFormField<String>(
                        value: ctrls[f.key]!.text,
                        decoration: InputDecoration(labelText: f.label),
                        items: [for (final o in f.options!) DropdownMenuItem(value: o, child: Text(o))],
                        onChanged: (v) => set(() => ctrls[f.key]!.text = v!),
                      )
                    : TextField(
                        controller: ctrls[f.key],
                        obscureText: f.obscure,
                        keyboardType: f.number ? TextInputType.number : TextInputType.text,
                        decoration: InputDecoration(labelText: f.label),
                      ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, {for (final e in ctrls.entries) e.key: e.value.text.trim()}),
            child: Text(ok),
          ),
        ],
      ),
    ),
  );
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ')),
      ],
    ),
  );
  return r == true;
}

class Loader<T> extends StatelessWidget {
  final Future<T> future;
  final Widget Function(T data) builder;
  const Loader({super.key, required this.future, required this.builder});
  @override
  Widget build(BuildContext context) => FutureBuilder<T>(
        future: future,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.hasError) {
            return Center(
                child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(errText(s.error!), textAlign: TextAlign.center),
            ));
          }
          return builder(s.data as T);
        },
      );
}
