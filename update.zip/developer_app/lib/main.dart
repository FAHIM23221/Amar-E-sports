import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'developer.dart';
import 'config.dart';
import 'util.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  // অ্যাপ চালু হলেই পুরনো সেশন সাফ: পাসকোড স্ক্রিন এড়িয়ে যাওয়া যাবে না।
  try {
    await sb.auth.signOut();
  } catch (_) {}
  runApp(const DeveloperApp());
}

class DeveloperApp extends StatelessWidget {
  const DeveloperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Amar E-sports Developer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: devTeal, brightness: Brightness.dark),
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: devNavy,
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      home: const DeveloperGate(),
    );
  }
}

class DeveloperGate extends StatelessWidget {
  const DeveloperGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, snap) {
        final session = snap.data?.session ?? sb.auth.currentSession;
        if (session == null) return const PasscodeLogin();
        return const DeveloperCheck();
      },
    );
  }
}

/// পাসকোড দিয়ে লগইন — অ্যাডমিন অ্যাপের মতো: কালো ব্যাকগ্রাউন্ড,
/// সাদা তালার আইকন, একটাই "Passcode" ফিল্ড, টিল "Continue" বোতাম।
class PasscodeLogin extends StatefulWidget {
  const PasscodeLogin({super.key});

  @override
  State<PasscodeLogin> createState() => _PasscodeLoginState();
}

class _PasscodeLoginState extends State<PasscodeLogin> {
  final _code = TextEditingController();
  var _busy = false;

  Future<void> _continue() async {
    final code = _code.text.trim();
    if (!passcodeRe.hasMatch(code)) {
      toast(context, '৪ সংখ্যার পাসকোড দিন');
      return;
    }
    setState(() => _busy = true);
    try {
      // প্রথমে পাসকোড যাচাই (সার্ভার-সাইড RPC)।
      final ok = await sb.rpc('verify_developer_passcode', params: {'p_code': code});
      if (ok != true) {
        toast(context, 'ভুল পাসকোড');
        _code.clear();
        return;
      }
      // পাসকোড ঠিক হলে ডেডিকেটেড ডেভেলপার অ্যাকাউন্টে সাইন ইন
      // (পাসওয়ার্ড = পাসকোড)।
      await sb.auth.signInWithPassword(
        email: developerEmail,
        password: developerAuthPassword(code),
      );
    } catch (e) {
      toast(context, errText(e));
      _code.clear();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, color: Colors.white, size: 56),
              const SizedBox(height: 16),
              const Text('DEVELOPER',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 4)),
              const SizedBox(height: 32),
              TextField(
                controller: _code,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 8),
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  hintText: 'Passcode',
                  hintStyle: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 0),
                  counterText: '',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: devTeal, width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: devTeal, width: 2),
                  ),
                ),
                onSubmitted: (_) => _continue(),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: _busy ? null : _continue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: devTeal,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: _busy
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : const Text('Continue', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// সাইন ইন করা অ্যাকাউন্টটি সত্যিই ডেভেলপার কি না যাচাই করে।
class DeveloperCheck extends StatelessWidget {
  const DeveloperCheck({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: sb.rpc('is_developer').then((v) => v == true).catchError((_) => false),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator(color: devTeal)),
          );
        }
        if (snap.data == true) return const DeveloperHome();
        return Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('এই অ্যাকাউন্ট ডেভেলপার নয়', style: TextStyle(color: Colors.white, fontSize: 18)),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: devTeal, foregroundColor: Colors.white),
                  onPressed: () async {
                    await sb.auth.signOut();
                  },
                  child: const Text('লগআউট'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
