import 'package:flutter/material.dart';
import 'util.dart';

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 6,
        child: Column(children: const [
          TabBar(isScrollable: true, tabs: [
            Tab(text: 'ড্যাশবোর্ড'),
            Tab(text: 'ডিপোজিট'),
            Tab(text: 'উইথড্র'),
            Tab(text: 'ম্যাচ'),
            Tab(text: 'ইউজার'),
            Tab(text: 'আরও'),
          ]),
          Expanded(
            child: TabBarView(children: [
              AdminStats(),
              AdminDeposits(),
              AdminWithdrawals(),
              AdminTournaments(),
              AdminUsers(),
              AdminMore(),
            ]),
          ),
        ]),
      );
}


// ---------- ড্যাশবোর্ড / পরিসংখ্যান ----------
class AdminStats extends StatefulWidget {
  const AdminStats({super.key});
  @override
  State<AdminStats> createState() => _AdminStatsState();
}

class _AdminStatsState extends State<AdminStats> {
  late Future<Map<String, int>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, int>> _load() async {
    final users = await sb.from('profiles').select('id');
    final dep = await sb.from('deposits').select('id').eq('status', 'pending');
    final wd = await sb.from('withdrawals').select('id').eq('status', 'pending');
    final open = await sb.from('tournaments').select('id').eq('status', 'open');
    return {
      'users': (users as List).length,
      'dep': (dep as List).length,
      'wd': (wd as List).length,
      'open': (open as List).length,
    };
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Widget _card(String label, int value, IconData icon) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 30),
            const SizedBox(height: 8),
            Text('$value', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Loader<Map<String, int>>(
        future: _f,
        builder: (d) => RefreshIndicator(
          onRefresh: _refresh,
          child: GridView.count(
            crossAxisCount: 2,
            padding: const EdgeInsets.all(16),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              _card('মোট ইউজার', d['users'] ?? 0, Icons.people),
              _card('অপেক্ষমাণ ডিপোজিট', d['dep'] ?? 0, Icons.add_circle_outline),
              _card('অপেক্ষমাণ উইথড্র', d['wd'] ?? 0, Icons.payments_outlined),
              _card('খোলা ম্যাচ', d['open'] ?? 0, Icons.sports_esports),
            ],
          ),
        ),
      );
}


// ---------- Deposits ----------
class AdminDeposits extends StatefulWidget {
  const AdminDeposits({super.key});
  @override
  State<AdminDeposits> createState() => _AdminDepositsState();
}

class _AdminDepositsState extends State<AdminDeposits> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb
      .from('deposits')
      .select('*, profiles(name, phone)')
      .eq('status', 'pending')
      .order('created_at');

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _review(String id, bool approve) async {
    if (!await confirm(context, approve ? 'এই ডিপোজিট অ্যাপ্রুভ করবেন? ব্যালেন্সে টাকা যোগ হবে।' : 'রিজেক্ট করবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('review_deposit', params: {'p_id': id, 'p_approve': approve}),
        ok: approve ? 'অ্যাপ্রুভ হয়েছে' : 'রিজেক্ট হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Loader<List<dynamic>>(
        future: _f,
        builder: (list) => RefreshIndicator(
          onRefresh: _refresh,
          child: list.isEmpty
              ? ListView(children: const [SizedBox(height: 160), Center(child: Text('কোনো অপেক্ষমাণ ডিপোজিট নেই'))])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final d = list[i] as Map<String, dynamic>;
                    final p = d['profiles'] as Map<String, dynamic>?;
                    return Card(
                      child: ListTile(
                        title: Text('${taka(d['amount'])} • ${d['method']} • ${d['trx_id']}'),
                        subtitle: Text('${p?['name'] ?? ''} • ${p?['phone'] ?? ''}\nপাঠিয়েছে: ${d['sender_number']}\n${when(d['created_at'])}'),
                        isThreeLine: true,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.check_circle, color: Colors.green), onPressed: () => _review('${d['id']}', true)),
                          IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => _review('${d['id']}', false)),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ---------- Withdrawals ----------
class AdminWithdrawals extends StatefulWidget {
  const AdminWithdrawals({super.key});
  @override
  State<AdminWithdrawals> createState() => _AdminWithdrawalsState();
}

class _AdminWithdrawalsState extends State<AdminWithdrawals> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb
      .from('withdrawals')
      .select('*, profiles(name, phone)')
      .eq('status', 'pending')
      .order('created_at');

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _review(String id, bool paid) async {
    if (!await confirm(context, paid ? 'আপনি কি টাকা পাঠিয়ে দিয়েছেন? "পাঠানো হয়েছে" চিহ্নিত হবে।' : 'রিজেক্ট করলে টাকা ইউজারের ব্যালেন্সে ফেরত যাবে।')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('review_withdraw', params: {'p_id': id, 'p_approve': paid}),
        ok: paid ? 'পাঠানো হয়েছে চিহ্নিত' : 'রিজেক্ট ও টাকা ফেরত');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Loader<List<dynamic>>(
        future: _f,
        builder: (list) => RefreshIndicator(
          onRefresh: _refresh,
          child: list.isEmpty
              ? ListView(children: const [SizedBox(height: 160), Center(child: Text('কোনো অপেক্ষমাণ উইথড্র নেই'))])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final d = list[i] as Map<String, dynamic>;
                    final p = d['profiles'] as Map<String, dynamic>?;
                    return Card(
                      child: ListTile(
                        title: Text('${taka(d['amount'])} • ${d['method']} • ${d['number']}'),
                        subtitle: Text('${p?['name'] ?? ''} • ${p?['phone'] ?? ''}\n${when(d['created_at'])}'),
                        isThreeLine: true,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.send, color: Colors.green), onPressed: () => _review('${d['id']}', true)),
                          IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => _review('${d['id']}', false)),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ---------- Tournaments ----------
class AdminTournaments extends StatefulWidget {
  const AdminTournaments({super.key});
  @override
  State<AdminTournaments> createState() => _AdminTournamentsState();
}

class _AdminTournamentsState extends State<AdminTournaments> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() => sb.from('tournaments').select().order('created_at', ascending: false).limit(60);

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _create() async {
    final m = await showForm(
      context,
      'নতুন ম্যাচ',
      const [
        F('title', 'ম্যাচের নাম'),
        F('game', 'গেম', options: ['Free Fire', 'Ludo King']),
        F('mode', 'টাইপ', options: ['Solo', 'Duo', 'Squad']),
        F('board', 'বোর্ড / ম্যাপ (যেমন LUDO KING, Bermuda, Dust 2)'),
        F('fee', 'এন্ট্রি ফি (টাকা)', number: true),
        F('prize', 'মোট প্রাইজ (টাকা)', number: true),
        F('slots', 'মোট স্লট', number: true),
        F('start', 'শুরুর সময় (যেমন 2026-12-01 20:00)'),
        F('status', 'অবস্থা', options: ['draft', 'open']),
      ],
      ok: 'তৈরি করুন',
    );
    if (m == null || !mounted) return;
    final ok = await run(context, () async {
      final start = DateTime.tryParse(m['start']!.replaceFirst(' ', 'T'));
      if (m['title']!.isEmpty) throw 'ম্যাচের নাম দিন';
      await sb.from('tournaments').insert({
        'title': m['title'],
        'game': m['game'],
        'mode': m['mode'],
        'board': m['board'],
        'fee': int.parse(m['fee']!),
        'prize_pool': int.parse(m['prize']!),
        'slots': int.parse(m['slots']!),
        'starts_at': start?.toUtc().toIso8601String(),
        'status': m['status'],
      });
    }, ok: 'ম্যাচ তৈরি হয়েছে');
    if (ok) _refresh();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: _create, child: const Icon(Icons.add)),
        body: Loader<List<dynamic>>(
          future: _f,
          builder: (list) => RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (c, i) {
                final t = list[i] as Map<String, dynamic>;
                return Card(
                  child: ListTile(
                    title: Text('${t['title']}'),
                    subtitle: Text('${statusLabel[t['status']] ?? t['status']} • ${t['joined']}/${t['slots']} • ফি ${taka(t['fee'])}\n${when(t['starts_at'])}'),
                    isThreeLine: true,
                    onTap: () async {
                      await Navigator.push(c, MaterialPageRoute(builder: (_) => AdminTournamentPage(id: '${t['id']}')));
                      _refresh();
                    },
                  ),
                );
              },
            ),
          ),
        ),
      );
}

class AdminTournamentPage extends StatefulWidget {
  final String id;
  const AdminTournamentPage({super.key, required this.id});
  @override
  State<AdminTournamentPage> createState() => _AdminTournamentPageState();
}

class _AdminTournamentPageState extends State<AdminTournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final ps = await sb.from('participants').select().eq('tournament_id', widget.id).order('joined_at');
    final room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    return {'t': t, 'ps': ps, 'room': room};
  }

  void _reload() => setState(() => _f = _load());

  Future<void> _setStatus(String s) async {
    final ok = await run(context, () => sb.from('tournaments').update({'status': s}).eq('id', widget.id), ok: 'আপডেট হয়েছে');
    if (ok) _reload();
  }

  Future<void> _room(Map<String, dynamic>? room) async {
    final m = await showForm(context, 'রুমের তথ্য', const [F('rid', 'রুম আইডি'), F('rpw', 'রুম পাসওয়ার্ড')],
        init: {'rid': '${room?['room_id'] ?? ''}', 'rpw': '${room?['room_password'] ?? ''}'});
    if (m == null || !mounted) return;
    final ok = await run(context, () => sb.from('tournament_rooms').upsert({
          'tournament_id': widget.id,
          'room_id': m['rid'],
          'room_password': m['rpw'],
        }), ok: 'রুমের তথ্য সংরক্ষিত');
    if (ok) _reload();
  }

  Future<void> _cancel() async {
    if (!await confirm(context, 'ম্যাচ বাতিল করলে সবার এন্ট্রি ফি ফেরত যাবে। নিশ্চিত?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('cancel_tournament', params: {'p_tournament': widget.id}), ok: 'বাতিল ও ফি ফেরত হয়েছে');
    if (ok) _reload();
  }

  Future<void> _publish(List<dynamic> ps) async {
    final ctrls = {for (final p in ps) '${p['user_id']}': TextEditingController()};
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('বিজয়ীদের প্রাইজ'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: [
            for (final p in ps)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(
                  controller: ctrls['${p['user_id']}'],
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: '${p['name']} (${p['game_id']}) — প্রাইজ ৳'),
                ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('পাবলিশ করুন')),
        ],
      ),
    );
    if (go != true || !mounted) return;
    final winners = <Map<String, dynamic>>[];
    for (final e in ctrls.entries) {
      final v = int.tryParse(e.value.text.trim()) ?? 0;
      if (v > 0) winners.add({'user_id': e.key, 'prize': v});
    }
    if (winners.isEmpty) {
      toast(context, 'কমপক্ষে একজনের প্রাইজ দিন', err: true);
      return;
    }
    if (!await confirm(context, '${winners.length} জনকে প্রাইজ দিয়ে ম্যাচ শেষ করবেন? এটা ফেরানো যাবে না।')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('publish_result', params: {'p_tournament': widget.id, 'p_winners': winners}),
        ok: 'রেজাল্ট পাবলিশ হয়েছে');
    if (ok) _reload();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ম্যাচ ম্যানেজ')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final ps = d['ps'] as List<dynamic>;
            final room = d['room'] as Map<String, dynamic>?;
            final closed = t['status'] == 'finished' || t['status'] == 'cancelled';
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('${t['title']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Text('${statusLabel[t['status']] ?? t['status']} • ${t['joined']}/${t['slots']} • ফি ${taka(t['fee'])} • প্রাইজ ${taka(t['prize_pool'])}'),
              const SizedBox(height: 12),
              if (!closed)
                Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton(onPressed: () => _setStatus('open'), child: const Text('ওপেন')),
                  OutlinedButton(onPressed: () => _setStatus('live'), child: const Text('লাইভ')),
                  OutlinedButton(onPressed: () => _room(room), child: const Text('রুমের তথ্য')),
                  FilledButton(onPressed: ps.isEmpty ? null : () => _publish(ps), child: const Text('রেজাল্ট দিন')),
                  TextButton(onPressed: _cancel, child: const Text('বাতিল ও ফেরত', style: TextStyle(color: Colors.redAccent))),
                ]),
              if (room != null) ListTile(title: Text('রুম: ${room['room_id']}'), subtitle: Text('পাসওয়ার্ড: ${room['room_password']}')),
              const Divider(),
              Text('জয়েন করেছে (${ps.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
              for (final p in ps) ListTile(dense: true, title: Text('${p['name']}'), subtitle: Text('${p['game_id']}')),
            ]);
          },
        ),
      );
}

// ---------- Users ----------
class AdminUsers extends StatefulWidget {
  const AdminUsers({super.key});
  @override
  State<AdminUsers> createState() => _AdminUsersState();
}

class _AdminUsersState extends State<AdminUsers> {
  final _q = TextEditingController();
  Future<List<dynamic>>? _f;

  void _search() {
    final q = _q.text.trim();
    if (q.isEmpty) return;
    setState(() => _f = sb.from('profiles').select('*, wallets(balance)').ilike('phone', '%$q%').limit(20));
  }

  dynamic _bal(Map<String, dynamic> p) {
    final w = p['wallets'];
    if (w is List) return w.isEmpty ? 0 : w.first['balance'];
    if (w is Map) return w['balance'];
    return 0;
  }

  Future<void> _reset(Map<String, dynamic> p) async {
    final m = await showForm(context, 'নতুন পাসওয়ার্ড (${p['phone']})', const [F('pw', 'নতুন পাসওয়ার্ড (কমপক্ষে ৬)')]);
    if (m == null || !mounted) return;
    await run(context, () => sb.rpc('admin_reset_password', params: {'p_user': p['id'], 'p_new_password': m['pw']}),
        ok: 'পাসওয়ার্ড বদলানো হয়েছে, ইউজারকে জানিয়ে দিন');
  }

  Future<void> _ban(Map<String, dynamic> p) async {
    final ban = p['banned'] != true;
    if (!await confirm(context, ban ? '${p['name']}-কে ব্যান করবেন?' : 'ব্যান তুলে নেবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('admin_set_banned', params: {'p_user': p['id'], 'p_banned': ban}), ok: 'সম্পন্ন');
    if (ok) _search();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _q,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'মোবাইল নম্বর দিয়ে খুঁজুন', border: OutlineInputBorder()),
                onSubmitted: (_) => _search(),
              ),
            ),
            IconButton(onPressed: _search, icon: const Icon(Icons.search)),
          ]),
        ),
        Expanded(
          child: _f == null
              ? const Center(child: Text('নম্বর লিখে সার্চ করুন'))
              : Loader<List<dynamic>>(
                  future: _f!,
                  builder: (list) => ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final p = list[i] as Map<String, dynamic>;
                      return Card(
                        child: ListTile(
                          title: Text('${p['name']} • ${p['phone']}'),
                          subtitle: Text('গেম আইডি ${p['game_id']} • ব্যালেন্স ${taka(_bal(p))}${p['banned'] == true ? ' • ব্যান' : ''}'),
                          onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AdminUserDetailPage(profile: p))),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) => v == 'pw' ? _reset(p) : _ban(p),
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'pw', child: Text('পাসওয়ার্ড রিসেট')),
                              PopupMenuItem(value: 'ban', child: Text(p['banned'] == true ? 'আনব্যান' : 'ব্যান')),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ]);
}


// ---------- আরও (পুরনো অ্যাডমিন প্যানেলের মেনু) ----------
// পুরনো অ্যাপের বড় সাদা মেনু কার্ডের মতো করে সাজানো।
class AdminMore extends StatelessWidget {
  const AdminMore({super.key});

  Widget _card(BuildContext context, IconData icon, String title, String sub, Widget page) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              child: Row(children: [
                Icon(icon, color: Colors.black, size: 32),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: const TextStyle(color: Colors.black, fontSize: 19, fontWeight: FontWeight.w900)),
                    if (sub.isNotEmpty)
                      Text(sub, style: const TextStyle(color: Colors.black54, fontSize: 13)),
                  ]),
                ),
                const Icon(Icons.chevron_right, color: Colors.black54),
              ]),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => ListView(children: [
        const SizedBox(height: 6),
        _card(context, Icons.send, 'SEND MONEY', 'ইউজারের ওয়ালেটে টাকা পাঠান', const AdminSendMoneyPage()),
        _card(context, Icons.campaign, 'নোটিশ ম্যানেজার', 'নোটিশ যোগ / মুছে ফেলুন', const AdminNoticesPage()),
        _card(context, Icons.notifications_active, 'পুশ নোটিফিকেশন', 'অ্যাপে ঘোষণা পাঠান', const AdminPushPage()),
        _card(context, Icons.rule, 'ম্যাচের নিয়ম', 'Free Fire / Ludo নিয়ম লিখুন', const AdminRulesPage()),
        const SizedBox(height: 16),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text('পুরনো অ্যাডমিন প্যানেলের মেনুগুলো এখানে রাখা হয়েছে।',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13)),
        ),
      ]);
}

// ---------- Send Money ----------
class AdminSendMoneyPage extends StatefulWidget {
  const AdminSendMoneyPage({super.key});
  @override
  State<AdminSendMoneyPage> createState() => _AdminSendMoneyPageState();
}

class _AdminSendMoneyPageState extends State<AdminSendMoneyPage> {
  bool _busy = false;

  Future<void> _send() async {
    final m = await showForm(context, 'Send Money', const [
      F('phone', 'মোবাইল নম্বর', number: true),
      F('amount', 'টাকার পরিমাণ', number: true),
      F('note', 'নোট (ঐচ্ছিক)'),
    ], ok: 'পাঠান');
    if (m == null || !mounted) return;
    final phone = (m['phone'] ?? '').trim();
    final amount = int.tryParse((m['amount'] ?? '').trim()) ?? 0;
    if (!phoneRe.hasMatch(phone)) {
      toast(context, 'সঠিক মোবাইল নম্বর দিন (যেমন 01XXXXXXXXX)', err: true);
      return;
    }
    if (amount <= 0) {
      toast(context, 'টাকার পরিমাণ ০-এর বেশি হতে হবে', err: true);
      return;
    }
    setState(() => _busy = true);
    await run(context, () => sb.rpc('admin_send_money', params: {
          'p_phone': phone,
          'p_amount': amount,
          'p_note': (m['note'] ?? '').trim(),
        }), ok: 'টাকা পাঠানো হয়েছে');
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Send Money')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('ইউজারের মোবাইল নম্বর দিয়ে তার ওয়ালেটে টাকা পাঠান। টাকাটা ব্যালেন্সে যোগ হবে আর লেনদেনের হিসেবে দেখাবে।',
                style: TextStyle(fontSize: 15)),
            const SizedBox(height: 20),
            FilledButton(onPressed: _busy ? null : _send, child: Text(_busy ? 'পাঠানো হচ্ছে…' : 'টাকা পাঠান')),
          ]),
        ),
      );
}

// ---------- ইউজার ডিটেইল ----------
class AdminUserDetailPage extends StatefulWidget {
  final Map<String, dynamic> profile;
  const AdminUserDetailPage({super.key, required this.profile});
  @override
  State<AdminUserDetailPage> createState() => _AdminUserDetailPageState();
}

class _AdminUserDetailPageState extends State<AdminUserDetailPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final id = '${widget.profile['id']}';
    final w = await sb.from('wallets').select('balance').eq('user_id', id).maybeSingle();
    final dep = await sb
        .from('deposits')
        .select('amount, method, status, created_at')
        .eq('user_id', id)
        .order('created_at', ascending: false)
        .limit(10);
    final wd = await sb
        .from('withdrawals')
        .select('amount, method, status, created_at')
        .eq('user_id', id)
        .order('created_at', ascending: false)
        .limit(10);
    return {'balance': w?['balance'] ?? 0, 'dep': dep, 'wd': wd};
  }

  Widget _row(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Expanded(child: Text(a, style: const TextStyle(color: Colors.white70))),
          Text(b, style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;
    return Scaffold(
      appBar: AppBar(title: Text('${p['name'] ?? ''}')),
      body: Loader<Map<String, dynamic>>(
        future: _f,
        builder: (d) {
          final dep = d['dep'] as List<dynamic>;
          final wd = d['wd'] as List<dynamic>;
          return ListView(padding: const EdgeInsets.all(16), children: [
            _row('নাম', '${p['name'] ?? '-'}'),
            _row('মোবাইল', '${p['phone'] ?? '-'}'),
            _row('গেম আইডি', '${p['game_id'] ?? '-'}'),
            _row('ব্যালেন্স', taka(d['balance'])),
            _row('ম্যাচ খেলেছে', '${p['matches_played'] ?? 0}'),
            _row('মোট কিল', '${p['total_kills'] ?? 0}'),
            _row('মোট জয়', '${p['total_wins'] ?? 0}'),
            _row('অবস্থা', p['banned'] == true ? 'ব্যান করা' : 'সচল'),
            const SizedBox(height: 16),
            const Text('সাম্প্রতিক ডিপোজিট', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            if (dep.isEmpty) const ListTile(title: Text('কোনো ডিপোজিট নেই')),
            for (final e in dep)
              ListTile(
                dense: true,
                title: Text('${taka(e['amount'])} • ${e['method']}'),
                subtitle: Text('${e['status']} • ${when(e['created_at'])}'),
              ),
            const SizedBox(height: 8),
            const Text('সাম্প্রতিক উইথড্র', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            if (wd.isEmpty) const ListTile(title: Text('কোনো উইথড্র নেই')),
            for (final e in wd)
              ListTile(
                dense: true,
                title: Text('${taka(e['amount'])} • ${e['method']}'),
                subtitle: Text('${e['status']} • ${when(e['created_at'])}'),
              ),
          ]);
        },
      ),
    );
  }
}

// ---------- নোটিশ ম্যানেজার ----------
class AdminNoticesPage extends StatefulWidget {
  const AdminNoticesPage({super.key});
  @override
  State<AdminNoticesPage> createState() => _AdminNoticesPageState();
}

class _AdminNoticesPageState extends State<AdminNoticesPage> {
  late Future<List<Map<String, dynamic>>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final row = await sb.from('app_config').select('value').eq('key', 'notices').maybeSingle();
    final v = row?['value'];
    if (v is List) return [for (final e in v) if (e is Map) Map<String, dynamic>.from(e)];
    return [];
  }

  Future<void> _save(List<Map<String, dynamic>> list) async {
    final ok = await run(context, () => sb.rpc('admin_save_notices', params: {'p_notices': list}),
        ok: 'নোটিশ সংরক্ষিত হয়েছে');
    if (ok) setState(() => _f = _load());
  }

  Future<void> _add() async {
    final m = await showForm(context, 'নতুন নোটিশ', const [F('title', 'শিরোনাম'), F('body', 'বিস্তারিত')],
        ok: 'যোগ করুন');
    if (m == null || !mounted) return;
    if ((m['title'] ?? '').isEmpty) {
      toast(context, 'শিরোনাম দিন', err: true);
      return;
    }
    final list = await _f;
    final now = DateTime.now();
    final date = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    list.insert(0, {'title': m['title'], 'body': m['body'] ?? '', 'date': date});
    await _save(list);
  }

  Future<void> _delete(int index) async {
    if (!await confirm(context, 'এই নোটিশটি মুছে ফেলবেন?')) return;
    if (!mounted) return;
    final list = await _f;
    list.removeAt(index);
    await _save(list);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('নোটিশ ম্যানেজার')),
        floatingActionButton: FloatingActionButton(onPressed: _add, child: const Icon(Icons.add)),
        body: Loader<List<Map<String, dynamic>>>(
          future: _f,
          builder: (list) => list.isEmpty
              ? const Center(child: Text('এখনো কোনো নোটিশ নেই'))
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final n = list[i];
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.campaign_outlined),
                        title: Text('${n['title'] ?? 'নোটিশ'}'),
                        subtitle: Text('${n['body'] ?? ''}${n['date'] != null ? '\n${n['date']}' : ''}'),
                        isThreeLine: true,
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _delete(i),
                        ),
                      ),
                    );
                  },
                ),
        ),
      );
}

// ---------- পুশ নোটিফিকেশন (ইন-অ্যাপ ঘোষণা) ----------
// সতর্কতা: এটি ডিভাইসে আসল পুশ পাঠায় না — ঘোষণাটি announcements টেবিলে
// যায়, আর ইউজার অ্যাপের নোটিশ পেজে দেখা যায়। আসল পুশের জন্য
// OneSignal/FCM সেটআপ লাগবে (এই আপডেটে নেই)।
class AdminPushPage extends StatefulWidget {
  const AdminPushPage({super.key});
  @override
  State<AdminPushPage> createState() => _AdminPushPageState();
}

class _AdminPushPageState extends State<AdminPushPage> {
  late Future<List<dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<List<dynamic>> _load() =>
      sb.from('announcements').select().order('created_at', ascending: false).limit(10);

  Future<void> _send() async {
    final m = await showForm(context, 'ঘোষণা পাঠান', const [F('title', 'শিরোনাম'), F('body', 'বার্তা')],
        ok: 'পাঠান');
    if (m == null || !mounted) return;
    if ((m['title'] ?? '').isEmpty || (m['body'] ?? '').isEmpty) {
      toast(context, 'শিরোনাম ও বার্তা দুটোই দিন', err: true);
      return;
    }
    final ok = await run(
        context,
        () => sb.from('announcements').insert({'title': m['title'], 'body': m['body']}),
        ok: 'ঘোষণা পাঠানো হয়েছে');
    if (ok) setState(() => _f = _load());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('পুশ নোটিফিকেশন')),
        floatingActionButton: FloatingActionButton(onPressed: _send, child: const Icon(Icons.send)),
        body: Column(children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'এই ঘোষণা অ্যাপের ভেতরে নোটিশ হিসেবে সব ইউজার দেখতে পাবে। ফোনের আসল পুশ নোটিফিকেশন (OneSignal/FCM) এখনো যুক্ত হয়নি — সেটার জন্য আলাদা সেটআপ লাগবে।',
              style: TextStyle(fontSize: 14),
            ),
          ),
          Expanded(
            child: Loader<List<dynamic>>(
              future: _f,
              builder: (list) => list.isEmpty
                  ? const Center(child: Text('এখনো কোনো ঘোষণা পাঠানো হয়নি'))
                  : ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (c, i) {
                        final a = list[i] as Map<String, dynamic>;
                        return Card(
                          child: ListTile(
                            leading: const Icon(Icons.notifications_active),
                            title: Text('${a['title']}'),
                            subtitle: Text('${a['body']}\n${when(a['created_at'])}'),
                            isThreeLine: true,
                          ),
                        );
                      },
                    ),
            ),
          ),
        ]),
      );
}

// ---------- ম্যাচের নিয়ম এডিটর (Free Fire / Ludo) ----------
class AdminRulesPage extends StatefulWidget {
  const AdminRulesPage({super.key});
  @override
  State<AdminRulesPage> createState() => _AdminRulesPageState();
}

class _AdminRulesPageState extends State<AdminRulesPage> {
  final _ff = TextEditingController();
  final _ludo = TextEditingController();
  late Future<void> _f;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<void> _load() async {
    final rows = await sb
        .from('app_config')
        .select('key, value')
        .inFilter('key', ['rules_ff', 'rules_ludo']);
    final map = {for (final r in (rows as List)) '${r['key']}': r['value']};
    String txt(String k) {
      final v = map[k];
      if (v is String) return v;
      return v == null ? '' : '$v';
    }

    _ff.text = txt('rules_ff');
    _ludo.text = txt('rules_ludo');
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    await run(
        context,
        () => sb.rpc('admin_save_rules', params: {
              'p_ff': _ff.text.trim(),
              'p_ludo': _ludo.text.trim(),
            }),
        ok: 'নিয়ম সংরক্ষিত হয়েছে');
    if (mounted) setState(() => _busy = false);
  }

  @override
  void dispose() {
    _ff.dispose();
    _ludo.dispose();
    super.dispose();
  }

  Widget _field(String label, TextEditingController c) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: TextField(
          controller: c,
          maxLines: 8,
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
            alignLabelWithHint: true,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ম্যাচের নিয়ম')),
        body: FutureBuilder<void>(
          future: _f,
          builder: (c, s) {
            if (s.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (s.hasError) {
              return Center(
                  child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(errText(s.error!), textAlign: TextAlign.center)));
            }
            return ListView(padding: const EdgeInsets.all(16), children: [
              _field('Free Fire নিয়ম', _ff),
              _field('Ludo King নিয়ম', _ludo),
              FilledButton(
                  onPressed: _busy ? null : _save,
                  child: Text(_busy ? 'সংরক্ষণ হচ্ছে…' : 'সংরক্ষণ করুন')),
            ]);
          },
        ),
      );
}
