import 'package:flutter/material.dart';

const navy = Color(0xFF050B1F);
const navy2 = Color(0xFF0B1330);
const cardDark = Color(0xFF0A0A1F);
const ffTeal = Color(0xFF0E9F85);
const ludoGreen = Color(0xFF0B6B1A);
const ludoRed = Color(0xFFB30000);

class GameInfo {
  final String key; // stored in tournaments.game
  final String title;
  final Color appBar;
  final List<Color> gradient;
  final IconData icon;
  final String boardLabel;
  const GameInfo(this.key, this.title, this.appBar, this.gradient, this.icon, this.boardLabel);
}

const games = [
  GameInfo('Free Fire', 'Free Fire', ffTeal, [Color(0xFF0B7D6A), Color(0xFF12B398)], Icons.local_fire_department, 'MAP'),
  GameInfo('Ludo King', 'Ludu King', ludoGreen, [Color(0xFF8E0000), Color(0xFFD10F0F)], Icons.casino, 'BOARD TYPE'),
];

GameInfo gameOf(String? key) => games.firstWhere((g) => g.key == key, orElse: () => games.first);
