AMAR E-SPORTS — UI Refinement Package

এই ZIP-এ Flutter source এবং আগের দেওয়া image resources একসাথে রাখা হয়েছে।

এই আপডেটে:
- Home ও Me header-এ Amar E-sports logo-র মাপ Reference অনুযায়ী সমন্বয় করা হয়েছে।
- Home screen-এর horizontal padding, banner area, Daily Matches spacing এবং game-card gap কম্প্যাক্ট করা হয়েছে।
- Bottom Play/Me navigation-এর height, icon ও label size কমানো হয়েছে।
- Me section-এর menu buttons, icons ও text size কমানো হয়েছে।
- Profile header-এর wallet amount profile data থেকে দেখানো হয়।
- আগের দেওয়া Free Fire, Ludo King, WhatsApp, Telegram এবং How to Play assets অন্তর্ভুক্ত আছে।
- Existing Supabase / admin source files অপরিবর্তিত রাখা হয়েছে, UI source ছাড়া।

নোট:
এটি source ZIP, APK নয়। এই environment-এ Flutter SDK পাওয়া যায়নি, তাই Android build চালিয়ে APK compile/test করা সম্ভব হয়নি। Android Studio বা Flutter SDK-তে app/pubspec.yaml খুলে dependencies resolve করে build করতে হবে।
