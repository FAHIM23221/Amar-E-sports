import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'util.dart';
import 'admin.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Amar E-sports Admin',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark),
        ),
        home: const AdminGate(),
      );
}

class AdminGate extends StatelessWidget {
  const AdminGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: sb.auth.onAuthStateChange,
        builder: (c, s) {
          final session = sb.auth.currentSession;
          if (session == null) return const AdminLogin();
          return AdminCheck(key: ValueKey(session.user.id));
        },
      );
}

class AdminLogin extends StatefulWidget {
  const AdminLogin({super.key});
  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;

  Future<void> _login() async {
    final phone = _phone.text.trim();
    if (!phoneRe.hasMatch(phone) || _pass.text.isEmpty) {
      toast(context, 'নম্বর ও পাসওয়ার্ড ঠিকভাবে দিন', err: true);
      return;
    }
    setState(() => _busy = true);
    await run(context, () => sb.auth.signInWithPassword(email: emailOf(phone), password: _pass.text));
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Image.asset('assets/images/logo.png', width: 96, height: 96),
                const SizedBox(height: 8),
                const Text('Amar E-sports Admin', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 24),
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  maxLength: 11,
                  decoration: const InputDecoration(labelText: 'মোবাইল নম্বর', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'পাসওয়ার্ড', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(onPressed: _busy ? null : _login, child: const Text('লগইন')),
                ),
              ]),
            ),
          ),
        ),
      );
}

class AdminCheck extends StatefulWidget {
  const AdminCheck({super.key});
  @override
  State<AdminCheck> createState() => _AdminCheckState();
}

class _AdminCheckState extends State<AdminCheck> {
  late Future<bool> _f;
  @override
  void initState() {
    super.initState();
    _f = _check();
  }

  Future<bool> _check() async => (await sb.rpc('is_admin')) == true;

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
        future: _f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (s.data == true) {
            return Scaffold(
              appBar: AppBar(
                title: const Text('অ্যাডমিন প্যানেল'),
                actions: [IconButton(icon: const Icon(Icons.logout), onPressed: () => sb.auth.signOut())],
              ),
              body: const AdminPage(),
            );
          }
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.lock, size: 56),
                  const SizedBox(height: 12),
                  Text(s.hasError ? errText(s.error!) : 'এই অ্যাকাউন্টের অ্যাডমিন অনুমতি নেই', textAlign: TextAlign.center),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('লগআউট')),
                ]),
              ),
            ),
          );
        },
      );
}
