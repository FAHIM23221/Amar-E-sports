# Build fix — update-8

## সমস্যা
GitHub Actions-এ `flutter build apk --release` ফেল করছিল:
`Target kernel_snapshot_program failed` / `compileFlutterBuildRelease`।

## কারণ
`app/lib/home.dart`-এর কাউন্টডাউন কোডে একটা টাইপ ভুল ছিল:
`n.toString().padLeft(2, 0)` — `padLeft`-এর ২য় আর্গুমেন্ট স্ট্রিং হতে হয়,
এখানে সংখ্যা `0` দেওয়া ছিল। Dart কম্পাইলার তাই পুরো অ্যাপ কম্পাইল করতে পারেনি।

## ঠিক করা হয়েছে
- `app/lib/home.dart` লাইন ৭১: `padLeft(2, 0)` → `padLeft(2, '0')`
- একই ফাইলে ম্যাচ ডিটেইলসে ডাবল `if` লাইনটা একটা করা হয়েছে (অপ্রয়োজনীয় ডুপ্লিকেট)।
- Dart analyzer দিয়ে পুরো কোড যাচাই করা হয়েছে — আর কোনো `argument_type` এরর নেই।

## ব্যবহার
এই zip-এর `app/lib/home.dart` ফাইলটা GitHub রিপোতে আগেরটার জায়গায় বসিয়ে
আবার workflow চালালেই বিল্ড হওয়ার কথা।
