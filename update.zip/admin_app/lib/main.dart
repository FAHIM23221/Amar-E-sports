import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin.dart';
import 'config.dart';
import 'util.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  // অ্যাপ চালু হলেই পুরনো সেশন সাফ: পাসকোড স্ক্রিন এড়িয়ে যাওয়া যাবে না।
  try {
    await sb.auth.signOut();
  } catch (_) {}
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Amar E-sports Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: adminTeal, brightness: Brightness.dark),
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: adminNavy,
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      home: const AdminGate(),
    );
  }
}

class AdminGate extends StatelessWidget {
  const AdminGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, snap) {
        final session = snap.data?.session ?? sb.auth.currentSession;
        if (session == null) return const PasscodeLogin();
        return const AdminCheck();
      },
    );
  }
}

/// পাসকোড দিয়ে লগইন — পুরনো অ্যাপের স্ক্রিনের মতো: কালো ব্যাকগ্রাউন্ড,
/// সাদা তালার আইকন, একটাই "Passcode" ফিল্ড, টিল "Continue" বোতাম।
/// ফোন নম্বর বা পাসওয়ার্ডের কোনো ফিল্ড নেই।
class PasscodeLogin extends StatefulWidget {
  const PasscodeLogin({super.key});

  @override
  State<PasscodeLogin> createState() => _PasscodeLoginState();
}

class _PasscodeLoginState extends State<PasscodeLogin> {
  final _code = TextEditingController();
  var _busy = false;

  Future<void> _continue() async {
    final code = _code.text.trim();
    if (!passcodeRe.hasMatch(code)) {
      toast(context, '৪ সংখ্যার পাসকোড দিন');
      return;
    }
    setState(() => _busy = true);
    try {
      // প্রথমে পাসকোড যাচাই (সার্ভার-সাইড RPC)।
      final ok = await sb.rpc('verify_admin_passcode', params: {'p_code': code});
      if (ok != true) {
        toast(context, 'ভুল পাসকোড');
        _code.clear();
        return;
      }
      // পাসকোড ঠিক হলে ডেডিকেটেড অ্যাডমিন অ্যাকাউন্টে সাইন ইন
      // (পাসওয়ার্ড = পাসকোড)। এতে is_admin() ঠিকঠাক কাজ করে।
      await sb.auth.signInWithPassword(
        email: adminEmail,
        password: adminAuthPassword(code),
      );
      await logAdmin('login', 'লগইন');
    } catch (e) {
      toast(context, errText(e));
      _code.clear();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// আলাদা অ্যাডমিন অ্যাকাউন্ট দিয়ে লগইন (ডেভেলপার অ্যাপে যোগ করা
  /// অ্যাডমিনরা এভাবে ঢোকে: ফোন নম্বর + নিজের পাসকোড)। এখানে গ্লোবাল
  /// পাসকোড যাচাই লাগে না — পাসওয়ার্ডই পাসকোড, সাইন-ইন সফল হওয়াই
  /// প্রমাণ। AdminCheck-এ is_admin + ব্যান যাচাই হয়।
  Future<void> _loginOtherAdmin() async {
    final phoneC = TextEditingController();
    final codeC = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('অ্যাডমিন লগইন', textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: phoneC,
              keyboardType: TextInputType.phone,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black, fontSize: 17),
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(hintText: 'মোবাইল নম্বর (01XXXXXXXXX)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: codeC,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 4,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black, fontSize: 17),
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(hintText: 'Passcode', counterText: ''),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('লগইন')),
        ],
      ),
    );
    if (go != true || !mounted) return;
    final phone = phoneC.text.trim();
    final code = codeC.text.trim();
    if (!phoneRe.hasMatch(phone) || !passcodeRe.hasMatch(code)) {
      toast(context, 'সঠিক নম্বর ও ৪ সংখ্যার পাসকোড দিন');
      return;
    }
    setState(() => _busy = true);
    try {
      await sb.auth.signInWithPassword(
        email: emailOf(phone),
        password: adminAuthPassword(code),
      );
      await logAdmin('login', 'লগইন ($phone)');
    } catch (e) {
      toast(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, color: Colors.white, size: 56),
              const SizedBox(height: 48),
              TextField(
                controller: _code,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 8),
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  hintText: 'Passcode',
                  hintStyle: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 0),
                  counterText: '',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: adminTeal, width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14)),
                    borderSide: BorderSide(color: adminTeal, width: 2),
                  ),
                ),
                onSubmitted: (_) => _continue(),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: _busy ? null : _continue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: adminTeal,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: _busy
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : const Text('Continue', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 18),
              TextButton(
                onPressed: _busy ? null : _loginOtherAdmin,
                child: const Text('অন্য অ্যাকাউন্ট দিয়ে লগইন',
                    style: TextStyle(color: Colors.white70, fontSize: 15)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// লগইন গেটের ফলাফল: অ্যাডমিন কি না, ব্যান কি না, মেইনটেন্যান্স,
/// ফোর্স/সফট আপডেট, ফিচার টগল — সব একসাথে যাচাই হয়।
class _GateResult {
  final bool isAdmin;
  final bool banned;
  final bool maintenance;
  final String maintenanceMessage;
  final bool needsUpdate;
  final bool forceUpdate;
  final String updateUrl;
  final String minVersion;
  const _GateResult({
    required this.isAdmin,
    required this.banned,
    this.maintenance = false,
    this.maintenanceMessage = '',
    this.needsUpdate = false,
    this.forceUpdate = false,
    this.updateUrl = '',
    this.minVersion = '',
  });
}

/// সাইন ইন করা অ্যাকাউন্টটি সত্যিই অ্যাডমিন কি না, ব্যান কি না যাচাই করে;
/// তারপর মেইনটেন্যান্স / ফোর্স আপডেট গেট পার হলে প্যানেলে ঢোকে।
class AdminCheck extends StatelessWidget {
  const AdminCheck({super.key});

  Future<_GateResult> _load() async {
    final isAdmin = await sb.rpc('is_admin').then((v) => v == true).catchError((_) => false);
    if (!isAdmin) return const _GateResult(isAdmin: false, banned: false);
    // ব্যান চেক: সাইন-ইন করা অ্যাকাউন্টের প্রোফাইল।
    var banned = false;
    try {
      final row = await sb.from('profiles').select('is_banned').eq('id', sb.auth.currentUser!.id).maybeSingle();
      banned = (row as Map?)?['is_banned'] == true;
    } catch (_) {}
    if (banned) return const _GateResult(isAdmin: true, banned: true);
    // মেইনটেন্যান্স / আপডেট / টগল — app_config থেকে একবারে।
    var maintenance = false;
    var maintenanceMessage = '';
    var minVersion = '';
    var forceUpdate = false;
    var updateUrl = '';
    try {
      final rows = await sb.from('app_config').select();
      final cfg = {for (final r in rows) r['key'] as String: r['value']};
      maintenance = cfg['maintenance_admin'] == true;
      maintenanceMessage = '${cfg['maintenance_message'] ?? ''}';
      minVersion = '${cfg['min_version_admin'] ?? ''}';
      forceUpdate = cfg['force_admin'] == true;
      updateUrl = '${cfg['update_url_admin'] ?? ''}';
      final tog = cfg['feature_toggles'];
      featureToggles = tog is Map ? Map<String, dynamic>.from(tog) : {};
    } catch (_) {}
    final needsUpdate = minVersion.trim().isNotEmpty &&
        compareVersions(appVersion, minVersion.trim()) < 0;
    if (needsUpdate && !forceUpdate) {
      adminSoftUpdate = SoftUpdate(minVersion, updateUrl);
    }
    return _GateResult(
      isAdmin: true,
      banned: false,
      maintenance: maintenance,
      maintenanceMessage: maintenanceMessage,
      needsUpdate: needsUpdate,
      forceUpdate: forceUpdate,
      updateUrl: updateUrl,
      minVersion: minVersion,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_GateResult>(
      future: _load(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator(color: adminTeal)),
          );
        }
        final g = snap.data ?? const _GateResult(isAdmin: false, banned: false);
        if (!g.isAdmin) {
          return Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('এই অ্যাকাউন্ট অ্যাডমিন নয়', style: TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                    onPressed: () async {
                      await sb.auth.signOut();
                    },
                    child: const Text('লগআউট'),
                  ),
                ],
              ),
            ),
          );
        }
        if (g.banned) {
          return Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.block, color: Colors.red, size: 56),
                  const SizedBox(height: 16),
                  const Text('আপনার অ্যাডমিন অ্যাকাউন্ট বন্ধ করা হয়েছে',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                    onPressed: () async {
                      await sb.auth.signOut();
                    },
                    child: const Text('লগআউট'),
                  ),
                ],
              ),
            ),
          );
        }
        if (g.maintenance) return AdminMaintenanceScreen(message: g.maintenanceMessage);
        if (g.needsUpdate && g.forceUpdate) {
          return AdminForceUpdateScreen(url: g.updateUrl, minVersion: g.minVersion);
        }
        return const AdminHome();
      },
    );
  }
}

/// অ্যাডমিন মেইনটেন্যান্স স্ক্রিন — লোগো + মেসেজ, ভেতরে ঢোকার উপায় নেই।
class AdminMaintenanceScreen extends StatelessWidget {
  final String message;
  const AdminMaintenanceScreen({super.key, required this.message});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo.png', width: 120, height: 120),
                  const SizedBox(height: 28),
                  const Icon(Icons.build, size: 44, color: Colors.white70),
                  const SizedBox(height: 16),
                  const Text('মেইনটেন্যান্স চলছে',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 12),
                  Text(
                    message.isEmpty ? 'অ্যাডমিন প্যানেল এখন মেইনটেন্যান্সে আছে। কিছুক্ষণ পর আবার চেষ্টা করুন।' : message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                    onPressed: () async {
                      await sb.auth.signOut();
                    },
                    child: const Text('লগআউট'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

/// অ্যাডমিন ফোর্স আপডেট স্ক্রিন — আপডেট না করে প্যানেলে ঢোকা যায় না।
class AdminForceUpdateScreen extends StatelessWidget {
  final String url;
  final String minVersion;
  const AdminForceUpdateScreen({super.key, required this.url, required this.minVersion});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/images/logo.png', width: 120, height: 120),
                  const SizedBox(height: 28),
                  const Text('নতুন আপডেট এসেছে',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 12),
                  Text(
                    'চালিয়ে যেতে $minVersion ভার্সনে আপডেট করুন।',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: url.isEmpty
                          ? null
                          : () async {
                              try {
                                await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                              } catch (_) {
                                if (context.mounted) toast(context, 'লিংক খোলা যায়নি', err: true);
                              }
                            },
                      style: ElevatedButton.styleFrom(backgroundColor: adminTeal, foregroundColor: Colors.white),
                      child: const Text('আপডেট করুন', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () async {
                      await sb.auth.signOut();
                    },
                    child: const Text('লগআউট', style: TextStyle(color: Colors.white70)),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}
