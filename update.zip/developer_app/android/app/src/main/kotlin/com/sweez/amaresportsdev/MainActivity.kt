package com.sweez.amaresportsdev

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
