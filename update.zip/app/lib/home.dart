import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'util.dart';
import 'links.dart';
import 'wallet.dart';

const ledgerLabel = {
  'deposit': 'ডিপোজিট',
  'join_fee': 'জয়েন ফি',
  'prize': 'প্রাইজ',
  'withdraw_hold': 'উইথড্র (আটকানো)',
  'withdraw_refund': 'উইথড্র ফেরত',
  'refund': 'ফি ফেরত',
};

// ---------------- Shell: Play / Me ----------------
class HomeShell extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onProfileChanged;
  const HomeShell({super.key, required this.profile, required this.onProfileChanged});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF030B2B),
        body: SafeArea(
          child: IndexedStack(index: _i, children: [
            const PlayPage(),
            ProfilePage(profile: widget.profile, onChanged: widget.onProfileChanged),
          ]),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            height: 66,
            decoration: const BoxDecoration(color: Color(0xFF030B2B)),
            child: Row(children: [
              _navItem(Icons.games, 'Play', 0),
              _navItem(Icons.account_circle, 'Me', 1),
            ]),
          ),
        ),
      );

  Widget _navItem(IconData icon, String label, int index) {
    final selected = _i == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _i = index),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 27, color: selected ? const Color(0xFFE6E9F5) : Colors.white38),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 15, color: selected ? const Color(0xFFE6E9F5) : Colors.white38)),
        ]),
      ),
    );
  }
}

// ---------------- Home (Play) ----------------
const _defaultBanners = [
  {'title': 'কিভাবে খেলবেন?', 'subtitle': 'ভিডিওটি দেখুন', 'url': '', 'image': '', 'asset': 'assets/images/how_to_play_banner.jpg'},
  {'title': 'Telegram কমিউনিটিতে যোগ দিন', 'subtitle': '', 'url': '', 'image': '', 'asset': 'assets/images/telegram_community_banner.jpg'},
  {'title': 'WhatsApp সাপোর্ট', 'subtitle': '', 'url': '', 'image': '', 'asset': 'assets/images/whatsapp_community_banner.jpg'},
];

const _bannerColors = [
  [Color(0xFF3B0A2A), Color(0xFF0B1B4A)],
  [Color(0xFF0A3D62), Color(0xFF1B1464)],
  [Color(0xFF0B4F2B), Color(0xFF062A16)],
];

class PlayPage extends StatefulWidget {
  const PlayPage({super.key});
  @override
  State<PlayPage> createState() => _PlayPageState();
}

class _PlayPageState extends State<PlayPage> {
  late Future<Map<String, dynamic>> _f;
  final _pc = PageController();
  Timer? _timer;
  int _page = 0;
  int _count = 3;

  @override
  void initState() {
    super.initState();
    _f = _load();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!_pc.hasClients || _count < 2) return;
      _pc.animateToPage((_page + 1) % _count, duration: const Duration(milliseconds: 450), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final w = await sb.from('wallets').select('balance').eq('user_id', me).maybeSingle();
    final cfg = await loadConfig();
    return {'balance': w?['balance'] ?? 0, 'cfg': cfg};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 19, bottom: 20),
        child: Row(children: [
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600, letterSpacing: 0.2, fontSize: 20, color: Colors.white)),
          ),
          const Expanded(child: Divider(color: Colors.white, thickness: 1)),
        ]),
      );

  String _fallbackBannerAsset(Map b, int i) {
    final title = '${b['title'] ?? ''}'.toLowerCase();
    if (title.contains('whatsapp') || title.contains('হোয়াটসঅ্যাপ')) {
      return 'assets/images/whatsapp_community_banner.jpg';
    }
    if (title.contains('telegram') || title.contains('টেলিগ্রাম')) {
      return 'assets/images/telegram_community_banner.jpg';
    }
    if (title.contains('play') || title.contains('খেল') || title.contains('ভিডিও') || title.contains('video')) {
      return 'assets/images/how_to_play_banner.jpg';
    }
    const defaults = [
      'assets/images/how_to_play_banner.jpg',
      'assets/images/telegram_community_banner.jpg',
      'assets/images/whatsapp_community_banner.jpg',
    ];
    return defaults[i % defaults.length];
  }

  Widget _banner(Map b, int i, Map<String, dynamic> cfg) {
    final colors = _bannerColors[i % _bannerColors.length];
    final img = '${b['image'] ?? ''}'.trim();
    final configuredAsset = '${b['asset'] ?? ''}'.trim();
    // Keep configured remote images/assets; use the supplied original artwork
    // whenever a banner record has no image configured.
    final asset = configuredAsset.isNotEmpty ? configuredAsset : (img.isEmpty ? _fallbackBannerAsset(b, i) : '');
    return GestureDetector(
      onTap: () => openUrl(context, '${b['url'] ?? ''}'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 1),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (asset.isNotEmpty)
            Image.asset(asset, fit: BoxFit.cover, alignment: Alignment.center, filterQuality: FilterQuality.high)
          else
            Image.network(
              img,
              fit: BoxFit.cover,
              alignment: Alignment.center,
              filterQuality: FilterQuality.high,
              errorBuilder: (_, __, ___) => Image.asset(
                _fallbackBannerAsset(b, i),
                fit: BoxFit.cover,
                alignment: Alignment.center,
                filterQuality: FilterQuality.high,
              ),
            ),
        ]),
      ),
    );
  }

  Widget _gameCard(GameInfo g, String asset) => Expanded(
        child: GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GameMatchesPage(game: g))),
          child: AspectRatio(
            aspectRatio: 1.67,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(7),
              child: Image.asset(asset, fit: BoxFit.cover, filterQuality: FilterQuality.high),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        future: _f,
        builder: (d) {
          final cfg = d['cfg'] as Map<String, dynamic>;
          final raw = cfg['banners'];
          final banners = (raw is List && raw.isNotEmpty) ? raw : _defaultBanners;
          _count = banners.length;
          return Stack(children: [
            RefreshIndicator(
              onRefresh: _refresh,
              child: ListView(padding: const EdgeInsets.fromLTRB(12, 8, 12, 88), children: [
                LayoutBuilder(builder: (context, constraints) {
                  final compact = constraints.maxWidth < 380;
                  final logoSize = compact ? 48.0 : 52.0;
                  final titleSize = compact ? 17.0 : (constraints.maxWidth < 430 ? 19.0 : 21.0);
                  return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                    ClipOval(child: Image.asset('assets/images/logo.png', width: logoSize, height: logoSize, fit: BoxFit.cover)),
                    SizedBox(width: compact ? 8 : 10),
                    Expanded(
                      child: Text('AMAR E-SPORTS', maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: titleSize, fontWeight: FontWeight.w900, letterSpacing: .2, color: Colors.white)),
                    ),
                    const SizedBox(width: 7),
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()));
                        _refresh();
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: compact ? 9 : 10),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.account_balance_wallet_outlined, color: const Color(0xFF07112E), size: compact ? 22 : 24),
                          const SizedBox(width: 5),
                          Text('${money(d['balance']).replaceAll('.00', '')} ৳',
                            style: TextStyle(color: const Color(0xFF07112E), fontSize: compact ? 17 : 19, fontWeight: FontWeight.w900)),
                        ]),
                      ),
                    ),
                  ]);
                }),
                const SizedBox(height: 10),
                AspectRatio(
                  aspectRatio: 1.84,
                  child: Stack(children: [
                    PageView.builder(
                      controller: _pc,
                      itemCount: banners.length,
                      onPageChanged: (v) => setState(() => _page = v),
                      itemBuilder: (c, i) => _banner(banners[i] as Map, i, cfg),
                    ),
                    Positioned(
                      bottom: 10,
                      left: 0,
                      right: 0,
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        for (var i = 0; i < banners.length; i++)
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: i == _page ? Colors.white70 : Colors.white38),
                          ),
                      ]),
                    ),
                  ]),
                ),
                _title('DAILY MATCHES'),
                Row(children: [
                  _gameCard(games[0], 'assets/images/freefire_card_resource.jpg'),
                  const SizedBox(width: 24),
                  _gameCard(games[1], 'assets/images/ludo_king_card_resource.jpg'),
                ]),
              ]),
            ),
            Positioned(
              right: 18,
              bottom: 18,
              child: Material(
                color: Colors.white,
                elevation: 4,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => openUrl(context, linkOf(cfg, 'whatsapp')),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: const BoxDecoration(color: Color(0xFF08A85A), shape: BoxShape.circle),
                      child: const Icon(Icons.chat, color: Colors.white, size: 21),
                    ),
                  ),
                ),
              ),
            ),
          ]);
        },
      );
}

// ---------------- Matches of one game ----------------
class GameMatchesPage extends StatefulWidget {
  final GameInfo game;
  const GameMatchesPage({super.key, required this.game});
  @override
  State<GameMatchesPage> createState() => _GameMatchesPageState();
}

class _GameMatchesPageState extends State<GameMatchesPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final me = sb.auth.currentUser!.id;
    final list = await sb
        .from('tournaments')
        .select()
        .eq('game', widget.game.key)
        .inFilter('status', ['open', 'live'])
        .order('starts_at', ascending: true)
        .limit(50);
    final mine = await sb.from('participants').select('tournament_id').eq('user_id', me);
    return {'list': list, 'mine': {for (final m in mine) '${m['tournament_id']}'}};
  }

  Future<void> _refresh() async {
    setState(() => _f = _load());
    await _f;
  }

  Future<void> _join(Map<String, dynamic> t) async {
    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
    if (!mounted) return;
    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': t['id']}), ok: 'জয়েন সফল হয়েছে');
    if (ok) _refresh();
  }

  Future<void> _room(Map<String, dynamic> t, bool joined) async {
    if (!joined) {
      toast(context, 'রুমের তথ্য দেখতে আগে ম্যাচে জয়েন করুন');
      return;
    }
    try {
      final r = await sb.from('tournament_rooms').select().eq('tournament_id', t['id']).maybeSingle();
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('ROOM INFO'),
          content: r == null || ('${r['room_id'] ?? ''}'.isEmpty)
              ? const Text('রুমের তথ্য এখনো দেওয়া হয়নি। ম্যাচ শুরুর আগে এখানে দেখতে পাবেন।')
              : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Room ID: ${r['room_id']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('Password: ${r['room_password'] ?? '-'}', style: const TextStyle(fontSize: 18)),
                ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
        ),
      );
    } catch (e) {
      if (mounted) toast(context, errText(e), err: true);
    }
  }

  Widget _stat(String label, Widget value) => Expanded(
        child: Column(children: [
          Text(label, style: const TextStyle(color: Colors.black87, fontSize: 15)),
          const SizedBox(height: 6),
          value,
        ]),
      );

  Widget _coin(dynamic v) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset('assets/images/coin.png', width: 26, height: 26),
        const SizedBox(width: 6),
        Text('$v', style: const TextStyle(color: Colors.black, fontSize: 26, fontWeight: FontWeight.bold)),
      ]);

  Widget _txt(String v) => Text(v, style: const TextStyle(color: Colors.black, fontSize: 21, fontWeight: FontWeight.bold));

  Widget _card(Map<String, dynamic> t, bool joined) {
    final g = widget.game;
    final slots = (t['slots'] as num).toInt();
    final cnt = (t['joined'] as num).toInt();
    final full = cnt >= slots;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 8, 14, 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Row(children: [
          CircleAvatar(radius: 28, backgroundColor: g.gradient.last, child: Icon(g.icon, color: Colors.white, size: 32)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${t['title']}', style: const TextStyle(color: Colors.black, fontSize: 24, fontWeight: FontWeight.bold)),
              Text(whenShort(t['starts_at']), style: const TextStyle(color: Color(0xFFC40000), fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
        const SizedBox(height: 14),
        Row(children: [_stat('WIN PRIZE', _coin(t['prize_pool'])), _stat('ENTRY FEE', _coin(t['fee']))]),
        const SizedBox(height: 14),
        Row(children: [
          _stat('TYPE', _txt('${t['mode'] ?? '-'}')),
          _stat(g.boardLabel, _txt('${t['board'] ?? '-'}'.toUpperCase())),
        ]),
        const SizedBox(height: 12),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              LinearProgressIndicator(value: slots == 0 ? 0 : cnt / slots, minHeight: 4, backgroundColor: Colors.black12, color: const Color(0xFF6EC6F0)),
              const SizedBox(height: 10),
              Padding(padding: const EdgeInsets.only(right: 12), child: Text('$cnt / $slots', style: const TextStyle(color: Colors.black87, fontSize: 16))),
            ]),
          ),
          const SizedBox(width: 12),
          Material(
            color: Colors.white,
            elevation: 3,
            borderRadius: BorderRadius.circular(6),
            child: InkWell(
              borderRadius: BorderRadius.circular(6),
              onTap: (joined || full) ? null : () => _join(t),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
                child: Text(joined ? 'JOINED' : (full ? 'FULL' : 'JOIN'),
                    style: TextStyle(color: (joined || full) ? Colors.black38 : Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: _darkBtn('DETAILS', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TournamentPage(id: '${t['id']}')))),
          ),
          const SizedBox(width: 12),
          Expanded(child: _darkBtn('ROOM INFO', () => _room(t, joined))),
        ]),
      ]),
    );
  }

  Widget _darkBtn(String label, VoidCallback onTap) => Material(
        color: cardDark,
        borderRadius: BorderRadius.circular(6),
        child: InkWell(
          borderRadius: BorderRadius.circular(6),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17))),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: navy,
        appBar: AppBar(
          backgroundColor: widget.game.appBar,
          foregroundColor: Colors.white,
          title: Text('${widget.game.title.replaceAll('Ludu King', 'Ludu')} Matches', style: const TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: CircleAvatar(
                backgroundColor: const Color(0xFF1E88E5),
                child: IconButton(
                  icon: const Icon(Icons.ios_share, color: Colors.white),
                  onPressed: () async {
                    await Clipboard.setData(const ClipboardData(text: 'Amar E-sports-এ দৈনিক ম্যাচ খেলুন এবং জিতুন প্রাইজ!'));
                    if (context.mounted) toast(context, 'শেয়ারের লেখা কপি হয়েছে');
                  },
                ),
              ),
            ),
          ],
        ),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final list = d['list'] as List<dynamic>;
            final mine = d['mine'] as Set<String>;
            return Column(children: [
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _refresh,
                  child: list.isEmpty
                      ? ListView(children: const [SizedBox(height: 200), Center(child: Text('এখন কোনো ম্যাচ নেই'))])
                      : ListView(children: [for (final t in list) _card(t as Map<String, dynamic>, mine.contains('${t['id']}'))]),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.info_outline, color: Color(0xFF6EC6F0), size: 20),
                  SizedBox(width: 8),
                  Text('Join a match and win exciting prizes. Good luck!', style: TextStyle(color: Colors.white70)),
                ]),
              ),
            ]);
          },
        ),
      );
}

// ---------------- Match details ----------------
class TournamentPage extends StatefulWidget {
  final String id;
  const TournamentPage({super.key, required this.id});
  @override
  State<TournamentPage> createState() => _TournamentPageState();
}

class _TournamentPageState extends State<TournamentPage> {
  late Future<Map<String, dynamic>> _f;
  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final t = await sb.from('tournaments').select().eq('id', widget.id).single();
    final me = sb.auth.currentUser!.id;
    final p = await sb.from('participants').select().eq('tournament_id', widget.id).eq('user_id', me).maybeSingle();
    Map<String, dynamic>? room;
    if (p != null) room = await sb.from('tournament_rooms').select().eq('tournament_id', widget.id).maybeSingle();
    return {'t': t, 'joined': p != null, 'room': room};
  }

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('DETAILS')),
        body: Loader<Map<String, dynamic>>(
          future: _f,
          builder: (d) {
            final t = d['t'] as Map<String, dynamic>;
            final joined = d['joined'] == true;
            final room = d['room'] as Map<String, dynamic>?;
            final g = gameOf('${t['game']}');
            final open = t['status'] == 'open' && (t['joined'] as int) < (t['slots'] as int);
            final me = sb.auth.currentUser!.id;
            int? myPrize;
            if (t['winners'] is List) {
              for (final w in t['winners']) {
                if (w['user_id'] == me) myPrize = (w['prize'] as num).toInt();
              }
            }
            Widget row(String a, String b) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(children: [Expanded(child: Text(a, style: const TextStyle(color: Colors.white70))), Text(b, style: const TextStyle(fontWeight: FontWeight.bold))]),
                );
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('${t['title']}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              row('গেম', g.title),
              row('শুরু', whenShort(t['starts_at'])),
              row('টাইপ', '${t['mode'] ?? '-'}'),
              row(g.boardLabel, '${t['board'] ?? '-'}'),
              row('এন্ট্রি ফি', taka(t['fee'])),
              row('মোট প্রাইজ', taka(t['prize_pool'])),
              row('স্লট', '${t['joined']}/${t['slots']}'),
              const SizedBox(height: 14),
              if (myPrize != null) Card(child: ListTile(leading: const Icon(Icons.emoji_events, color: Colors.amber), title: Text('আপনি জিতেছেন ${taka(myPrize)}'))),
              if (joined && room != null && '${room['room_id'] ?? ''}'.isNotEmpty)
                Card(child: ListTile(leading: const Icon(Icons.key), title: Text('রুম আইডি: ${room['room_id']}'), subtitle: Text('পাসওয়ার্ড: ${room['room_password'] ?? '-'}'))),
              if (joined && (room == null || '${room['room_id'] ?? ''}'.isEmpty))
                const Card(child: ListTile(leading: Icon(Icons.hourglass_top), title: Text('রুমের তথ্য শিগগির দেওয়া হবে'))),
              if (joined) const Card(child: ListTile(leading: Icon(Icons.check_circle, color: Colors.greenAccent), title: Text('আপনি এই ম্যাচে জয়েন করেছেন'))),
              if (!joined && open)
                FilledButton(
                  onPressed: () async {
                    if (!await confirm(context, '${taka(t['fee'])} কেটে এই ম্যাচে জয়েন করবেন?')) return;
                    if (!context.mounted) return;
                    final ok = await run(context, () => sb.rpc('join_tournament', params: {'p_tournament': widget.id}), ok: 'জয়েন সফল হয়েছে');
                    if (ok) _reload();
                  },
                  child: const Text('JOIN'),
                ),
            ]);
          },
        ),
      );
}

// ---------------- Me ----------------
class ProfilePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const ProfilePage({super.key, required this.profile, required this.onChanged});

  Widget _statCard(String value, String label) => Expanded(
        child: Container(
          height: 112,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
          alignment: Alignment.center,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(value, style: const TextStyle(color: Colors.black, fontSize: 27, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(label, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black, fontSize: 17, height: 1.12, fontWeight: FontWeight.w800)),
          ]),
        ),
      );

  Widget _menu(BuildContext context, IconData icon, String title, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 11),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(6),
          child: InkWell(
            borderRadius: BorderRadius.circular(6),
            onTap: onTap,
            child: SizedBox(height: 66, child: Row(children: [
              const SizedBox(width: 48),
              Icon(icon, color: Colors.black, size: 28),
              const SizedBox(width: 30),
              Expanded(child: Text(title, style: const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w800))),
            ])),
          ),
        ),
      );

  Future<void> _edit(BuildContext context) async {
    final m = await showForm(context, 'প্রোফাইল এডিট', const [F('name', 'নাম'), F('game_id', 'গেম আইডি')],
        init: {'name': '${profile['name']}', 'game_id': '${profile['game_id']}'});
    if (m == null || !context.mounted) return;
    final ok = await run(context, () => sb.from('profiles').update({'name': m['name'], 'game_id': m['game_id']}).eq('id', sb.auth.currentUser!.id),
        ok: 'আপডেট হয়েছে');
    if (ok) onChanged();
  }

  Future<void> _openConfigured(BuildContext context, String key) async {
    try {
      final cfg = await loadConfig();
      final links = cfg['links'];
      final url = links is Map ? '${links[key] ?? ''}' : '';
      if (context.mounted) await openUrl(context, url);
    } catch (_) {
      if (context.mounted) toast(context, 'লিংক লোড করা যায়নি', err: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final phone = '${profile['phone'] ?? ''}';
    final played = '${profile['matches_played'] ?? 0}';
    final kills = '${profile['total_kills'] ?? 0}';
    final wins = '${profile['total_wins'] ?? 0}';
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
      Row(children: [
        ClipOval(child: Image.asset('assets/images/logo.png', width: 58, height: 58, fit: BoxFit.cover)),
        const SizedBox(width: 14),
        const Expanded(child: Text('AMAR E-SPORTS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: .35, color: Colors.white))),
        Container(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFF07112E), size: 27), const SizedBox(width: 7), Text(money(profile['balance'] ?? 0).replaceAll('.00', '') + ' ৳', style: const TextStyle(color: Color(0xFF07112E), fontSize: 22, fontWeight: FontWeight.w900))])),
      ]),
      const SizedBox(height: 22),
      const Center(child: Icon(Icons.sports_esports, size: 58, color: Colors.white)),
      const SizedBox(height: 10),
      Center(child: Text(phone, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: .5))),
      const SizedBox(height: 46),
      Container(height: 132, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('${profile['balance'] ?? 0}', style: const TextStyle(color: Colors.black, fontSize: 29, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Available Balance', style: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w800)),
        ])),
      const SizedBox(height: 14),
      Row(children: [_statCard(played, 'Match\nPlayed'), _statCard(kills, 'Total Kills'), _statCard(wins, 'Total Wins')]),
      const SizedBox(height: 20),
      _menu(context, Icons.account_circle, 'My Profile', () => _edit(context)),
      _menu(context, Icons.account_balance_wallet, 'My Wallet', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletPage()))),
      _menu(context, Icons.help, 'Customer Support', () => _openConfigured(context, 'support')),
      _menu(context, Icons.shopping_bag, 'Topup Diamonds', () => _openConfigured(context, 'topup')),
      _menu(context, Icons.play_circle, 'How to play?', () => _openConfigured(context, 'how_to_play')),
      _menu(context, Icons.play_circle, 'YouTube Channel', () => _openConfigured(context, 'youtube')),
      _menu(context, Icons.person, 'Logout', () => sb.auth.signOut()),
      const SizedBox(height: 2),
      const Center(child: Text('Version: 1.0', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800))),
      const SizedBox(height: 4),
      const Center(child: Text('AMAR E-SPORTS', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 2))),
    ]);
  }
}
